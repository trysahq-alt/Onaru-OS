import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { hqAudit } from "@/lib/hq.functions";
import { Panel, Empty, relativeTime } from "@/components/hq/ui";

export const Route = createFileRoute("/_authenticated/hq/audit")({ component: HQAudit });

function HQAudit() {
  const fetchAudit = useServerFn(hqAudit);
  const { data, isLoading } = useQuery({ queryKey: ["hq", "audit"], queryFn: () => fetchAudit() });
  const rows = (data ?? []) as Array<Record<string, unknown>>;

  return (
    <div className="space-y-6">
      <header>
        <p className="text-[10px] uppercase tracking-[0.3em] text-gold">Onaru Core</p>
        <h1 className="mt-2 text-2xl font-semibold sm:text-3xl">Audit log</h1>
      </header>
      <Panel>
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : rows.length ? (
          <ul className="divide-y divide-border text-sm">
            {rows.map((a) => (
              <li key={String(a.id)} className="flex items-center justify-between gap-3 py-2.5">
                <span className="min-w-0 truncate">
                  <span className="text-gold">{String(a.action)}</span>
                  <span className="ml-2 text-muted-foreground">
                    {String(a.actor_label ?? a.actor_type ?? "")} · {String(a.resource_type ?? "")}
                  </span>
                </span>
                <span className="shrink-0 text-xs text-muted-foreground">{relativeTime(a.created_at as string)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <Empty title="No administrative actions recorded yet." />
        )}
      </Panel>
    </div>
  );
}
