import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { db } from "@/lib/db";
import { formatBytes, logActivity, signedUrl } from "@/lib/cms";
import { Loader2, Search, Trash2, Upload, X, Copy } from "lucide-react";
import { toast } from "sonner";

export type MediaItem = {
  id: string;
  path: string;
  url: string;
  filename: string;
  mime_type: string | null;
  size: number | null;
  alt_text: string | null;
  folder: string;
  created_at: string;
};

const ALLOWED = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/svg+xml",
  "video/mp4",
  "video/quicktime",
  "application/pdf",
];
const MAX_SIZE = 25 * 1024 * 1024;

export function useMedia(search = "") {
  return useQuery({
    queryKey: ["media", search],
    queryFn: async () => {
      let q = db.from("media").select("*").order("created_at", { ascending: false }).limit(300);
      if (search) q = q.ilike("filename", `%${search}%`);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as MediaItem[];
    },
  });
}

export function useUploadMedia() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (files: FileList | File[]) => {
      const { data: auth } = await supabase.auth.getUser();
      const list = Array.from(files);
      for (const file of list) {
        if (!ALLOWED.includes(file.type)) throw new Error(`${file.name}: unsupported file type`);
        if (file.size > MAX_SIZE) throw new Error(`${file.name}: larger than 25MB`);
        const ext = file.name.split(".").pop() ?? "bin";
        const path = `${new Date().getFullYear()}/${crypto.randomUUID()}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("media")
          .upload(path, file, { cacheControl: "31536000", contentType: file.type });
        if (upErr) throw upErr;
        const url = await signedUrl(path, 60 * 60 * 24 * 365);
        const { error } = await db.from("media").insert({
          path,
          url,
          filename: file.name,
          mime_type: file.type,
          size: file.size,
          uploaded_by: auth.user?.id ?? null,
        });
        if (error) throw error;
      }
      await logActivity(`Uploaded ${list.length} file(s)`, "media");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["media"] });
      toast.success("Upload complete");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function MediaGrid({
  onSelect,
  selectable = false,
}: {
  onSelect?: (item: MediaItem) => void;
  selectable?: boolean;
}) {
  const [search, setSearch] = useState("");
  const { data, isLoading } = useMedia(search);
  const upload = useUploadMedia();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  async function remove(item: MediaItem) {
    if (!confirm(`Delete ${item.filename}?`)) return;
    await supabase.storage.from("media").remove([item.path]);
    await db.from("media").delete().eq("id", item.id);
    await logActivity(`Deleted media ${item.filename}`, "media", item.id);
    qc.invalidateQueries({ queryKey: ["media"] });
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[180px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search files"
            className="h-11 w-full rounded-xl border border-border bg-background/50 pl-9 pr-3 text-sm outline-none focus:border-gold/50"
          />
        </div>
        <button
          onClick={() => fileRef.current?.click()}
          className="inline-flex h-11 items-center gap-2 rounded-xl bg-gold px-4 text-sm font-medium text-black"
        >
          {upload.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          Upload
        </button>
        <button
          onClick={() => cameraRef.current?.click()}
          className="inline-flex h-11 items-center rounded-xl border border-border px-4 text-sm sm:hidden"
        >
          Camera
        </button>
        <input
          ref={fileRef}
          type="file"
          multiple
          hidden
          accept={ALLOWED.join(",")}
          onChange={(e) => e.target.files && upload.mutate(e.target.files)}
        />
        <input
          ref={cameraRef}
          type="file"
          hidden
          accept="image/*"
          capture="environment"
          onChange={(e) => e.target.files && upload.mutate(e.target.files)}
        />
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="aspect-square animate-pulse rounded-xl bg-white/5" />
          ))}
        </div>
      ) : !data?.length ? (
        <p className="rounded-xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
          No files yet. Upload images, video, SVG or PDFs.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {data.map((item) => (
            <div
              key={item.id}
              className="group relative overflow-hidden rounded-xl border border-border bg-card"
            >
              <button
                type="button"
                onClick={() => onSelect?.(item)}
                className="block aspect-square w-full"
              >
                {item.mime_type?.startsWith("image/") ? (
                  <img
                    src={item.url}
                    alt={item.alt_text ?? item.filename}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="grid h-full place-items-center px-2 text-center text-[11px] text-muted-foreground">
                    {item.mime_type ?? "file"}
                  </div>
                )}
              </button>
              <div className="space-y-1 p-2">
                <p className="truncate text-[11px] text-foreground">{item.filename}</p>
                <p className="text-[10px] text-muted-foreground">{formatBytes(item.size)}</p>
              </div>
              {!selectable && (
                <div className="absolute right-1.5 top-1.5 flex gap-1 opacity-0 transition group-hover:opacity-100">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(item.url);
                      toast.success("URL copied");
                    }}
                    className="grid h-8 w-8 place-items-center rounded-lg bg-black/70 text-white"
                  >
                    <Copy className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => remove(item)}
                    className="grid h-8 w-8 place-items-center rounded-lg bg-black/70 text-red-400"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function MediaPicker({
  open,
  onClose,
  onSelect,
}: {
  open: boolean;
  onClose: () => void;
  onSelect: (url: string) => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-6">
      <div className="max-h-[85vh] w-full max-w-3xl overflow-y-auto rounded-t-2xl border border-border bg-card p-4 sm:rounded-2xl sm:p-6">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold">Media library</h3>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-white/5">
            <X className="h-4 w-4" />
          </button>
        </div>
        <MediaGrid
          selectable
          onSelect={(item) => {
            onSelect(item.url);
            onClose();
          }}
        />
      </div>
    </div>
  );
}
