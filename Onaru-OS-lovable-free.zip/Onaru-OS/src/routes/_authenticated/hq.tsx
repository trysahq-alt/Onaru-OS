import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { OnaruMark } from "@/components/site/Wordmark";
import { useSessionAccount, isAdminRole } from "@/hooks/useSession";
import {
  Activity,
  Boxes,
  Building2,
  Gauge,
  KeyRound,
  ScrollText,
  Users,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/hq")({
  head: () => ({
    meta: [
      { title: "ONARU HQ — Core Infrastructure Console" },
      { name: "description", content: "Identity, intelligence and integration infrastructure for the Onaru group." },
      { property: "og:title", content: "ONARU HQ" },
      { property: "og:description", content: "Identity, intelligence and integration infrastructure for the Onaru group." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: HQShell,
});

const nav = [
  { to: "/hq", label: "Overview", icon: Gauge, exact: true },
  { to: "/hq/products", label: "Products", icon: Boxes },
  { to: "/hq/users", label: "Identities", icon: Users },
  { to: "/hq/organizations", label: "Organizations", icon: Building2 },
  { to: "/hq/intelligence/events", label: "Events", icon: Activity },
  { to: "/hq/integrations", label: "Integrations", icon: KeyRound },
  { to: "/hq/audit", label: "Audit", icon: ScrollText },
];

function HQShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const account = useSessionAccount();
  const allowed = isAdminRole(account.data?.roles);

  const isActive = (to: string, exact?: boolean) =>
    exact ? pathname === to : pathname.startsWith(to);

  if (account.isLoading) {
    return <div className="grid min-h-screen place-items-center text-sm text-muted-foreground">Verifying access…</div>;
  }

  if (!allowed) {
    return (
      <div className="grid min-h-screen place-items-center px-6 text-center">
        <div>
          <OnaruMark className="mx-auto h-10 w-10" />
          <h1 className="mt-6 text-lg font-semibold">Onaru HQ is restricted</h1>
          <p className="mt-2 max-w-sm text-sm text-muted-foreground">
            This console is limited to Onaru leadership. Your account does not have HQ authorization.
          </p>
          <Link to="/" className="mt-6 inline-block text-xs uppercase tracking-[0.2em] text-gold">
            Return to onaru.com
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Mobile-first: top identity bar + scrollable rail; expands to a sidebar on large screens. */}
      <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur lg:hidden">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2.5">
            <OnaruMark className="h-7 w-7" />
            <div>
              <p className="text-sm font-semibold leading-none">ONARU HQ</p>
              <p className="mt-1 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Core</p>
            </div>
          </div>
          <span className="truncate text-[11px] text-muted-foreground">{account.data?.email}</span>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-2 [scrollbar-width:none]">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to as never}
              className={`whitespace-nowrap rounded-full px-3 py-1.5 text-xs transition ${
                isActive(item.to, item.exact) ? "bg-gold/12 text-gold" : "text-muted-foreground"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>

      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[240px] flex-col border-r border-border bg-card/30 lg:flex">
        <div className="flex items-center gap-3 px-5 py-6">
          <OnaruMark className="h-8 w-8" />
          <div>
            <p className="text-sm font-semibold leading-tight">ONARU HQ</p>
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Core Infrastructure</p>
          </div>
        </div>
        <nav className="flex-1 space-y-0.5 px-3">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to as never}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${
                isActive(item.to, item.exact)
                  ? "bg-gold/10 text-gold"
                  : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              }`}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="border-t border-border px-5 py-4">
          <p className="truncate text-xs">{account.data?.email}</p>
          <Link to="/admin" className="mt-1 block text-[11px] text-muted-foreground hover:text-foreground">
            Switch to Studio →
          </Link>
        </div>
      </aside>

      <main className="px-4 py-6 sm:px-6 lg:ml-[240px] lg:px-10 lg:py-10">
        <Outlet />
      </main>
    </div>
  );
}
