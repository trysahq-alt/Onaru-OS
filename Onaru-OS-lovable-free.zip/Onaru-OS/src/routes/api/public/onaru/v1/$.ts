import { anyDb } from "@/integrations/supabase/any-db";
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

/**
 * ONARU CONNECT — the server-to-server API connected products use to talk to
 * Onaru Core. Authenticated with per-product API credentials, never with the
 * service-role key. Scoped, rate limited and payload validated.
 */
export const Route = createFileRoute("/api/public/onaru/v1/$")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: cors() }),
      GET: async (ctx) => handle(ctx.request, ctx.params._splat ?? ""),
      POST: async (ctx) => handle(ctx.request, ctx.params._splat ?? ""),
    },
  },
});

function cors() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, content-type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  };
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", ...cors() },
  });
}

const identifySchema = z.object({
  email: z.string().trim().email().max(255),
  external_user_id: z.string().trim().max(200).optional(),
  phone: z.string().trim().max(40).optional(),
  first_name: z.string().trim().max(120).optional(),
  last_name: z.string().trim().max(120).optional(),
  display_name: z.string().trim().max(160).optional(),
  avatar_url: z.string().trim().url().max(600).optional(),
  country: z.string().trim().max(80).optional(),
  timezone: z.string().trim().max(80).optional(),
  email_verified: z.boolean().optional(),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

const eventSchema = z.object({
  event_name: z.string().trim().min(1).max(120),
  external_event_id: z.string().trim().max(200).optional(),
  external_user_id: z.string().trim().max(200).optional(),
  onaru_user_id: z.string().uuid().optional(),
  organization_slug: z.string().trim().max(160).optional(),
  session_id: z.string().trim().max(200).optional(),
  event_version: z.number().int().min(1).max(1000).optional(),
  properties: z.record(z.string(), z.unknown()).optional(),
  occurred_at: z.string().datetime().optional(),
});

async function handle(request: Request, splat: string) {
  const path = splat.replace(/^\/+|\/+$/g, "");
  const ip =
    request.headers.get("cf-connecting-ip") ??
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    null;

  const core = await import("@/lib/onaru/core.server");
  const auth = await core.authenticateApiClient(request);

  if ("failure" in auth) {
    await core.logApiRequest({
      endpoint: path,
      status: auth.failure.status,
      error: auth.failure.error,
      ip,
    });
    return json({ error: auth.failure.error }, auth.failure.status);
  }

  const client = auth.client;
  const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);

  const finish = async (body: unknown, status: number) => {
    await core.logApiRequest({
      clientId: client.id,
      productId: client.product_id,
      endpoint: path,
      status,
      error: status >= 400 ? String((body as { error?: string })?.error ?? "error") : null,
      ip,
    });
    return json(body, status);
  };

  const requireScope = (scope: Parameters<typeof core.hasScope>[1]) =>
    core.hasScope(client, scope) ? null : { error: `Missing scope: ${scope}` };

  let payload: unknown = {};
  if (request.method === "POST") {
    const raw = await request.text();
    if (raw.length > core.MAX_EVENT_BYTES * core.MAX_BATCH_EVENTS) {
      return finish({ error: "Payload too large" }, 413);
    }
    try {
      payload = raw ? JSON.parse(raw) : {};
    } catch {
      return finish({ error: "Invalid JSON body" }, 400);
    }
  }

  /** Resolves or creates the Onaru identity + product membership. */
  async function identify(input: z.infer<typeof identifySchema>) {
    const email = input.email.toLowerCase();

    let onaruUserId: string | null = null;

    if (input.external_user_id) {
      const { data: mapped } = await supabaseAdmin
        .from("onaru_product_memberships")
        .select("user_id")
        .eq("product_id", client.product_id)
        .eq("external_user_id", input.external_user_id)
        .maybeSingle();
      onaruUserId = mapped?.user_id ?? null;
    }

    if (!onaruUserId) {
      const { data: byEmail } = await supabaseAdmin
        .from("onaru_users")
        .select("id, email_verified")
        .ilike("primary_email", email)
        .maybeSingle();
      if (byEmail) {
        onaruUserId = byEmail.id;
        // An identity already exists for this email in another product: never
        // auto-merge. Record a link request that must be verified by the owner.
        if (input.external_user_id) {
          const { data: existingMembership } = await supabaseAdmin
            .from("onaru_product_memberships")
            .select("id")
            .eq("product_id", client.product_id)
            .eq("user_id", onaruUserId)
            .maybeSingle();
          if (!existingMembership) {
            await supabaseAdmin.from("onaru_identity_links").insert({
              primary_user_id: onaruUserId,
              product_id: client.product_id,
              external_user_id: input.external_user_id,
              email,
              status: "pending",
              requested_by: "product",
              expires_at: new Date(Date.now() + 7 * 864e5).toISOString(),
            });
            await core.writeAudit({
              actorType: "api_client",
              actorId: client.id,
              action: "account.link_requested",
              resourceType: "onaru_users",
              resourceId: onaruUserId,
              metadata: { product_id: client.product_id },
              ip,
            });
          }
        }
      }
    }

    if (!onaruUserId) {
      const { data: created, error } = await supabaseAdmin
        .from("onaru_users")
        .insert({
          primary_email: email,
          phone: input.phone ?? null,
          first_name: input.first_name ?? null,
          last_name: input.last_name ?? null,
          display_name: input.display_name ?? null,
          avatar_url: input.avatar_url ?? null,
          country: input.country ?? null,
          timezone: input.timezone ?? null,
          email_verified: input.email_verified ?? false,
          last_seen_at: new Date().toISOString(),
        })
        .select("id")
        .single();
      if (error || !created) throw new Error(error?.message ?? "Could not create identity");
      onaruUserId = created.id;
      await core.writeAudit({
        actorType: "api_client",
        actorId: client.id,
        action: "identity.created",
        resourceType: "onaru_users",
        resourceId: onaruUserId,
        metadata: { product_id: client.product_id },
        ip,
      });
    } else {
      await supabaseAdmin
        .from("onaru_users")
        .update({ last_seen_at: new Date().toISOString() })
        .eq("id", onaruUserId);
    }

    await supabaseAdmin.from("onaru_product_memberships").upsert(
      {
        user_id: onaruUserId,
        product_id: client.product_id,
        external_user_id: input.external_user_id ?? null,
        last_active_at: new Date().toISOString(),
        metadata: (input.metadata ?? {}) as never,
      },
      { onConflict: "user_id,product_id" },
    );

    return onaruUserId;
  }

  async function ingest(list: z.infer<typeof eventSchema>[]) {
    const rows: Record<string, unknown>[] = [];
    for (const e of list) {
      const props = core.sanitizeProperties(e.properties ?? {});
      if (new TextEncoder().encode(JSON.stringify(props)).length > core.MAX_EVENT_BYTES) {
        return { error: `Event ${e.event_name} exceeds payload size limit` };
      }
      let userId = e.onaru_user_id ?? null;
      if (!userId && e.external_user_id) {
        const { data: m } = await supabaseAdmin
          .from("onaru_product_memberships")
          .select("user_id")
          .eq("product_id", client.product_id)
          .eq("external_user_id", e.external_user_id)
          .maybeSingle();
        userId = m?.user_id ?? null;
      }
      let orgId: string | null = null;
      if (e.organization_slug) {
        const { data: org } = await supabaseAdmin
          .from("onaru_organizations")
          .select("id")
          .eq("slug", e.organization_slug)
          .maybeSingle();
        orgId = org?.id ?? null;
      }
      rows.push({
        event_name: e.event_name,
        product_id: client.product_id,
        user_id: userId,
        organization_id: orgId,
        external_user_id: e.external_user_id ?? null,
        external_event_id: e.external_event_id ?? null,
        session_id: e.session_id ?? null,
        event_version: e.event_version ?? 1,
        properties: props,
        occurred_at: e.occurred_at ?? new Date().toISOString(),
        environment: client.environment,
      });
    }
    // Idempotent on (product_id, external_event_id): a replayed event is ignored.
    const { data, error } = await supabaseAdmin
      .from("onaru_events")
      .upsert(rows as never, { onConflict: "product_id,external_event_id", ignoreDuplicates: true })
      .select("id");
    if (error) return { error: error.message };
    return { accepted: rows.length, stored: data?.length ?? 0 };
  }

  try {
    switch (`${request.method} ${path}`) {
      case "POST identify": {
        const scoped = requireScope("identity:write");
        if (scoped) return finish(scoped, 403);
        const parsed = identifySchema.safeParse(payload);
        if (!parsed.success) return finish({ error: parsed.error.issues[0]?.message }, 400);
        const id = await identify(parsed.data);
        return finish({ onaru_user_id: id }, 200);
      }

      case "POST link-external-user": {
        const scoped = requireScope("memberships:write");
        if (scoped) return finish(scoped, 403);
        const schema = z.object({
          onaru_user_id: z.string().uuid(),
          external_user_id: z.string().trim().min(1).max(200),
          role: z.string().trim().max(60).optional(),
        });
        const parsed = schema.safeParse(payload);
        if (!parsed.success) return finish({ error: parsed.error.issues[0]?.message }, 400);
        const { error } = await supabaseAdmin.from("onaru_product_memberships").upsert(
          {
            user_id: parsed.data.onaru_user_id,
            product_id: client.product_id,
            external_user_id: parsed.data.external_user_id,
            role: parsed.data.role ?? "user",
            last_active_at: new Date().toISOString(),
          },
          { onConflict: "user_id,product_id" },
        );
        if (error) return finish({ error: error.message }, 400);
        await core.writeAudit({
          actorType: "api_client",
          actorId: client.id,
          action: "account.linked",
          resourceType: "onaru_users",
          resourceId: parsed.data.onaru_user_id,
          metadata: { product_id: client.product_id },
          ip,
        });
        return finish({ ok: true }, 200);
      }

      case "POST memberships": {
        const scoped = requireScope("memberships:write");
        if (scoped) return finish(scoped, 403);
        const schema = z.object({
          onaru_user_id: z.string().uuid(),
          role: z.string().trim().max(60).optional(),
          status: z.string().trim().max(40).optional(),
          metadata: z.record(z.string(), z.unknown()).optional(),
        });
        const parsed = schema.safeParse(payload);
        if (!parsed.success) return finish({ error: parsed.error.issues[0]?.message }, 400);
        const { error } = await supabaseAdmin.from("onaru_product_memberships").upsert(
          {
            user_id: parsed.data.onaru_user_id,
            product_id: client.product_id,
            role: parsed.data.role ?? "user",
            status: parsed.data.status ?? "active",
            metadata: (parsed.data.metadata ?? {}) as never,
            last_active_at: new Date().toISOString(),
          },
          { onConflict: "user_id,product_id" },
        );
        if (error) return finish({ error: error.message }, 400);
        return finish({ ok: true }, 200);
      }

      case "POST organizations": {
        const scoped = requireScope("organizations:write");
        if (scoped) return finish(scoped, 403);
        const schema = z.object({
          name: z.string().trim().min(1).max(200),
          slug: z.string().trim().min(1).max(160).regex(/^[a-z0-9-]+$/),
          organization_type: z.string().trim().max(60).optional(),
          country: z.string().trim().max(80).optional(),
          logo_url: z.string().trim().url().max(600).optional(),
          owner_onaru_user_id: z.string().uuid().optional(),
        });
        const parsed = schema.safeParse(payload);
        if (!parsed.success) return finish({ error: parsed.error.issues[0]?.message }, 400);
        const { data, error } = await supabaseAdmin
          .from("onaru_organizations")
          .upsert(
            {
              name: parsed.data.name,
              slug: parsed.data.slug,
              organization_type: parsed.data.organization_type ?? "business",
              country: parsed.data.country ?? null,
              logo_url: parsed.data.logo_url ?? null,
              owner_user_id: parsed.data.owner_onaru_user_id ?? null,
            },
            { onConflict: "slug" },
          )
          .select("id")
          .single();
        if (error) return finish({ error: error.message }, 400);
        if (parsed.data.owner_onaru_user_id) {
          await supabaseAdmin.from("onaru_organization_members").upsert(
            {
              organization_id: data.id,
              user_id: parsed.data.owner_onaru_user_id,
              role: "owner",
              permissions: ["*"] as never,
            },
            { onConflict: "organization_id,user_id" },
          );
        }
        return finish({ organization_id: data.id }, 200);
      }

      case "POST events": {
        const scoped = requireScope("events:write");
        if (scoped) return finish(scoped, 403);
        const parsed = eventSchema.safeParse(payload);
        if (!parsed.success) return finish({ error: parsed.error.issues[0]?.message }, 400);
        const result = await ingest([parsed.data]);
        return finish(result, "error" in result ? 400 : 202);
      }

      case "POST events/batch": {
        const scoped = requireScope("events:write");
        if (scoped) return finish(scoped, 403);
        const parsed = z
          .object({ events: z.array(eventSchema).min(1).max(core.MAX_BATCH_EVENTS) })
          .safeParse(payload);
        if (!parsed.success) return finish({ error: parsed.error.issues[0]?.message }, 400);
        const result = await ingest(parsed.data.events);
        return finish(result, "error" in result ? 400 : 202);
      }

      default: {
        // GET identity/<onaru_user_id>  — scoped to identities this product knows.
        const identityMatch = path.match(/^identity\/([0-9a-f-]{36})$/i);
        if (request.method === "GET" && identityMatch) {
          const scoped = requireScope("identity:read");
          if (scoped) return finish(scoped, 403);
          const userId = identityMatch[1];
          const { data: membership } = await supabaseAdmin
            .from("onaru_product_memberships")
            .select("external_user_id, role, status, joined_at, last_active_at")
            .eq("product_id", client.product_id)
            .eq("user_id", userId)
            .maybeSingle();
          if (!membership) return finish({ error: "Not found" }, 404);
          const { data: user } = await supabaseAdmin
            .from("onaru_users")
            .select(
              "id, primary_email, first_name, last_name, display_name, avatar_url, country, timezone, status, email_verified, phone_verified, identity_verified, created_at, last_seen_at",
            )
            .eq("id", userId)
            .maybeSingle();
          if (!user) return finish({ error: "Not found" }, 404);
          return finish({ identity: user, membership }, 200);
        }
        return finish({ error: "Unknown endpoint" }, 404);
      }
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unexpected error";
    return finish({ error: message }, 500);
  }
}
