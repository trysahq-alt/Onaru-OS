import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { hqEvents } from "@/lib/hq.functions";
import { Panel, Empty, Tag, relativeTime } from "@/components/hq/ui";

export const Route = createFileRoute("/_authenticated/hq/intelligence/events")({ component: HQEvents });

function HQEvents() {
  const [productId, setProductId] = useState("");
  const [eventName, setEventName] = useState("");
  const [environment, setEnvironment] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const fetchEvents = useServerFn(hqEvents);

  const { data, isLoading } = useQuery({
    queryKey: ["hq", "events", productId, eventName, environment],
    queryFn: () =>
      fetchEvents({
        data: {
          productId: productId || undefined,
          eventName: eventName || undefined,
          environment: (environment || undefined) as never,
        },
      }),
  });

  const products = data?.products ?? [];
  const events = (data?.events ?? []) as Array<Record<string, unknown>>;

  return (
    <div className="space-y-6">
      <header>
        <p className="text-[10px] uppercase tracking-[0.3em] text-gold">Onaru Intelligence</p>
        <h1 className="mt-2 text-2xl font-semibold sm:text-3xl">Event explorer</h1>
      </header>

      <div className="grid gap-2 sm:grid-cols-3">
        <select value={productId} onChange={(e) => setProductId(e.target.value)} className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm">
          <option value="">All products</option>
          {products.map((p) => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>
        <select value={eventName} onChange={(e) => setEventName(e.target.value)} className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm">
          <option value="">All event types</option>
          {(data?.eventNames ?? []).map((n) => (
            <option key={String(n)} value={String(n)}>{String(n)}</option>
          ))}
        </select>
        <select value={environment} onChange={(e) => setEnvironment(e.target.value)} className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm">
          <option value="">All environments</option>
          <option value="development">development</option>
          <option value="staging">staging</option>
          <option value="production">production</option>
        </select>
      </div>

      <Panel>
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading events…</p>
        ) : events.length ? (
          <ul className="divide-y divide-border text-sm">
            {events.map((e) => {
              const id = String(e.id);
              return (
                <li key={id} className="py-2.5">
                  <button className="flex w-full items-center justify-between gap-3 text-left" onClick={() => setOpen(open === id ? null : id)}>
                    <span className="min-w-0 truncate">
                      <span className="text-muted-foreground">
                        {products.find((p) => p.id === e.product_id)?.name ?? "—"}
                      </span>
                      <span className="mx-2 text-muted-foreground/40">—</span>
                      {String(e.event_name)}
                    </span>
                    <span className="flex shrink-0 items-center gap-2">
                      <Tag>{String(e.environment)}</Tag>
                      <span className="text-xs text-muted-foreground">{relativeTime(e.occurred_at as string)}</span>
                    </span>
                  </button>
                  {open === id ? (
                    <pre className="mt-2 overflow-x-auto rounded-xl border border-border bg-black/40 p-3 text-[11px] text-muted-foreground">
                      {JSON.stringify(e.properties ?? {}, null, 2)}
                    </pre>
                  ) : null}
                </li>
              );
            })}
          </ul>
        ) : (
          <Empty title="No events match these filters." body="Events appear as soon as connected products send them through Onaru Connect." />
        )}
      </Panel>
    </div>
  );
}
