import { createFileRoute } from "@tanstack/react-router";
import { siteUrl } from "@/config/site";
import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { Founder } from "@/components/site/Founder";
import { Companies } from "@/components/site/Companies";
import { TwoSides } from "@/components/site/TwoSides";
import { About } from "@/components/site/About";
import { Philosophy } from "@/components/site/Philosophy";
import { Impact } from "@/components/site/Impact";
import { Vision } from "@/components/site/Vision";
import { Contact, Footer } from "@/components/site/Contact";
import { SmoothScroll } from "@/components/site/SmoothScroll";
import { Cursor } from "@/components/site/Cursor";
import { PageLoad } from "@/components/site/PageLoad";

const title = "ONARU LIMITED — Building Companies That Shape Africa's Future";
const description =
  "ONARU Limited is a venture holding company creating technology, media, education and creative businesses that solve real problems at scale.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: siteUrl("/") },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: siteUrl("/") }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "ONARU LIMITED",
          description,
          foundingLocation: "Lagos, Nigeria",
          founder: { "@type": "Person", name: "Abayomi Onalaru" },
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <SmoothScroll />
      <PageLoad />
      <Cursor />
      <Nav />
      <main>
        <Hero />
        <Founder />
        <TwoSides />
        <Companies />
        <About />
        <Philosophy />
        <Impact />
        <Vision />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
