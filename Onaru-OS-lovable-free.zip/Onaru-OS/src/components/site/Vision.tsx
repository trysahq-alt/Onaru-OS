import { Reveal } from "./Reveal";

export function Vision() {
  return (
    <section className="grain relative overflow-hidden border-t border-border py-32 md:py-48">
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 h-[60vh] w-[90vw] -translate-x-1/2 -translate-y-1/2 opacity-[0.14] blur-[130px]"
        style={{ background: "var(--gradient-gold)" }}
      />
      <div className="relative mx-auto max-w-[1400px] px-6 text-center md:px-10">
        <Reveal>
          <p className="eyebrow">Vision</p>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="display-lg mx-auto mt-10 max-w-[14ch] text-muted-foreground">
            Our ambition is simple.
          </p>
        </Reveal>
        <Reveal delay={0.2}>
          <p className="display-xl mx-auto mt-8 max-w-[20ch]">
            Build companies that improve how Africa{" "}
            <span className="text-gold-gradient">creates, works and grows.</span>
          </p>
        </Reveal>
      </div>
    </section>
  );
}
