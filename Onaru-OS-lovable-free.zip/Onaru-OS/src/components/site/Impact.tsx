import { useEffect, useRef, useState } from "react";
import { useInView } from "motion/react";
import { Reveal } from "./Reveal";

const stats = [
  { value: 10, suffix: "", label: "Companies Built" },
  { value: 2400, suffix: "+", label: "Creators Empowered" },
  { value: 6, suffix: "", label: "Countries Reached" },
  { value: 850, suffix: "+", label: "Projects Completed" },
  { value: 9, suffix: "", label: "Years Building" },
];

function Counter({ value, suffix }: { value: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-15%" });
  const [n, setN] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let frame = 0;
    const total = 90;
    const tick = () => {
      frame += 1;
      const p = 1 - Math.pow(1 - frame / total, 4);
      setN(Math.round(value * p));
      if (frame < total) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [inView, value]);

  return (
    <span ref={ref} className="tabular-nums">
      {n.toLocaleString()}
      {suffix}
    </span>
  );
}

export function Impact() {
  return (
    <section id="impact" className="relative border-t border-border py-32 md:py-52">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10">
        <Reveal>
          <p className="eyebrow">Impact</p>
          <h2 className="display-lg mt-6 max-w-[18ch]">Measured in what we leave behind.</h2>
        </Reveal>

        <div className="mt-16 grid grid-cols-2 gap-px overflow-hidden rounded-[1.5rem] bg-border hairline md:mt-24 md:grid-cols-5">
          {stats.map((s, i) => (
            <div key={s.label} className="bg-card p-8 md:p-10">
              <Reveal delay={i * 0.06}>
                <p className="text-4xl tracking-tight text-gold-gradient md:text-5xl">
                  <Counter value={s.value} suffix={s.suffix} />
                </p>
                <p className="eyebrow mt-4 leading-relaxed">{s.label}</p>
              </Reveal>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
