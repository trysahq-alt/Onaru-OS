import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { hqProduct } from "@/lib/hq.functions";
import { Panel, Empty, Tag, num, relativeTime } from "@/components/hq/ui";

export const Route = createFileRoute("/_authenticated/hq/products/$id")({ component: HQProductDetail });

function HQProductDetail() {
  const { id } = Route.useParams();
  const fetchProduct = useServerFn(hqProduct);
  const { data, isLoading, error } = useQuery({
    queryKey: ["hq", "product", id],
    queryFn: () => fetchProduct({ data: { id } }),
  });

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading product…</p>;
  if (error) return <p className="text-sm text-red-300">{(error as Error).message}</p>;
  if (!data) return null;

  const p = data.product as Record<string, unknown>;
  const s = (data.stats ?? {}) as Record<string, unknown>;

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center gap-3">
        <div>
          <h1 className="text-2xl font-semibold sm:text-3xl">{String(p.name)}</h1>
          <p className="text-xs text-muted-foreground">{String(p.api_identifier)}</p>
        </div>
        <Tag tone={p.status === "active" ? "good" : "muted"}>{String(p.status)}</Tag>
        <Tag>{String(p.environment)}</Tag>
      </header>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          ["Users", s.users],
          ["Active 30d", s.active_users_30d],
          ["Events 30d", s.events_30d],
          ["Revenue 30d", s.revenue_30d],
        ].map(([label, value]) => (
          <div key={String(label)} className="rounded-2xl border border-border bg-card/40 p-4">
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{String(label)}</p>
            <p className="mt-2 text-2xl font-semibold tabular-nums">{num(value)}</p>
          </div>
        ))}
      </div>

      <Panel title="Recent events">
        {data.events.length ? (
          <ul className="divide-y divide-border text-sm">
            {data.events.map((e) => (
              <li key={e.id} className="flex items-center justify-between gap-3 py-2.5">
                <span className="truncate">{e.event_name}</span>
                <span className="shrink-0 text-xs text-muted-foreground">{relativeTime(e.occurred_at)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <Empty title="No events received from this product yet." />
        )}
      </Panel>

      <Panel title="Integration health — recent API calls">
        {data.requests.length ? (
          <ul className="divide-y divide-border text-sm">
            {data.requests.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 py-2.5">
                <span className="truncate">
                  <span className={r.status_code >= 400 ? "text-red-300" : "text-emerald-300"}>{r.status_code}</span>
                  <span className="ml-2 text-muted-foreground">/{r.endpoint}</span>
                  {r.error ? <span className="ml-2 text-xs text-red-300">{r.error}</span> : null}
                </span>
                <span className="shrink-0 text-xs text-muted-foreground">{relativeTime(r.created_at)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <Empty title="No API traffic recorded yet." />
        )}
      </Panel>
    </div>
  );
}
