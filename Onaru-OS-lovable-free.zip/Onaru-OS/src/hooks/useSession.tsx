import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { bootstrapAccount, type AppRole } from "@/lib/admin.functions";

export function useSessionAccount() {
  const bootstrap = useServerFn(bootstrapAccount);
  return useQuery({
    queryKey: ["account"],
    queryFn: () => bootstrap(),
    staleTime: 5 * 60 * 1000,
  });
}

export const roleLabels: Record<AppRole, string> = {
  super_admin: "Super Admin",
  admin: "Admin",
  editor: "Editor",
  writer: "Writer",
  marketing: "Marketing",
  support: "Support",
  viewer: "Viewer",
};

export const allRoles = Object.keys(roleLabels) as AppRole[];

export function canEdit(roles: AppRole[] = []) {
  return roles.some((r) => ["super_admin", "admin", "editor", "writer", "marketing"].includes(r));
}

export function isAdminRole(roles: AppRole[] = []) {
  return roles.some((r) => r === "super_admin" || r === "admin");
}
