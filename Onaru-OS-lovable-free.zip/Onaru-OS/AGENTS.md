# ONARU OS Engineering Rules

ONARU OS is an independent application. Do not introduce vendor-specific editor/runtime dependencies.

- Production backend: ONARU Supabase project `ltwrbgndncispmigvvga`.
- Browser authentication: Supabase Auth.
- Server secrets: environment variables and Supabase Vault/Edge Functions; never commit secrets.
- AI actions must go through the ONARU capability/tool gateway.
- Keep RLS enabled and preserve existing security boundaries.
- Keep production infrastructure on ONARU-owned services; do not add hosted development-platform dependencies, preview brokers, or telemetry.
