import { anyDb } from "@/integrations/supabase/any-db";
import { supabase } from "@/integrations/supabase/client";

export type ContentStatus = "draft" | "scheduled" | "published" | "archived";

export const statusTone: Record<ContentStatus, string> = {
  draft: "bg-white/8 text-muted-foreground",
  scheduled: "bg-sky-500/12 text-sky-300",
  published: "bg-emerald-500/12 text-emerald-300",
  archived: "bg-white/5 text-muted-foreground/70",
};

export function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/['"]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export function formatDate(value?: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function formatBytes(bytes?: number | null) {
  if (!bytes) return "0 KB";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let n = bytes;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i += 1;
  }
  return `${n.toFixed(n < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

export async function logActivity(action: string, entityType?: string, entityId?: string) {
  const { data } = await supabase.auth.getUser();
  if (!data.user) return;
  await anyDb(supabase).from("activity_log").insert({
    user_id: data.user.id,
    actor_name: data.user.email,
    action,
    entity_type: entityType ?? null,
    entity_id: entityId ?? null,
  });
}

/** Signed URL for a private media-bucket object. */
export async function signedUrl(path: string, expiresIn = 60 * 60 * 24 * 7) {
  const { data } = await supabase.storage.from("media").createSignedUrl(path, expiresIn);
  return data?.signedUrl ?? "";
}
