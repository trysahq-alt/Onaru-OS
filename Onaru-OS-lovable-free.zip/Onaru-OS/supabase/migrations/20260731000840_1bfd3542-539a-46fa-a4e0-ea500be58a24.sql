
CREATE POLICY "Team reads media files" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'media' AND public.is_staff(auth.uid()));
CREATE POLICY "Team uploads media files" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'media' AND public.can_edit(auth.uid()));
CREATE POLICY "Team updates media files" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'media' AND public.can_edit(auth.uid()));
CREATE POLICY "Admins delete media files" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'media' AND public.is_admin(auth.uid()));
