import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { db } from "@/lib/db";
import { formatDate } from "@/lib/cms";
import {
  Eye,
  FileEdit,
  Inbox,
  Mail,
  Newspaper,
  Plus,
  Clock,
  Users,
  HardDrive,
  Activity as ActivityIcon,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: Dashboard,
});

function useStats() {
  return useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async () => {
      const since = new Date(Date.now() - 30 * 864e5).toISOString();
      const count = async (table: string, build?: (q: any) => any) => {
        let q = db.from(table).select("*", { count: "exact", head: true });
        if (build) q = build(q);
        const { count: c } = await q;
        return c ?? 0;
      };
      const [
        views,
        visitors,
        subscribers,
        enquiries,
        newEnquiries,
        published,
        drafts,
        scheduled,
        team,
        mediaRows,
      ] = await Promise.all([
        count("page_views", (q) => q.gte("created_at", since)),
        db
          .from("page_views")
          .select("session_id")
          .gte("created_at", since)
          .then(({ data }: any) => new Set((data ?? []).map((r: any) => r.session_id)).size),
        count("subscribers", (q) => q.eq("status", "subscribed")),
        count("submissions"),
        count("submissions", (q) => q.eq("status", "new")),
        count("posts", (q) => q.eq("status", "published")),
        count("posts", (q) => q.eq("status", "draft")),
        count("posts", (q) => q.eq("status", "scheduled")),
        count("profiles"),
        db.from("media").select("size").then(({ data }: any) => data ?? []),
      ]);

      const storage = (mediaRows as { size: number | null }[]).reduce(
        (sum, m) => sum + (m.size ?? 0),
        0,
      );

      return {
        views,
        visitors,
        subscribers,
        enquiries,
        newEnquiries,
        published,
        drafts,
        scheduled,
        team,
        storage,
        files: mediaRows.length,
      };
    },
  });
}

function Stat({
  label,
  value,
  icon: Icon,
  hint,
}: {
  label: string;
  value: string | number;
  icon: React.ElementType;
  hint?: string;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card/60 p-4">
      <div className="flex items-center justify-between">
        <span className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">{label}</span>
        <Icon className="h-4 w-4 text-gold/70" />
      </div>
      <p className="mt-3 text-2xl font-semibold tracking-tight">{value}</p>
      {hint && <p className="mt-1 text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}

function Dashboard() {
  const stats = useStats();
  const activity = useQuery({
    queryKey: ["activity", "recent"],
    queryFn: async () => {
      const { data } = await db
        .from("activity_log")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(8);
      return data ?? [];
    },
  });

  const s = stats.data;
  const mb = s ? (s.storage / (1024 * 1024)).toFixed(1) : "0";

  const quick = [
    { to: "/admin/insights", label: "New article", icon: Newspaper },
    { to: "/admin/work", label: "New project", icon: FileEdit },
    { to: "/admin/pages", label: "Edit pages", icon: Plus },
    { to: "/admin/services", label: "Manage services", icon: Inbox },
  ] as const;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Overview</h1>
        <p className="mt-1 text-sm text-muted-foreground">Last 30 days across the ONARU website.</p>
      </header>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Page views" value={s?.views ?? "—"} icon={Eye} hint="30 days" />
        <Stat label="Visitors" value={s?.visitors ?? "—"} icon={Users} hint="Unique sessions" />
        <Stat label="Subscribers" value={s?.subscribers ?? "—"} icon={Mail} />
        <Stat
          label="Enquiries"
          value={s?.enquiries ?? "—"}
          icon={Inbox}
          hint={s ? `${s.newEnquiries} unread` : undefined}
        />
        <Stat label="Published" value={s?.published ?? "—"} icon={Newspaper} />
        <Stat label="Drafts" value={s?.drafts ?? "—"} icon={FileEdit} />
        <Stat label="Scheduled" value={s?.scheduled ?? "—"} icon={Clock} />
        <Stat
          label="Storage"
          value={`${mb} MB`}
          icon={HardDrive}
          hint={s ? `${s.files} files` : undefined}
        />
      </div>

      <section>
        <h2 className="mb-3 text-xs uppercase tracking-[0.16em] text-muted-foreground">
          Quick actions
        </h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {quick.map((q) => (
            <Link
              key={q.to + q.label}
              to={q.to}
              className="flex items-center gap-2.5 rounded-xl border border-border bg-card/50 px-4 py-3.5 text-sm transition hover:border-gold/40"
            >
              <q.icon className="h-4 w-4 text-gold/80" />
              {q.label}
            </Link>
          ))}
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-border bg-card/50 p-5">
          <h2 className="mb-4 flex items-center gap-2 text-sm font-medium">
            <ActivityIcon className="h-4 w-4 text-gold/70" /> Recent activity
          </h2>
          {activity.data?.length ? (
            <ul className="space-y-3">
              {activity.data.map((a: any) => (
                <li key={a.id} className="flex items-start justify-between gap-3 text-sm">
                  <div className="min-w-0">
                    <p className="truncate text-foreground">{a.action}</p>
                    <p className="text-[11px] text-muted-foreground">{a.actor_name}</p>
                  </div>
                  <span className="shrink-0 text-[11px] text-muted-foreground">
                    {formatDate(a.created_at)}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground">No activity recorded yet.</p>
          )}
        </div>

        <div className="rounded-2xl border border-border bg-card/50 p-5">
          <h2 className="mb-4 text-sm font-medium">Website health</h2>
          <ul className="space-y-3 text-sm">
            <HealthRow label="Database" ok />
            <HealthRow label="Authentication" ok />
            <HealthRow label="Media storage" ok />
            <HealthRow label="Team members" ok value={String(s?.team ?? 0)} />
          </ul>
        </div>
      </section>
    </div>
  );
}

function HealthRow({ label, ok, value }: { label: string; ok: boolean; value?: string }) {
  return (
    <li className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="flex items-center gap-2">
        {value && <span className="text-xs text-muted-foreground">{value}</span>}
        <span
          className={`h-2 w-2 rounded-full ${ok ? "bg-emerald-400" : "bg-red-400"}`}
          aria-label={ok ? "Healthy" : "Issue"}
        />
      </span>
    </li>
  );
}
