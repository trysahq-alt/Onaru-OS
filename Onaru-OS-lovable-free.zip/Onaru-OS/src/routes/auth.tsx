import { useEffect, useState } from "react";
import { createFileRoute, useNavigate, useSearch } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { OnaruMark } from "@/components/site/Wordmark";
import { toast } from "sonner";

const title = "Sign in — ONARU Studio";
const description = "Secure access to the ONARU content and growth operating system.";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { name: "robots", content: "noindex" },
    ],
  }),
  validateSearch: (search: Record<string, unknown>) => ({
    redirect: typeof search.redirect === "string" ? search.redirect : undefined,
  }),
  component: AuthPage,
});

function safePath(value?: string) {
  if (!value || !value.startsWith("/") || value.startsWith("//")) return "/admin";
  return value;
}

function AuthPage() {
  const navigate = useNavigate();
  const search = useSearch({ from: "/auth" });
  const target = safePath(search.redirect);

  const [mode, setMode] = useState<"signin" | "reset">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: target, replace: true });
    });
  }, [navigate, target]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "reset") {
        const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        toast.success("Reset link sent", { description: "Check your inbox." });
        setMode("signin");
        return;
      }
      const { error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      if (error) throw error;
      navigate({ to: target, replace: true });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogle() {
    setBusy(true);
    try {
      sessionStorage.setItem("onaru:redirect", target);
      const callback = `${window.location.origin}/auth`;
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo: callback },
      });
      if (error) throw error;
      return;
      navigate({ to: target, replace: true });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Google sign-in failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-5 py-16">
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-[-30%] h-[80vh] w-[110vw] -translate-x-1/2 rounded-full opacity-40 blur-3xl"
        style={{ background: "var(--gradient-gold, radial-gradient(circle, rgba(201,162,39,.25), transparent 70%))" }}
      />
      <div className="relative w-full max-w-[400px]">
        <div className="mb-10 flex flex-col items-center text-center">
          <OnaruMark className="h-12 w-12" />
          <h1 className="mt-6 text-2xl font-semibold tracking-tight text-foreground">
            ONARU Studio
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {mode === "signin"
              ? "Sign in to manage the website."
              : "We'll email you a secure reset link."}
          </p>
        </div>

        <div className="rounded-2xl border border-border bg-card/70 p-6 backdrop-blur-xl sm:p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-muted-foreground">
                Email
              </label>
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-12 w-full rounded-xl border border-border bg-background/60 px-4 text-base text-foreground outline-none transition focus:border-gold/60"
                placeholder="you@onaru.com"
              />
            </div>

            {mode === "signin" && (
              <div>
                <label className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-muted-foreground">
                  Password
                </label>
                <input
                  type="password"
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-12 w-full rounded-xl border border-border bg-background/60 px-4 text-base text-foreground outline-none transition focus:border-gold/60"
                  placeholder="••••••••"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="h-12 w-full rounded-xl bg-gold text-base font-medium text-black transition hover:opacity-90 disabled:opacity-50"
            >
              {busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Send reset link"}
            </button>
          </form>

          {mode === "signin" && (
            <>
              <div className="my-5 flex items-center gap-3 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                <span className="h-px flex-1 bg-border" />
                or
                <span className="h-px flex-1 bg-border" />
              </div>
              <button
                onClick={handleGoogle}
                disabled={busy}
                className="h-12 w-full rounded-xl border border-border bg-background/40 text-base font-medium text-foreground transition hover:bg-white/5 disabled:opacity-50"
              >
                Continue with Google
              </button>
            </>
          )}

          <button
            onClick={() => setMode(mode === "signin" ? "reset" : "signin")}
            className="mt-5 w-full text-center text-sm text-muted-foreground transition hover:text-foreground"
          >
            {mode === "signin" ? "Forgot your password?" : "Back to sign in"}
          </button>
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          Access is invite-only. Contact your administrator.
        </p>
      </div>
    </main>
  );
}
