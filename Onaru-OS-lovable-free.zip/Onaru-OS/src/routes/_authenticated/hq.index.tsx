import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { hqOverview } from "@/lib/hq.functions";
import { Panel, Stat, Empty, num, relativeTime } from "@/components/hq/ui";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export const Route = createFileRoute("/_authenticated/hq/")({ component: HQOverview });

function HQOverview() {
  const fetchOverview = useServerFn(hqOverview);
  const { data, isLoading, error } = useQuery({
    queryKey: ["hq", "overview"],
    queryFn: () => fetchOverview(),
    refetchInterval: 30_000,
  });

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading intelligence…</p>;
  if (error) return <p className="text-sm text-red-300">{(error as Error).message}</p>;
  if (!data) return null;

  const o = data.overview ?? {};
  const productName = (id: string) => data.products.find((p) => p.id === id)?.name ?? "Unknown product";
  const growth =
    Number(o.new_prev_week) > 0
      ? Math.round(((Number(o.new_this_week) - Number(o.new_prev_week)) / Number(o.new_prev_week)) * 100)
      : null;

  return (
    <div className="space-y-6">
      <header>
        <p className="text-[10px] uppercase tracking-[0.3em] text-gold">Onaru Core</p>
        <h1 className="mt-2 text-2xl font-semibold sm:text-3xl">Executive overview</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Identity, activity and integration health across every connected Onaru company.
        </p>
      </header>

      {data.products.length === 0 ? (
        <Empty
          title="No products connected yet."
          body="Onaru Core is live and ready. Register your first product to start issuing credentials and receiving events."
          action={
            <Link to="/hq/integrations" className="rounded-full bg-gold px-4 py-2 text-xs font-medium text-black">
              Connect your first product →
            </Link>
          }
        />
      ) : null}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total identities" value={num(o.total_identities)} sub={`${num(o.new_today)} new today`} />
        <Stat
          label="New this week"
          value={num(o.new_this_week)}
          sub={growth === null ? "No prior week baseline" : `${growth >= 0 ? "+" : ""}${growth}% vs last week`}
        />
        <Stat label="Monthly active" value={num(o.mau)} sub={`${num(o.dau)} active today`} />
        <Stat label="Connected products" value={num(o.connected_products)} sub={`${num(o.active_products)} active`} />
        <Stat label="Organizations" value={num(o.active_organizations)} />
        <Stat label="Events today" value={num(o.events_today)} sub={`${num(o.events_30d)} in 30 days`} />
        <Stat label="Revenue events (30d)" value={num(o.revenue_events_30d)} sub={`${num(o.revenue_amount_30d)} reported value`} />
        <Stat label="Bookings (30d)" value={num(o.bookings_30d)} sub={`${num(o.subscriptions_active)} live subscriptions`} />
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Panel title="User growth — 30 days">
          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.series}>
                <defs>
                  <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#C8A45C" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#C8A45C" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(255,255,255,.05)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#8a8a8a" }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#8a8a8a" }} tickLine={false} axisLine={false} allowDecimals={false} width={28} />
                <Tooltip contentStyle={{ background: "#111", border: "1px solid rgba(255,255,255,.08)", borderRadius: 12, fontSize: 12 }} />
                <Area type="monotone" dataKey="new_users" stroke="#C8A45C" fill="url(#g)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel title="Daily activity — events & active users">
          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.series}>
                <CartesianGrid stroke="rgba(255,255,255,.05)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#8a8a8a" }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#8a8a8a" }} tickLine={false} axisLine={false} allowDecimals={false} width={28} />
                <Tooltip contentStyle={{ background: "#111", border: "1px solid rgba(255,255,255,.08)", borderRadius: 12, fontSize: 12 }} />
                <Bar dataKey="events" fill="rgba(255,255,255,.25)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="active_users" fill="#C8A45C" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Panel title="Cross-product adoption">
          {data.cross?.distribution?.length ? (
            <ul className="space-y-2">
              {data.cross.distribution.map((d) => (
                <li key={d.products} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    {d.products} {d.products === 1 ? "product" : "products"}
                  </span>
                  <span className="tabular-nums">{num(d.users)} identities</span>
                </li>
              ))}
              {data.cross.overlaps?.length ? (
                <li className="pt-3 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Strongest overlaps</li>
              ) : null}
              {(data.cross.overlaps ?? []).slice(0, 5).map((o2) => (
                <li key={`${o2.product_a}-${o2.product_b}`} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{o2.product_a} ↔ {o2.product_b}</span>
                  <span className="tabular-nums">{num(o2.shared_users)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="No cross-product data yet." body="Adoption appears once products map identities through Onaru Connect." />
          )}
        </Panel>

        <Panel title="Live activity">
          {data.activity.length ? (
            <ul className="divide-y divide-border">
              {data.activity.map((e) => (
                <li key={e.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                  <span className="truncate">
                    <span className="text-muted-foreground">{productName(e.product_id)}</span>
                    <span className="mx-2 text-muted-foreground/40">—</span>
                    {e.event_name}
                  </span>
                  <span className="shrink-0 text-xs text-muted-foreground">{relativeTime(e.occurred_at)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="No events received yet." body="Real activity appears here the moment a connected product sends its first event." />
          )}
        </Panel>
      </div>
    </div>
  );
}
