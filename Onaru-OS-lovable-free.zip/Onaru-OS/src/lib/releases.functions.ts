import { anyDb } from "@/integrations/supabase/any-db";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * ONARU app download. Metadata and installers are never public: a signed-in
 * request is re-verified server side, then a short-lived signed URL is minted
 * for a private storage object. No storage credential reaches the browser.
 */

type Ctx = { supabase: any; userId: string }; // eslint-disable-line @typescript-eslint/no-explicit-any

export type AppRelease = {
  id: string;
  platform: string;
  version: string;
  build: string | null;
  channel: string;
  notes: string | null;
  file_size: number | null;
  released_at: string;
};

export const listAppReleases = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context as Ctx;
    const { data, error } = await supabase
      .from("app_releases")
      .select("id, platform, version, build, channel, notes, file_size, released_at")
      .eq("is_current", true)
      .order("released_at", { ascending: false });
    // A project that has not applied db/20260919_app_releases.sql yet should
    // render the portal, not an error page.
    if (error) return [] as AppRelease[];
    return (data ?? []) as AppRelease[];
  });

export const getAppDownloadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ releaseId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as Ctx;

    // RLS already scopes this read to signed-in users and current releases.
    const { data: release, error } = await supabase
      .from("app_releases")
      .select("id, platform, version, build, storage_path")
      .eq("id", data.releaseId)
      .eq("is_current", true)
      .maybeSingle();
    if (error || !release) throw new Error("Release not available");

    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
    const { data: signed, error: signError } = await supabaseAdmin.storage
      .from("releases")
      .createSignedUrl(release.storage_path, 120, { download: true });
    if (signError || !signed?.signedUrl) throw new Error("Could not prepare the download");

    await supabaseAdmin.from("onaru_audit_logs").insert({
      action: "app.download",
      actor_type: "user",
      actor_id: userId,
      resource_type: "app_release",
      resource_id: release.id,
      metadata: {
        platform: release.platform,
        version: release.version,
        build: release.build,
      },
    });

    return { url: signed.signedUrl, expiresIn: 120 };
  });
