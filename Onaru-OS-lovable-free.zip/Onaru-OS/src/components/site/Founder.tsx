import { Reveal } from "./Reveal";
import { FounderFrame } from "./Hero";

export function Founder() {
  return (
    <section id="founder" className="relative border-t border-border py-32 md:py-52">
      <div className="mx-auto grid max-w-[1400px] gap-16 px-6 md:px-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-24">
        <Reveal>
          <div className="lg:sticky lg:top-32">
            <FounderFrame tall />
          </div>
        </Reveal>

        <div>
          <Reveal>
            <p className="eyebrow">Meet The Founder</p>
            <h2 className="display-lg mt-6">Abayomi Onalaru</h2>
            <p className="mt-4 font-mono text-xs uppercase tracking-[0.28em] text-gold">
              CEO &amp; Founder
            </p>
          </Reveal>

          <div className="mt-12 space-y-7 text-[15px] leading-[1.85] text-muted-foreground md:text-[17px]">
            <Reveal delay={0.05}>
              <p>
                Abayomi began behind a camera. Years of photographing people, brands and
                spaces taught him something most business schools never do — that value is
                created in the details, and that the person who controls the system controls
                the outcome.
              </p>
            </Reveal>
            <Reveal delay={0.1}>
              <p>
                Freelancing had a ceiling. Every project ended, every invoice closed, and the
                work started again from zero. So he stopped selling hours and started
                building infrastructure: tools, studios, platforms and academies that keep
                working after the day ends.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <p>
                That shift became ONARU — a holding company built to spin up businesses that
                solve problems he has personally lived through. Operations software for
                African businesses. Creative spaces for people who cannot afford a studio of
                their own. Education for the next generation of operators. Media that tells
                the story properly.
              </p>
            </Reveal>
            <Reveal delay={0.2}>
              <p>
                The through-line is empowerment. African creators do not lack talent; they
                lack leverage. ONARU exists to hand them the machinery — and to keep building
                it for the next thirty years, not the next funding cycle.
              </p>
            </Reveal>
          </div>

          <Reveal delay={0.25}>
            <div className="mt-14 flex items-end gap-6 border-t border-border pt-10">
              <svg viewBox="0 0 220 80" className="h-16 w-auto text-gold" aria-hidden="true">
                <path
                  d="M8 58c14-30 24-42 30-38s-4 34 4 38 20-24 27-34 12-8 10 6-6 24 2 26 18-14 24-24 14-14 14-2-6 18 0 20 14-6 20-14"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />
              </svg>
              <div>
                <p className="text-sm tracking-tight text-foreground">Abayomi Onalaru</p>
                <p className="eyebrow mt-1">Lagos, Nigeria</p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
