import { supabase } from "@/integrations/supabase/client";

/**
 * Loosely-typed handle on the same authenticated client, used by the generic
 * CMS managers that address tables by name at runtime.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const db = supabase as any;

export type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
