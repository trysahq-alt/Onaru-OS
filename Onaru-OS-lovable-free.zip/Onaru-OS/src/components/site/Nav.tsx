import { useEffect, useState } from "react";
import { motion, useScroll, useSpring } from "motion/react";
import { Wordmark } from "./Wordmark";

const links = [
  { label: "Ecosystem", href: "#companies" },
  { label: "Model", href: "#model" },
  { label: "Founder", href: "#founder" },
  { label: "About", href: "#about" },
  { label: "Philosophy", href: "#philosophy" },
  { label: "Impact", href: "#impact" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<string>("#top");
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.3 });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const ids = links.map((l) => l.href.slice(1));
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(`#${visible.target.id}`);
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: [0, 0.25, 0.5, 1] },
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-700 ${
        scrolled ? "glass-panel border-x-0 border-t-0" : "border-transparent bg-transparent"
      }`}
      style={{ transitionTimingFunction: "var(--ease-lux)" }}
    >
      <nav
        className={`mx-auto grid max-w-[1400px] grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-6 transition-all duration-700 md:grid-cols-[1fr_auto_1fr] md:px-10 ${
          scrolled ? "h-16 md:h-[68px]" : "h-16 md:h-24"
        }`}
        style={{ transitionTimingFunction: "var(--ease-lux)" }}
      >
        <a
          href="#top"
          className="group min-w-0 text-sm text-foreground"
          aria-label="ONARU — back to top"
        >
          <span className="inline-block transition-opacity duration-500 group-hover:opacity-70">
            <Wordmark />
          </span>
        </a>

        <div className="hidden items-center justify-center gap-1 md:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className={`relative rounded-full px-4 py-2 text-[13px] transition-colors duration-500 hover:text-foreground ${
                active === l.href ? "text-foreground" : "text-muted-foreground"
              }`}
            >
              {active === l.href && (
                <motion.span
                  layoutId="nav-pill"
                  className="absolute inset-0 -z-10 rounded-full bg-foreground/[0.06] hairline"
                  transition={{ type: "spring", stiffness: 380, damping: 34 }}
                />
              )}
              {l.label}
            </a>
          ))}
        </div>

        <div className="flex items-center justify-end gap-3">
          <a href="/companies" className="btn-ghost hidden md:inline-flex">
            Companies
          </a>
          <a href="#contact" className="btn-gold hidden md:inline-flex">
            Contact
          </a>
          <button
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="flex h-10 w-10 shrink-0 flex-col items-center justify-center gap-1.5 md:hidden"
          >
            <span
              className={`h-px w-5 bg-foreground transition-transform duration-500 ${open ? "translate-y-[3px] rotate-45" : ""}`}
              style={{ transitionTimingFunction: "var(--ease-lux)" }}
            />
            <span
              className={`h-px w-5 bg-foreground transition-transform duration-500 ${open ? "-translate-y-[3px] -rotate-45" : ""}`}
              style={{ transitionTimingFunction: "var(--ease-lux)" }}
            />
          </button>
        </div>
      </nav>

      <motion.div
        className="h-px origin-left"
        style={{ scaleX: progress, background: "var(--gradient-gold)", opacity: scrolled ? 1 : 0 }}
      />

      <div
        className={`glass-panel overflow-hidden border-x-0 border-b-0 px-6 md:hidden ${
          open ? "max-h-[70vh] py-2" : "max-h-0 py-0"
        }`}
        style={{ transition: "max-height 700ms var(--ease-lux), padding 700ms var(--ease-lux)" }}
      >
        {links
          .concat({ label: "Our Companies", href: "/companies" })
          .concat({ label: "Contact", href: "#contact" })
          .map((l, i) => (
          <a
            key={l.href}
            href={l.href}
            onClick={() => setOpen(false)}
            className="block border-b border-border/60 py-4 text-lg tracking-tight text-foreground transition-colors duration-300 last:border-0 hover:text-gold"
            style={{
              opacity: open ? 1 : 0,
              transform: open ? "translateY(0)" : "translateY(8px)",
              transition: `opacity 600ms var(--ease-lux) ${i * 45}ms, transform 600ms var(--ease-lux) ${i * 45}ms`,
            }}
          >
            {l.label}
          </a>
        ))}
      </div>
    </header>
  );
}
