-- ONARU app download portal: release metadata + private installer storage.
-- Apply this to the ONARU Supabase project (SQL editor or `supabase db push`)
-- once the project is connected. It is additive and safe to re-run.

CREATE TABLE IF NOT EXISTS public.app_releases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  platform text NOT NULL,
  version text NOT NULL,
  build text,
  channel text NOT NULL DEFAULT 'stable',
  notes text,
  storage_path text NOT NULL,
  file_size bigint,
  is_current boolean NOT NULL DEFAULT true,
  released_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.app_releases TO authenticated;
GRANT ALL ON public.app_releases TO service_role;

ALTER TABLE public.app_releases ENABLE ROW LEVEL SECURITY;

-- Signed-in ONARU people may read current release metadata; never anonymous.
DROP POLICY IF EXISTS "Authenticated can read current releases" ON public.app_releases;
CREATE POLICY "Authenticated can read current releases"
  ON public.app_releases FOR SELECT TO authenticated
  USING (is_current);

DROP POLICY IF EXISTS "Admins manage releases" ON public.app_releases;
CREATE POLICY "Admins manage releases"
  ON public.app_releases FOR ALL TO authenticated
  USING (public.is_admin(auth.uid()))
  WITH CHECK (public.is_admin(auth.uid()));

-- Private installer bucket. No public URL; access is by short-lived signed URL only.
INSERT INTO storage.buckets (id, name, public)
VALUES ('releases', 'releases', false)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "Admins manage release files" ON storage.objects;
CREATE POLICY "Admins manage release files"
  ON storage.objects FOR ALL TO authenticated
  USING (bucket_id = 'releases' AND public.is_admin(auth.uid()))
  WITH CHECK (bucket_id = 'releases' AND public.is_admin(auth.uid()));
