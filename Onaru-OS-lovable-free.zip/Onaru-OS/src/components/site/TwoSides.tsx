import { Reveal } from "./Reveal";
import { companies, studioCapabilities } from "@/data/companies";

export function TwoSides() {
  return (
    <section id="model" className="relative border-t border-border py-32 md:py-52">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10">
        <Reveal>
          <p className="eyebrow">The Model</p>
          <h2 className="display-lg mt-6 max-w-[18ch]">
            We build. We operate. <span className="text-gold-gradient">We create.</span>
          </h2>
          <p className="mt-7 max-w-[60ch] text-[15px] leading-relaxed text-muted-foreground md:text-lg">
            ONARU is not only a creative agency. We build and run our own companies — and we put the
            same capability to work for a small number of external partners.
          </p>
        </Reveal>

        <div className="mt-16 grid gap-5 md:mt-24 lg:grid-cols-2">
          <Reveal>
            <div className="h-full rounded-[1.75rem] bg-card p-8 hairline md:p-10">
              <p className="eyebrow text-gold">01 — ONARU Companies</p>
              <h3 className="mt-5 text-2xl tracking-tight text-foreground md:text-3xl">
                Businesses and products we build and operate.
              </h3>
              <ul className="mt-8">
                {companies.map((c) => (
                  <li
                    key={c.slug}
                    className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 border-t border-border py-4"
                  >
                    <span className="truncate text-[15px] text-foreground">{c.name}</span>
                    <span className="shrink-0 text-[13px] text-muted-foreground">{c.label}</span>
                  </li>
                ))}
              </ul>
              <a href="/companies" className="btn-ghost mt-8 inline-flex">
                Our companies →
              </a>
            </div>
          </Reveal>

          <Reveal delay={0.08}>
            <div className="h-full rounded-[1.75rem] bg-card p-8 hairline md:p-10">
              <p className="eyebrow text-gold">02 — ONARU Studio</p>
              <h3 className="mt-5 text-2xl tracking-tight text-foreground md:text-3xl">
                Capabilities we provide to external companies and clients.
              </h3>
              <ul className="mt-8">
                {studioCapabilities.map((s) => (
                  <li key={s.title} className="border-t border-border py-4">
                    <p className="text-[15px] text-foreground">{s.title}</p>
                    <p className="mt-1.5 max-w-[46ch] text-[13px] leading-relaxed text-muted-foreground">
                      {s.body}
                    </p>
                  </li>
                ))}
              </ul>
              <a href="#contact" className="btn-ghost mt-8 inline-flex">
                Start a project →
              </a>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
