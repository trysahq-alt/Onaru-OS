import { Reveal } from "./Reveal";

const chapters = [
  {
    tag: "The Beginning",
    year: "2016 — 2020",
    title: "A camera and a question",
    body: "Years of client work across brands, weddings and campaigns exposed the same gap everywhere: talent was abundant, systems were not. Businesses ran on WhatsApp threads and memory.",
  },
  {
    tag: "Today",
    year: "2021 — 2026",
    title: "From services to structures",
    body: "ONARU was formed to hold and build the answers — software, studios, education, media and consumer brands, each staffed by small teams and connected by shared infrastructure.",
  },
  {
    tag: "The Future",
    year: "2027 →",
    title: "A continental operating layer",
    body: "The ambition is a group of durable African companies that outlive their founders: profitable, well-governed, and useful to millions of people who create and trade every day.",
  },
];

export function About() {
  return (
    <section id="about" className="relative border-t border-border py-32 md:py-52">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10">
        <Reveal>
          <p className="eyebrow">About ONARU</p>
          <h2 className="display-lg mt-6 max-w-[20ch]">
            Why a holding company, and why now.
          </h2>
        </Reveal>

        <div className="mt-20 md:mt-28">
          {chapters.map((c, i) => (
            <Reveal key={c.tag} delay={i * 0.08}>
              <div className="group relative grid gap-6 border-t border-border py-12 md:grid-cols-[200px_1fr_1.1fr] md:gap-12 md:py-16">
                <span
                  className="absolute left-0 top-0 h-px w-0 transition-[width] duration-1000 group-hover:w-full"
                  style={{
                    background: "var(--gradient-gold)",
                    transitionTimingFunction: "var(--ease-lux)",
                  }}
                />
                <div>
                  <p className="eyebrow text-gold">{c.tag}</p>
                  <p className="mt-3 font-mono text-xs text-muted-foreground">{c.year}</p>
                </div>
                <h3 className="text-2xl leading-tight tracking-tight text-foreground md:text-3xl">
                  {c.title}
                </h3>
                <p className="max-w-[52ch] text-[15px] leading-[1.85] text-muted-foreground">
                  {c.body}
                </p>
              </div>
            </Reveal>
          ))}
          <div className="border-t border-border" />
        </div>
      </div>
    </section>
  );
}
