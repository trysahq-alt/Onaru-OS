import { anyDb } from "@/integrations/supabase/any-db";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const FOUNDER_EMAIL = "yomionalaru@gmail.com";

export type AppRole =
  | "super_admin"
  | "admin"
  | "editor"
  | "writer"
  | "marketing"
  | "support"
  | "viewer";

/**
 * Called right after sign-in. Makes sure a profile row exists and grants the
 * founder account super_admin on first login.
 */
export const bootstrapAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
    const userId = context.userId;
    const email = String(context.claims.email ?? "").toLowerCase();
    const meta = (context.claims.user_metadata ?? {}) as Record<string, unknown>;

    await supabaseAdmin.from("profiles").upsert(
      {
        id: userId,
        email,
        full_name: (meta.full_name as string) ?? (meta.name as string) ?? email.split("@")[0],
        avatar_url: (meta.avatar_url as string) ?? null,
      },
      { onConflict: "id" },
    );

    const { data: existing } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);

    if ((!existing || existing.length === 0) && email === FOUNDER_EMAIL) {
      await supabaseAdmin.from("user_roles").insert({ user_id: userId, role: "super_admin" });
    }

    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);

    return {
      userId,
      email,
      roles: (roles ?? []).map((r) => r.role as AppRole),
    };
  });

export const listTeam = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await anyDb(context.supabase).rpc("is_admin", { _user_id: context.userId });
    if (!isAdmin) throw new Error("Forbidden");
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);

    const [{ data: profiles }, { data: roles }] = await Promise.all([
      supabaseAdmin.from("profiles").select("*").order("created_at", { ascending: true }),
      supabaseAdmin.from("user_roles").select("user_id, role"),
    ]);

    return (profiles ?? []).map((p) => ({
      ...p,
      roles: (roles ?? []).filter((r) => r.user_id === p.id).map((r) => r.role as AppRole),
    }));
  });

export const inviteTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        email: z.string().trim().email().max(255),
        role: z.enum([
          "super_admin",
          "admin",
          "editor",
          "writer",
          "marketing",
          "support",
          "viewer",
        ]),
        fullName: z.string().trim().max(120).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await anyDb(context.supabase).rpc("is_admin", { _user_id: context.userId });
    if (!isAdmin) throw new Error("Forbidden");
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);

    const { data: invited, error } =
      await supabaseAdmin.auth.admin.inviteUserByEmail(data.email);
    if (error || !invited?.user) throw new Error(error?.message ?? "Could not invite user");

    await supabaseAdmin.from("profiles").upsert(
      { id: invited.user.id, email: data.email, full_name: data.fullName ?? null },
      { onConflict: "id" },
    );
    await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: invited.user.id, role: data.role }, { onConflict: "user_id,role" });

    return { ok: true };
  });

export const setTeamRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        userId: z.string().uuid(),
        role: z.enum([
          "super_admin",
          "admin",
          "editor",
          "writer",
          "marketing",
          "support",
          "viewer",
        ]),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await anyDb(context.supabase).rpc("is_admin", { _user_id: context.userId });
    if (!isAdmin) throw new Error("Forbidden");
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);

    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
    await supabaseAdmin.from("user_roles").insert({ user_id: data.userId, role: data.role });
    return { ok: true };
  });

export const setTeamStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ userId: z.string().uuid(), status: z.enum(["active", "suspended"]) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await anyDb(context.supabase).rpc("is_admin", { _user_id: context.userId });
    if (!isAdmin) throw new Error("Forbidden");
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);

    await supabaseAdmin.from("profiles").update({ status: data.status }).eq("id", data.userId);
    await supabaseAdmin.auth.admin.updateUserById(data.userId, {
      ban_duration: data.status === "suspended" ? "876000h" : "none",
    });
    return { ok: true };
  });

export const removeTeamMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ userId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await anyDb(context.supabase).rpc("is_admin", { _user_id: context.userId });
    if (!isAdmin) throw new Error("Forbidden");
    if (data.userId === context.userId) throw new Error("You cannot remove your own account");
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);

    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
    await supabaseAdmin.from("profiles").delete().eq("id", data.userId);
    await supabaseAdmin.auth.admin.deleteUser(data.userId);
    return { ok: true };
  });
