import { anyDb } from "@/integrations/supabase/any-db";
/**
 * ONARU CORE — server-only primitives shared by Onaru Connect (the product API)
 * and Onaru HQ. Never import this from client-reachable modules at top level.
 */

export const ONARU_SCOPES = [
  "identity:read",
  "identity:write",
  "events:write",
  "organizations:read",
  "organizations:write",
  "memberships:write",
] as const;

export type OnaruScope = (typeof ONARU_SCOPES)[number];

export const MAX_EVENT_BYTES = 32 * 1024;
export const MAX_BATCH_EVENTS = 200;
export const RATE_LIMIT_PER_MINUTE = 600;

/** Property names whose values are never persisted. */
const SENSITIVE_KEY = /(password|passwd|secret|token|api[_-]?key|authorization|auth|credential|private[_-]?key|session|cookie|otp|pin|cvv|card[_-]?number|ssn|bvn)/i;

export function sanitizeProperties(input: unknown, depth = 0): Record<string, unknown> {
  if (depth > 6 || input === null || typeof input !== "object" || Array.isArray(input)) return {};
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
    if (SENSITIVE_KEY.test(key)) {
      out[key] = "[redacted]";
      continue;
    }
    if (value && typeof value === "object" && !Array.isArray(value)) {
      out[key] = sanitizeProperties(value, depth + 1);
    } else if (Array.isArray(value)) {
      out[key] = value.slice(0, 100).map((v) =>
        v && typeof v === "object" ? sanitizeProperties(v, depth + 1) : v,
      );
    } else {
      out[key] = value;
    }
  }
  return out;
}

function toHex(buffer: ArrayBuffer) {
  return [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function hashSecret(secret: string): Promise<string> {
  const data = new TextEncoder().encode(secret);
  return toHex(await crypto.subtle.digest("SHA-256", data));
}

export function timingSafeEqualHex(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function randomToken(bytes: number) {
  const buf = new Uint8Array(bytes);
  crypto.getRandomValues(buf);
  return [...buf].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** Generates a credential pair. The full secret is returned exactly once. */
export function generateCredential(environment: string) {
  const envTag = environment === "production" ? "live" : environment === "staging" ? "stg" : "dev";
  const keyPrefix = `onaru_${envTag}_${randomToken(6)}`;
  const secret = randomToken(32);
  return { keyPrefix, secret, fullKey: `${keyPrefix}.${secret}` };
}

export type AuthedClient = {
  id: string;
  product_id: string;
  environment: "development" | "staging" | "production";
  scopes: string[];
};

export type ConnectError = { status: number; error: string };

/**
 * Authenticates a server-to-server request from a connected product.
 * Expects `Authorization: Bearer <key_prefix>.<secret>`.
 */
export async function authenticateApiClient(
  request: Request,
): Promise<{ client: AuthedClient } | { failure: ConnectError }> {
  const header = request.headers.get("authorization") ?? "";
  if (!header.startsWith("Bearer ")) {
    return { failure: { status: 401, error: "Missing bearer credentials" } };
  }
  const raw = header.slice(7).trim();
  const sep = raw.indexOf(".");
  if (sep <= 0) return { failure: { status: 401, error: "Malformed credentials" } };

  const keyPrefix = raw.slice(0, sep);
  const secret = raw.slice(sep + 1);

  const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
  const { data: client } = await supabaseAdmin
    .from("onaru_api_clients")
    .select("id, product_id, environment, scopes, status, secret_hash, expires_at")
    .eq("key_prefix", keyPrefix)
    .maybeSingle();

  if (!client) return { failure: { status: 401, error: "Invalid credentials" } };
  if (client.status !== "active") return { failure: { status: 403, error: "Credential revoked" } };
  if (client.expires_at && new Date(client.expires_at) < new Date()) {
    return { failure: { status: 403, error: "Credential expired" } };
  }

  const presented = await hashSecret(secret);
  if (!timingSafeEqualHex(presented, client.secret_hash)) {
    return { failure: { status: 401, error: "Invalid credentials" } };
  }

  // Rate limiting, per credential, per rolling minute.
  const since = new Date(Date.now() - 60_000).toISOString();
  const { count } = await supabaseAdmin
    .from("onaru_api_requests")
    .select("id", { count: "exact", head: true })
    .eq("api_client_id", client.id)
    .gte("created_at", since);
  if ((count ?? 0) >= RATE_LIMIT_PER_MINUTE) {
    return { failure: { status: 429, error: "Rate limit exceeded" } };
  }

  await supabaseAdmin
    .from("onaru_api_clients")
    .update({ last_used_at: new Date().toISOString() })
    .eq("id", client.id);

  return {
    client: {
      id: client.id,
      product_id: client.product_id,
      environment: client.environment,
      scopes: Array.isArray(client.scopes) ? (client.scopes as string[]) : [],
    },
  };
}

export function hasScope(client: AuthedClient, scope: OnaruScope) {
  return client.scopes.includes(scope);
}

export async function logApiRequest(args: {
  clientId?: string | null;
  productId?: string | null;
  endpoint: string;
  status: number;
  error?: string | null;
  ip?: string | null;
}) {
  const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
  await supabaseAdmin.from("onaru_api_requests").insert({
    api_client_id: args.clientId ?? null,
    product_id: args.productId ?? null,
    endpoint: args.endpoint,
    status_code: args.status,
    error: args.error ?? null,
    ip: args.ip ?? null,
  });
}

export async function writeAudit(args: {
  actorType?: string;
  actorId?: string | null;
  actorLabel?: string | null;
  action: string;
  resourceType?: string;
  resourceId?: string | null;
  metadata?: Record<string, unknown>;
  ip?: string | null;
  userAgent?: string | null;
}) {
  const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
  await supabaseAdmin.from("onaru_audit_logs").insert({
    actor_type: args.actorType ?? "admin",
    actor_id: args.actorId ?? null,
    actor_label: args.actorLabel ?? null,
    action: args.action,
    resource_type: args.resourceType ?? null,
    resource_id: args.resourceId ?? null,
    metadata: (args.metadata ?? {}) as never,
    ip: args.ip ?? null,
    user_agent: args.userAgent ?? null,
  });
}
