
-- ===== Enums =====
CREATE TYPE public.onaru_environment AS ENUM ('development','staging','production');
CREATE TYPE public.onaru_product_status AS ENUM ('active','beta','disabled');
CREATE TYPE public.onaru_user_status AS ENUM ('active','suspended','deleted','pending');
CREATE TYPE public.onaru_link_status AS ENUM ('pending','verified','rejected','expired','unlinked');

-- ===== Helper: HQ authorization =====
CREATE OR REPLACE FUNCTION public.is_onaru_hq(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('super_admin','admin'));
$$;

-- ===== Identities =====
CREATE TABLE public.onaru_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_user_id uuid UNIQUE,
  primary_email text NOT NULL,
  phone text,
  first_name text,
  last_name text,
  display_name text,
  avatar_url text,
  country text,
  timezone text,
  status public.onaru_user_status NOT NULL DEFAULT 'active',
  email_verified boolean NOT NULL DEFAULT false,
  phone_verified boolean NOT NULL DEFAULT false,
  identity_verified boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz
);
CREATE UNIQUE INDEX onaru_users_primary_email_key ON public.onaru_users (lower(primary_email));
CREATE INDEX onaru_users_phone_idx ON public.onaru_users (phone);
CREATE INDEX onaru_users_created_at_idx ON public.onaru_users (created_at DESC);
CREATE INDEX onaru_users_last_seen_idx ON public.onaru_users (last_seen_at DESC);
GRANT SELECT ON public.onaru_users TO authenticated;
GRANT ALL ON public.onaru_users TO service_role;
ALTER TABLE public.onaru_users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads identities" ON public.onaru_users FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()) OR auth_user_id = auth.uid());

-- ===== Organizations =====
CREATE TABLE public.onaru_organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  logo_url text,
  organization_type text NOT NULL DEFAULT 'business',
  country text,
  status text NOT NULL DEFAULT 'active',
  owner_user_id uuid REFERENCES public.onaru_users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX onaru_orgs_owner_idx ON public.onaru_organizations (owner_user_id);
GRANT SELECT ON public.onaru_organizations TO authenticated;
GRANT ALL ON public.onaru_organizations TO service_role;
ALTER TABLE public.onaru_organizations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads organizations" ON public.onaru_organizations FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

CREATE TABLE public.onaru_organization_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES public.onaru_organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.onaru_users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member',
  permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'active',
  joined_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, user_id)
);
CREATE INDEX onaru_org_members_user_idx ON public.onaru_organization_members (user_id);
GRANT SELECT ON public.onaru_organization_members TO authenticated;
GRANT ALL ON public.onaru_organization_members TO service_role;
ALTER TABLE public.onaru_organization_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads org members" ON public.onaru_organization_members FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

-- ===== Products =====
CREATE TABLE public.onaru_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  description text,
  logo_url text,
  environment public.onaru_environment NOT NULL DEFAULT 'development',
  status public.onaru_product_status NOT NULL DEFAULT 'beta',
  api_identifier text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.onaru_products TO authenticated;
GRANT ALL ON public.onaru_products TO service_role;
ALTER TABLE public.onaru_products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads products" ON public.onaru_products FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

CREATE TABLE public.onaru_product_memberships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.onaru_users(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.onaru_products(id) ON DELETE CASCADE,
  external_user_id text,
  role text NOT NULL DEFAULT 'user',
  status text NOT NULL DEFAULT 'active',
  joined_at timestamptz NOT NULL DEFAULT now(),
  last_active_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, product_id)
);
CREATE UNIQUE INDEX onaru_pm_external_key ON public.onaru_product_memberships (product_id, external_user_id) WHERE external_user_id IS NOT NULL;
CREATE INDEX onaru_pm_product_idx ON public.onaru_product_memberships (product_id, last_active_at DESC);
CREATE INDEX onaru_pm_user_idx ON public.onaru_product_memberships (user_id);
GRANT SELECT ON public.onaru_product_memberships TO authenticated;
GRANT ALL ON public.onaru_product_memberships TO service_role;
ALTER TABLE public.onaru_product_memberships ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads memberships" ON public.onaru_product_memberships FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

-- ===== Account linking =====
CREATE TABLE public.onaru_identity_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  primary_user_id uuid NOT NULL REFERENCES public.onaru_users(id) ON DELETE CASCADE,
  candidate_user_id uuid REFERENCES public.onaru_users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.onaru_products(id) ON DELETE SET NULL,
  external_user_id text,
  email text,
  status public.onaru_link_status NOT NULL DEFAULT 'pending',
  verification_token_hash text,
  requested_by text NOT NULL DEFAULT 'system',
  expires_at timestamptz,
  verified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX onaru_links_primary_idx ON public.onaru_identity_links (primary_user_id);
CREATE INDEX onaru_links_status_idx ON public.onaru_identity_links (status, created_at DESC);
GRANT SELECT ON public.onaru_identity_links TO authenticated;
GRANT ALL ON public.onaru_identity_links TO service_role;
ALTER TABLE public.onaru_identity_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads identity links" ON public.onaru_identity_links FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

-- ===== Events =====
CREATE TABLE public.onaru_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_name text NOT NULL,
  product_id uuid NOT NULL REFERENCES public.onaru_products(id) ON DELETE CASCADE,
  user_id uuid REFERENCES public.onaru_users(id) ON DELETE SET NULL,
  organization_id uuid REFERENCES public.onaru_organizations(id) ON DELETE SET NULL,
  external_user_id text,
  external_event_id text,
  session_id text,
  event_version integer NOT NULL DEFAULT 1,
  properties jsonb NOT NULL DEFAULT '{}'::jsonb,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  received_at timestamptz NOT NULL DEFAULT now(),
  environment public.onaru_environment NOT NULL DEFAULT 'production'
);
CREATE UNIQUE INDEX onaru_events_idempotency ON public.onaru_events (product_id, external_event_id) WHERE external_event_id IS NOT NULL;
CREATE INDEX onaru_events_product_time_idx ON public.onaru_events (product_id, occurred_at DESC);
CREATE INDEX onaru_events_name_time_idx ON public.onaru_events (event_name, occurred_at DESC);
CREATE INDEX onaru_events_user_time_idx ON public.onaru_events (user_id, occurred_at DESC);
CREATE INDEX onaru_events_org_time_idx ON public.onaru_events (organization_id, occurred_at DESC);
CREATE INDEX onaru_events_time_idx ON public.onaru_events (occurred_at DESC);
CREATE INDEX onaru_events_props_idx ON public.onaru_events USING gin (properties);
GRANT SELECT ON public.onaru_events TO authenticated;
GRANT ALL ON public.onaru_events TO service_role;
ALTER TABLE public.onaru_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads events" ON public.onaru_events FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

-- ===== API clients =====
CREATE TABLE public.onaru_api_clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.onaru_products(id) ON DELETE CASCADE,
  name text NOT NULL,
  key_prefix text NOT NULL UNIQUE,
  secret_hash text NOT NULL,
  environment public.onaru_environment NOT NULL DEFAULT 'development',
  scopes jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'active',
  last_used_at timestamptz,
  expires_at timestamptz,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX onaru_api_clients_product_idx ON public.onaru_api_clients (product_id);
GRANT ALL ON public.onaru_api_clients TO service_role;
ALTER TABLE public.onaru_api_clients ENABLE ROW LEVEL SECURITY;
-- no authenticated grants: secrets metadata is only reachable through trusted server code

-- ===== API request log (rate limiting + usage) =====
CREATE TABLE public.onaru_api_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  api_client_id uuid REFERENCES public.onaru_api_clients(id) ON DELETE SET NULL,
  product_id uuid REFERENCES public.onaru_products(id) ON DELETE SET NULL,
  endpoint text NOT NULL,
  status_code integer NOT NULL,
  error text,
  ip text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX onaru_api_requests_client_time_idx ON public.onaru_api_requests (api_client_id, created_at DESC);
CREATE INDEX onaru_api_requests_time_idx ON public.onaru_api_requests (created_at DESC);
GRANT SELECT ON public.onaru_api_requests TO authenticated;
GRANT ALL ON public.onaru_api_requests TO service_role;
ALTER TABLE public.onaru_api_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads api requests" ON public.onaru_api_requests FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

-- ===== Audit logs =====
CREATE TABLE public.onaru_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_type text NOT NULL DEFAULT 'admin',
  actor_id text,
  actor_label text,
  action text NOT NULL,
  resource_type text,
  resource_id text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip text,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX onaru_audit_time_idx ON public.onaru_audit_logs (created_at DESC);
CREATE INDEX onaru_audit_action_idx ON public.onaru_audit_logs (action, created_at DESC);
GRANT SELECT ON public.onaru_audit_logs TO authenticated;
GRANT ALL ON public.onaru_audit_logs TO service_role;
ALTER TABLE public.onaru_audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads audit logs" ON public.onaru_audit_logs FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

-- ===== Privacy =====
CREATE TABLE public.onaru_consents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.onaru_users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.onaru_products(id) ON DELETE SET NULL,
  consent_type text NOT NULL,
  granted boolean NOT NULL DEFAULT true,
  source text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX onaru_consents_user_idx ON public.onaru_consents (user_id);
GRANT SELECT ON public.onaru_consents TO authenticated;
GRANT ALL ON public.onaru_consents TO service_role;
ALTER TABLE public.onaru_consents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads consents" ON public.onaru_consents FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

CREATE TABLE public.onaru_data_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.onaru_users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.onaru_products(id) ON DELETE SET NULL,
  request_type text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  notes text,
  requested_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX onaru_data_requests_status_idx ON public.onaru_data_requests (status, requested_at DESC);
GRANT SELECT ON public.onaru_data_requests TO authenticated;
GRANT ALL ON public.onaru_data_requests TO service_role;
ALTER TABLE public.onaru_data_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "HQ reads data requests" ON public.onaru_data_requests FOR SELECT TO authenticated USING (public.is_onaru_hq(auth.uid()));

-- ===== updated_at triggers =====
CREATE TRIGGER trg_onaru_users_updated BEFORE UPDATE ON public.onaru_users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_onaru_orgs_updated BEFORE UPDATE ON public.onaru_organizations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_onaru_org_members_updated BEFORE UPDATE ON public.onaru_organization_members FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_onaru_products_updated BEFORE UPDATE ON public.onaru_products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_onaru_pm_updated BEFORE UPDATE ON public.onaru_product_memberships FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_onaru_links_updated BEFORE UPDATE ON public.onaru_identity_links FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_onaru_api_clients_updated BEFORE UPDATE ON public.onaru_api_clients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_onaru_consents_updated BEFORE UPDATE ON public.onaru_consents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_onaru_data_requests_updated BEFORE UPDATE ON public.onaru_data_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ===== Analytics functions (HQ only, security definer with guard) =====
CREATE OR REPLACE FUNCTION public.onaru_hq_overview()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE result jsonb;
BEGIN
  IF NOT public.is_onaru_hq(auth.uid()) THEN RAISE EXCEPTION 'Forbidden'; END IF;
  SELECT jsonb_build_object(
    'total_identities', (SELECT count(*) FROM onaru_users),
    'new_today', (SELECT count(*) FROM onaru_users WHERE created_at >= date_trunc('day', now())),
    'new_this_week', (SELECT count(*) FROM onaru_users WHERE created_at >= now() - interval '7 days'),
    'new_prev_week', (SELECT count(*) FROM onaru_users WHERE created_at >= now() - interval '14 days' AND created_at < now() - interval '7 days'),
    'mau', (SELECT count(DISTINCT user_id) FROM onaru_events WHERE user_id IS NOT NULL AND occurred_at >= now() - interval '30 days'),
    'dau', (SELECT count(DISTINCT user_id) FROM onaru_events WHERE user_id IS NOT NULL AND occurred_at >= date_trunc('day', now())),
    'connected_products', (SELECT count(*) FROM onaru_products),
    'active_products', (SELECT count(*) FROM onaru_products WHERE status = 'active'),
    'active_organizations', (SELECT count(*) FROM onaru_organizations WHERE status = 'active'),
    'events_today', (SELECT count(*) FROM onaru_events WHERE occurred_at >= date_trunc('day', now())),
    'events_30d', (SELECT count(*) FROM onaru_events WHERE occurred_at >= now() - interval '30 days'),
    'revenue_events_30d', (SELECT count(*) FROM onaru_events WHERE event_name IN ('payment.received','subscription.started') AND occurred_at >= now() - interval '30 days'),
    'revenue_amount_30d', (SELECT coalesce(sum((properties->>'amount')::numeric), 0) FROM onaru_events WHERE event_name = 'payment.received' AND occurred_at >= now() - interval '30 days' AND (properties->>'amount') ~ '^[0-9]+(\.[0-9]+)?$'),
    'bookings_30d', (SELECT count(*) FROM onaru_events WHERE event_name LIKE 'booking.%' AND occurred_at >= now() - interval '30 days'),
    'subscriptions_active', (SELECT count(*) FROM onaru_events WHERE event_name = 'subscription.started') - (SELECT count(*) FROM onaru_events WHERE event_name = 'subscription.cancelled')
  ) INTO result;
  RETURN result;
END; $$;

CREATE OR REPLACE FUNCTION public.onaru_hq_timeseries(_days integer DEFAULT 30)
RETURNS TABLE (day date, new_users bigint, events bigint, active_users bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_onaru_hq(auth.uid()) THEN RAISE EXCEPTION 'Forbidden'; END IF;
  RETURN QUERY
  WITH days AS (
    SELECT generate_series(date_trunc('day', now()) - ((_days - 1) || ' days')::interval, date_trunc('day', now()), '1 day')::date AS d
  )
  SELECT d,
    (SELECT count(*) FROM onaru_users u WHERE u.created_at::date = d),
    (SELECT count(*) FROM onaru_events e WHERE e.occurred_at::date = d),
    (SELECT count(DISTINCT e.user_id) FROM onaru_events e WHERE e.occurred_at::date = d AND e.user_id IS NOT NULL)
  FROM days ORDER BY d;
END; $$;

CREATE OR REPLACE FUNCTION public.onaru_hq_cross_product()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE result jsonb;
BEGIN
  IF NOT public.is_onaru_hq(auth.uid()) THEN RAISE EXCEPTION 'Forbidden'; END IF;
  SELECT jsonb_build_object(
    'distribution', (
      SELECT coalesce(jsonb_agg(jsonb_build_object('products', products, 'users', users) ORDER BY products), '[]'::jsonb)
      FROM (
        SELECT c.products, count(*)::bigint AS users FROM (
          SELECT user_id, count(DISTINCT product_id) AS products FROM onaru_product_memberships GROUP BY user_id
        ) c GROUP BY c.products
      ) t
    ),
    'overlaps', (
      SELECT coalesce(jsonb_agg(x ORDER BY (x->>'shared_users')::bigint DESC), '[]'::jsonb) FROM (
        SELECT jsonb_build_object('product_a', pa.name, 'product_b', pb.name, 'shared_users', count(*)::bigint) AS x
        FROM onaru_product_memberships ma
        JOIN onaru_product_memberships mb ON ma.user_id = mb.user_id AND ma.product_id < mb.product_id
        JOIN onaru_products pa ON pa.id = ma.product_id
        JOIN onaru_products pb ON pb.id = mb.product_id
        GROUP BY pa.name, pb.name
        LIMIT 20
      ) o
    )
  ) INTO result;
  RETURN result;
END; $$;

CREATE OR REPLACE FUNCTION public.onaru_hq_product_stats()
RETURNS TABLE (
  product_id uuid, name text, slug text, status public.onaru_product_status,
  environment public.onaru_environment, users bigint, active_users_30d bigint,
  organizations bigint, events_30d bigint, events_prev_30d bigint,
  revenue_30d numeric, last_activity_at timestamptz
) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_onaru_hq(auth.uid()) THEN RAISE EXCEPTION 'Forbidden'; END IF;
  RETURN QUERY
  SELECT p.id, p.name, p.slug, p.status, p.environment,
    (SELECT count(*) FROM onaru_product_memberships m WHERE m.product_id = p.id),
    (SELECT count(DISTINCT e.user_id) FROM onaru_events e WHERE e.product_id = p.id AND e.user_id IS NOT NULL AND e.occurred_at >= now() - interval '30 days'),
    (SELECT count(DISTINCT e.organization_id) FROM onaru_events e WHERE e.product_id = p.id AND e.organization_id IS NOT NULL),
    (SELECT count(*) FROM onaru_events e WHERE e.product_id = p.id AND e.occurred_at >= now() - interval '30 days'),
    (SELECT count(*) FROM onaru_events e WHERE e.product_id = p.id AND e.occurred_at >= now() - interval '60 days' AND e.occurred_at < now() - interval '30 days'),
    (SELECT coalesce(sum((e.properties->>'amount')::numeric),0) FROM onaru_events e WHERE e.product_id = p.id AND e.event_name = 'payment.received' AND e.occurred_at >= now() - interval '30 days' AND (e.properties->>'amount') ~ '^[0-9]+(\.[0-9]+)?$'),
    (SELECT max(e.occurred_at) FROM onaru_events e WHERE e.product_id = p.id)
  FROM onaru_products p ORDER BY p.created_at;
END; $$;
