import { Reveal } from "./Reveal";
import { OnaruMark } from "./Wordmark";

export function Contact() {
  return (
    <section id="contact" className="relative border-t border-border py-32 md:py-52">
      <div className="mx-auto grid max-w-[1400px] gap-16 px-6 md:px-10 lg:grid-cols-2 lg:gap-24">
        <Reveal>
          <p className="eyebrow">Contact</p>
          <h2 className="display-lg mt-6 max-w-[14ch]">Let's start a conversation.</h2>
          <dl className="mt-14 space-y-8">
            {[
              { k: "Email", v: "hello@onaru.com" },
              { k: "LinkedIn", v: "/company/onaru" },
              { k: "Instagram", v: "@onaru" },
              { k: "Office", v: "Lagos, Nigeria" },
            ].map((row) => (
              <div key={row.k} className="border-b border-border pb-5">
                <dt className="eyebrow">{row.k}</dt>
                <dd className="mt-2 text-lg tracking-tight text-foreground">{row.v}</dd>
              </div>
            ))}
          </dl>
        </Reveal>

        <Reveal delay={0.1}>
          <form
            className="rounded-[1.5rem] bg-card p-8 hairline md:p-10"
            onSubmit={(e) => e.preventDefault()}
          >
            {[
              { id: "name", label: "Name", type: "text" },
              { id: "email", label: "Email", type: "email" },
              { id: "company", label: "Company", type: "text" },
            ].map((f) => (
              <div key={f.id} className="mb-7">
                <label htmlFor={f.id} className="eyebrow">
                  {f.label}
                </label>
                <input
                  id={f.id}
                  type={f.type}
                  className="mt-3 w-full border-b border-border bg-transparent pb-3 text-[15px] text-foreground outline-none transition-colors duration-500 focus:border-gold"
                />
              </div>
            ))}
            <div className="mb-9">
              <label htmlFor="message" className="eyebrow">
                Message
              </label>
              <textarea
                id="message"
                rows={4}
                className="mt-3 w-full resize-none border-b border-border bg-transparent pb-3 text-[15px] text-foreground outline-none transition-colors duration-500 focus:border-gold"
              />
            </div>
            <button
              type="submit"
              className="inline-flex items-center gap-3 rounded-full px-7 py-3.5 text-[14px] font-medium text-accent-foreground"
              style={{ background: "var(--gradient-gold)" }}
            >
              Send Message →
            </button>
          </form>
        </Reveal>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-border py-16 md:py-20">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10">
        <div className="flex flex-col gap-12 md:flex-row md:items-start md:justify-between">
          <div>
            <span className="inline-flex items-center gap-3 text-foreground">
              <OnaruMark className="h-7 w-7 text-gold" />
              <span className="wordmark text-sm">Onaru</span>
            </span>
            <p className="mt-5 max-w-[34ch] text-[13px] leading-relaxed text-muted-foreground">
              A venture holding company building technology, media, education and creative
              businesses across Africa.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-12 sm:grid-cols-3">
            {[
              {
                title: "Company",
                items: ["Companies", "Founder", "About", "Philosophy"],
              },
              { title: "Resources", items: ["Newsroom", "Careers", "Media Kit", "Investors"] },
              { title: "Legal", items: ["Privacy", "Terms", "Governance"] },
            ].map((col) => (
              <div key={col.title}>
                <p className="eyebrow">{col.title}</p>
                <ul className="mt-5 space-y-3">
                  {col.items.map((it) => (
                    <li key={it}>
                      <a
                        href={`#${it.toLowerCase().replace(/\s+/g, "-")}`}
                        className="text-[13px] text-muted-foreground transition-colors duration-300 hover:text-foreground"
                      >
                        {it}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-3 border-t border-border pt-8 sm:flex-row sm:items-center sm:justify-between">
          <p className="font-mono text-[11px] tracking-wider text-muted-foreground">
            © {new Date().getFullYear()} ONARU LIMITED. All rights reserved.
          </p>
          <p className="font-mono text-[11px] tracking-wider text-muted-foreground">
            Lagos · Africa · Worldwide
          </p>
        </div>
      </div>
    </footer>
  );
}
