import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { hqUsers } from "@/lib/hq.functions";
import { Panel, Empty, Tag, relativeTime } from "@/components/hq/ui";

export const Route = createFileRoute("/_authenticated/hq/users/")({ component: HQUsers });

function HQUsers() {
  const [query, setQuery] = useState("");
  const [applied, setApplied] = useState("");
  const fetchUsers = useServerFn(hqUsers);
  const { data, isLoading } = useQuery({
    queryKey: ["hq", "users", applied],
    queryFn: () => fetchUsers({ data: { query: applied || undefined } }),
  });

  return (
    <div className="space-y-6">
      <header>
        <p className="text-[10px] uppercase tracking-[0.3em] text-gold">Onaru ID</p>
        <h1 className="mt-2 text-2xl font-semibold sm:text-3xl">Identities</h1>
      </header>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          setApplied(query);
        }}
        className="flex gap-2"
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search name, email, phone, Onaru ID or external product ID"
          className="w-full rounded-xl border border-border bg-card/40 px-4 py-2.5 text-sm outline-none focus:border-gold/40"
        />
        <button className="rounded-xl bg-gold px-4 text-xs font-medium text-black">Search</button>
      </form>

      <Panel>
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Searching…</p>
        ) : (data ?? []).length ? (
          <ul className="divide-y divide-border">
            {(data ?? []).map((u) => (
              <li key={u.id}>
                <Link to="/hq/users/$id" params={{ id: u.id }} className="flex items-center justify-between gap-3 py-3">
                  <span className="min-w-0">
                    <span className="block truncate text-sm">{u.display_name || `${u.first_name ?? ""} ${u.last_name ?? ""}`.trim() || u.primary_email}</span>
                    <span className="block truncate text-xs text-muted-foreground">{u.primary_email}</span>
                  </span>
                  <span className="flex shrink-0 items-center gap-2">
                    {u.identity_verified ? <Tag tone="good">verified</Tag> : null}
                    <span className="text-xs text-muted-foreground">{relativeTime(u.last_seen_at)}</span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <Empty title="No identities yet." body="Identities are created when connected products call Onaru Connect." />
        )}
      </Panel>
    </div>
  );
}
