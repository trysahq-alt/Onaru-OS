import { createFileRoute } from "@tanstack/react-router";
import { ResourceManager } from "@/components/admin/ResourceManager";

export const Route = createFileRoute("/_authenticated/admin/insights")({
  component: () => (
    <ResourceManager
      table="posts"
      title="Insights"
      singular="Article"
      description="Blog articles, guides and publications."
      orderBy={{ column: "created_at", ascending: false }}
      columns={["title", "category", "published_at"]}
      searchColumn="title"
      defaults={{ status: "draft" }}
      fields={[
        { name: "title", label: "Title", type: "text" },
        { name: "slug", label: "Slug", type: "slug", from: "title" },
        { name: "excerpt", label: "Excerpt", type: "textarea" },
        { name: "content_html", label: "Content", type: "richtext" },
        { name: "category", label: "Category", type: "text" },
        { name: "tags", label: "Tags", type: "list" },
        { name: "author_name", label: "Author", type: "text" },
        { name: "read_time", label: "Read time (min)", type: "number" },
        { name: "featured_image", label: "Featured image", type: "image" },
        { name: "og_image", label: "OG image", type: "image" },
        { name: "canonical_url", label: "Canonical URL", type: "text" },
        { name: "status", label: "Status", type: "status" },
        {
          name: "publish_at",
          label: "Publish at",
          type: "datetime",
          help: "Set status to Scheduled to publish automatically at this time.",
        },
        { name: "seo", label: "SEO (JSON)", type: "json" },
      ]}
    />
  ),
});
