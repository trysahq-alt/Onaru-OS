import { Reveal } from "./Reveal";

const tenets = [
  {
    n: "01",
    title: "We don't chase trends.",
    body: "Hype is a poor substitute for demand. We build for problems that will still exist in ten years.",
  },
  {
    n: "02",
    title: "We build systems.",
    body: "A system compounds while you sleep. A service stops the moment you do.",
  },
  {
    n: "03",
    title: "We solve meaningful problems.",
    body: "If removing the product wouldn't hurt anyone, it wasn't worth building.",
  },
  {
    n: "04",
    title: "We think in decades.",
    body: "Every decision is measured against where the company should be in 2040.",
  },
  {
    n: "05",
    title: "We create impact before profit.",
    body: "Margin follows usefulness. We earn the right to charge by being genuinely needed.",
  },
];

export function Philosophy() {
  return (
    <section id="philosophy" className="relative border-t border-border py-32 md:py-52">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10">
        <Reveal>
          <p className="eyebrow">Philosophy</p>
          <h2 className="display-lg mt-6 max-w-[16ch]">
            Five rules we <span className="text-gold-gradient">refuse to break.</span>
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-5 md:mt-24 md:grid-cols-2 lg:grid-cols-3">
          {tenets.map((t, i) => (
            <Reveal
              key={t.n}
              delay={(i % 3) * 0.07}
              className={i === 0 ? "lg:col-span-2" : undefined}
            >
              <div className="group h-full rounded-[1.5rem] bg-card p-8 hairline float-card md:p-10">
                <span className="font-mono text-xs text-gold/70">{t.n}</span>
                <h3 className="mt-8 text-2xl leading-[1.15] tracking-tight text-foreground md:text-[2rem]">
                  {t.title}
                </h3>
                <p className="mt-5 max-w-[42ch] text-[15px] leading-relaxed text-muted-foreground">
                  {t.body}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
