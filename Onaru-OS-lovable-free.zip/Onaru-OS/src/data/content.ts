export const testimonials = [
  {
    quote:
      "We came for a website. We left with a business model we could actually explain to investors. That reframing was worth more than the build.",
    author: "Chinedu Okafor",
    role: "Founder",
    company: "Technology",
  },
  {
    quote:
      "The first month they mostly deleted things — campaigns, spend, whole channels. Revenue went up. That told me everything.",
    author: "Amara Bello",
    role: "Managing Director",
    company: "Retail Group",
  },
  {
    quote:
      "The production standard is genuinely international. We've used agencies in London that delivered less for more.",
    author: "Tunde Adeyemi",
    role: "Marketing Director",
    company: "Hospitality",
  },
  {
    quote:
      "They tell you when you're wrong. Politely, with data, but they tell you. I've never had that from an agency before.",
    author: "Fatima Sani",
    role: "CEO",
    company: "Healthcare",
  },
  {
    quote:
      "Our cost per lead halved and the leads got better at the same time. I still don't fully understand how, but the reporting shows it every week.",
    author: "David Mensah",
    role: "Head of Growth",
    company: "Real Estate",
  },
  {
    quote:
      "ONARU treats our brand like they own equity in it. That's the difference between a vendor and a partner.",
    author: "Zainab Idris",
    role: "Brand Director",
    company: "Beauty",
  },
];

export const processSteps = [
  {
    n: "01",
    title: "Diagnose",
    body: "We start with the numbers and the uncomfortable questions. Where does revenue actually come from, what does it cost, and what's quietly broken? No proposals until we understand the business.",
    detail: ["Business and funnel audit", "Customer and market research", "Data and tracking review"],
  },
  {
    n: "02",
    title: "Define",
    body: "We choose a position worth defending and a growth model with numbers attached. This is where most engagements are won or lost — before any creative exists.",
    detail: ["Positioning and narrative", "Growth model and forecast", "Channel and budget strategy"],
  },
  {
    n: "03",
    title: "Design",
    body: "Identity, campaigns, product interfaces, film and web. Everything produced to a standard that matches what you're charging for.",
    detail: ["Brand and campaign systems", "Production and film", "Web and product design"],
  },
  {
    n: "04",
    title: "Deploy",
    body: "We ship. Campaigns go live, systems get built, automations get wired, and the measurement layer tells the truth from day one.",
    detail: ["Campaign launch", "Systems and automation", "Analytics implementation"],
  },
  {
    n: "05",
    title: "Compound",
    body: "The real work. Weekly optimisation, quarterly resets, and a constant pipeline of tests — so performance improves instead of plateauing.",
    detail: ["Weekly optimisation", "Continuous testing", "Quarterly strategy resets"],
  },
];

export const values = [
  {
    title: "Business first, marketing second",
    body: "We ask what the business needs before we decide what to make. Sometimes the answer isn't a campaign — and we'll say so.",
  },
  {
    title: "Evidence over opinion",
    body: "Taste matters, but data decides. Every recommendation carries a number and every campaign carries a hypothesis.",
  },
  {
    title: "Craft is non-negotiable",
    body: "Premium positioning collapses under amateur execution. The work has to look and feel worth the price it's asking for.",
  },
  {
    title: "Fewer, deeper partnerships",
    body: "We deliberately keep the client list short. Depth compounds; volume dilutes.",
  },
  {
    title: "Systems over heroics",
    body: "If growth depends on one person remembering, it isn't growth. We build machines, then hand over the manual.",
  },
  {
    title: "Say the hard thing early",
    body: "The most valuable thing a partner does is tell you what nobody internally will. We do it in month one, not month twelve.",
  },
];

export const insights = [
  {
    slug: "positioning-before-performance",
    title: "Positioning Before Performance",
    category: "Strategy",
    readTime: "6 min read",
    date: "2026-06-18",
    excerpt:
      "Why doubling ad spend on a weak position is the most expensive mistake in marketing — and how to tell if yours is weak.",
    body: [
      "Every quarter we meet a company convinced they have a performance problem. Cost per acquisition is climbing, conversion is flat, and the obvious answer is to fix the ads.",
      "Almost always, the ads are fine. The position is the problem. When a market can't tell you apart from three alternatives, every click has to work harder to compensate — and you pay for that in media, forever.",
      "A quick test: ask five customers why they chose you over the alternative. If you get five different answers, you don't have a position. You have a coincidence.",
      "The fix is unglamorous. Decide who you are for, what you refuse to do, and what you're willing to be worse at. Write it down. Then make every asset agree with it for six months. Performance costs fall because the work is doing more of the persuading.",
    ],
  },
  {
    slug: "the-creative-volume-problem",
    title: "The Creative Volume Problem",
    category: "Advertising",
    readTime: "5 min read",
    date: "2026-05-02",
    excerpt:
      "Paid social is now a creative testing business. Most brands are producing at a tenth of the rate the algorithm requires.",
    body: [
      "Media buying used to be about audiences. Targeting was the skill and creative was the wrapper. That era ended.",
      "Platform algorithms now find the audience for you. What they cannot do is invent a new angle when yours fatigues — and fatigue arrives in weeks, not quarters.",
      "The brands winning on paid social are producing between twelve and forty new creative variations a month. Not variations of colour. Variations of argument: different problems, different proofs, different formats.",
      "This is a production capacity question disguised as a media question. If your creative pipeline can only support four assets a month, no amount of bid strategy will save the account.",
    ],
  },
  {
    slug: "what-african-brands-get-wrong-about-premium",
    title: "What African Brands Get Wrong About Premium",
    category: "Brand",
    readTime: "7 min read",
    date: "2026-03-27",
    excerpt:
      "Premium isn't a price tag. It's a set of consistent refusals — and most brands break them at the first sign of a slow month.",
    body: [
      "There is no shortage of premium ambition on the continent. There is a shortage of premium discipline.",
      "Premium is not what you charge. It is what you consistently refuse: the discount in a slow quarter, the badly lit photo because the shoot ran late, the influencer who has no relationship to the brand but has reach.",
      "Every one of those decisions is individually rational and collectively fatal. Customers read the pattern long before they read the price list.",
      "The brands that hold the line have one thing in common: a written governance standard and someone senior empowered to say no. That's it. It isn't a bigger budget. It's a shorter list of acceptable compromises.",
    ],
  },
  {
    slug: "ai-that-actually-pays-for-itself",
    title: "AI That Actually Pays For Itself",
    category: "Technology",
    readTime: "6 min read",
    date: "2026-02-11",
    excerpt:
      "Skip the strategy deck. Here are the four workflows where AI reliably returns more than it costs.",
    body: [
      "Most AI initiatives fail at the same point: the pilot works, everyone is impressed, and nothing changes because nobody could name the number it moved.",
      "Start from cost or revenue. Four workflows return reliably in our experience: support triage, content repurposing, research synthesis, and reporting.",
      "Each shares a profile — high volume, predictable structure, tolerable error rate with a human reviewing output. That last condition is what separates a useful deployment from a liability.",
      "Size the hours before you build. If a workflow doesn't consume at least ten hours a week across the team, automate something else first.",
    ],
  },
  {
    slug: "the-retainer-is-not-the-product",
    title: "The Retainer Is Not The Product",
    category: "Growth",
    readTime: "4 min read",
    date: "2026-01-15",
    excerpt:
      "How to buy agency services without paying for activity that no one can trace to an outcome.",
    body: [
      "Agencies sell hours. Clients want outcomes. The retainer exists to bridge that gap and mostly obscures it instead.",
      "Before signing anything, ask three questions. What number does this move? How will we know within ninety days? What happens if it doesn't?",
      "A good partner answers all three without discomfort. They will also tell you which parts of the scope they'd cut if the budget shrank — because they know which parts actually matter.",
      "Judge the relationship on decisions made, not deliverables shipped. Deliverables are easy to manufacture. Decisions are not.",
    ],
  },
  {
    slug: "measurement-is-a-leadership-problem",
    title: "Measurement Is A Leadership Problem",
    category: "Analytics",
    readTime: "5 min read",
    date: "2025-11-30",
    excerpt:
      "When three tools give three answers, the fix isn't another dashboard. It's a decision about which number wins.",
    body: [
      "Attribution debates are rarely technical. They're political. Each channel owner prefers the model that flatters their channel, and the tooling obligingly provides one for everybody.",
      "The fix is a leadership decision, made once: this is our source of truth, this is the attribution window, this is the number we report. Everything else becomes diagnostic, not scorekeeping.",
      "Then instrument it properly — server-side where possible, CRM-linked always — and stop relitigating it every month.",
      "Companies that make this call early move faster on everything downstream, because budget conversations stop being arguments about whose data is right.",
    ],
  },
];

export const getInsight = (slug: string) => insights.find((i) => i.slug === slug);

export const stats = [
  { value: "10", label: "Companies built and operated" },
  { value: "$18M+", label: "Client revenue influenced" },
  { value: "6", label: "Industries served at depth" },
  { value: "2016", label: "Building since" },
];
