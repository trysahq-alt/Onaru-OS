import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { db, type Row } from "@/lib/db";
import { formatDate, logActivity, slugify, statusTone, type ContentStatus } from "@/lib/cms";
import { MediaPicker } from "@/components/admin/Media";
import { RichText } from "@/components/admin/RichText";
import { toast } from "sonner";
import { Copy, Loader2, Plus, Search, Trash2, X } from "lucide-react";

export type FieldType =
  | "text"
  | "textarea"
  | "slug"
  | "richtext"
  | "number"
  | "boolean"
  | "status"
  | "datetime"
  | "list"
  | "json"
  | "image"
  | "select";

export type Field = {
  name: string;
  label: string;
  type: FieldType;
  options?: string[];
  help?: string;
  from?: string; // source field for slug generation
};

export type ResourceConfig = {
  table: string;
  title: string;
  singular: string;
  description?: string;
  fields: Field[];
  columns: string[];
  orderBy?: { column: string; ascending?: boolean };
  defaults?: Row;
  searchColumn?: string;
};

const inputCls =
  "h-11 w-full rounded-xl border border-border bg-background/50 px-3 text-sm text-foreground outline-none transition focus:border-gold/50";

export function ResourceManager(config: ResourceConfig) {
  const {
    table,
    title,
    singular,
    description,
    fields,
    columns,
    orderBy = { column: "created_at", ascending: false },
    defaults = {},
    searchColumn = columns[0],
  } = config;

  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Row | null>(null);

  const list = useQuery({
    queryKey: [table, orderBy.column],
    queryFn: async () => {
      const { data, error } = await db
        .from(table)
        .select("*")
        .order(orderBy.column, { ascending: orderBy.ascending ?? false });
      if (error) throw error;
      return (data ?? []) as Row[];
    },
  });

  const filtered = useMemo(() => {
    const rows = list.data ?? [];
    if (!search) return rows;
    const q = search.toLowerCase();
    return rows.filter((r) =>
      columns.some((c) => String(r[c] ?? "").toLowerCase().includes(q)),
    );
  }, [list.data, search, columns]);

  const save = useMutation({
    mutationFn: async (row: Row) => {
      const { id, created_at, updated_at, ...payload } = row;
      if (id) {
        const { error } = await db.from(table).update(payload).eq("id", id);
        if (error) throw error;
        await logActivity(`Updated ${singular.toLowerCase()} "${payload[searchColumn] ?? id}"`, table, id);
      } else {
        const { data, error } = await db.from(table).insert(payload).select("id").single();
        if (error) throw error;
        await logActivity(`Created ${singular.toLowerCase()} "${payload[searchColumn] ?? ""}"`, table, data?.id);
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [table] });
      setEditing(null);
      toast.success("Saved");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (row: Row) => {
      const { error } = await db.from(table).delete().eq("id", row.id);
      if (error) throw error;
      await logActivity(`Deleted ${singular.toLowerCase()}`, table, row.id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [table] });
      toast.success("Deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function duplicate(row: Row) {
    const { id, created_at, updated_at, ...rest } = row;
    const copy: Row = { ...rest, status: "draft" };
    if (copy.slug) copy.slug = `${copy.slug}-copy`;
    if (copy.title) copy.title = `${copy.title} (copy)`;
    if (copy.name) copy.name = `${copy.name} (copy)`;
    setEditing(copy);
  }

  return (
    <div className="space-y-5">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
          {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
        </div>
        <button
          onClick={() => setEditing({ ...defaults })}
          className="hidden h-11 items-center gap-2 rounded-xl bg-gold px-4 text-sm font-medium text-black sm:inline-flex"
        >
          <Plus className="h-4 w-4" /> New {singular}
        </button>
      </header>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={`Search ${title.toLowerCase()}`}
          className={`${inputCls} pl-9`}
        />
      </div>

      {list.isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-16 animate-pulse rounded-xl bg-white/5" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-border p-12 text-center text-sm text-muted-foreground">
          Nothing here yet. Create your first {singular.toLowerCase()}.
        </p>
      ) : (
        <ul className="space-y-2">
          {filtered.map((row) => (
            <li
              key={row.id}
              className="group flex items-center gap-3 rounded-xl border border-border bg-card/60 p-3 transition hover:border-white/15"
            >
              <button
                onClick={() => setEditing(row)}
                className="min-w-0 flex-1 text-left"
              >
                <p className="truncate text-sm font-medium text-foreground">
                  {String(row[columns[0]] ?? "Untitled")}
                </p>
                <p className="mt-0.5 truncate text-xs text-muted-foreground">
                  {columns
                    .slice(1)
                    .map((c) => (c.includes("_at") ? formatDate(row[c]) : String(row[c] ?? "")))
                    .filter(Boolean)
                    .join(" · ")}
                </p>
              </button>
              {"status" in row && (
                <span
                  className={`rounded-full px-2.5 py-1 text-[10px] uppercase tracking-wider ${
                    statusTone[(row.status as ContentStatus) ?? "draft"]
                  }`}
                >
                  {row.status}
                </span>
              )}
              <div className="flex shrink-0 gap-1">
                <button
                  onClick={() => duplicate(row)}
                  aria-label="Duplicate"
                  className="grid h-9 w-9 place-items-center rounded-lg text-muted-foreground hover:bg-white/5"
                >
                  <Copy className="h-4 w-4" />
                </button>
                <button
                  onClick={() => {
                    if (confirm("Delete this item permanently?")) remove.mutate(row);
                  }}
                  aria-label="Delete"
                  className="grid h-9 w-9 place-items-center rounded-lg text-muted-foreground hover:bg-white/5 hover:text-red-400"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <button
        onClick={() => setEditing({ ...defaults })}
        aria-label={`New ${singular}`}
        className="fixed bottom-24 right-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-gold text-black shadow-lg sm:hidden"
      >
        <Plus className="h-6 w-6" />
      </button>

      {editing && (
        <RecordEditor
          key={editing.id ?? "new"}
          singular={singular}
          fields={fields}
          record={editing}
          saving={save.isPending}
          onCancel={() => setEditing(null)}
          onSave={(row) => save.mutate(row)}
        />
      )}
    </div>
  );
}

function RecordEditor({
  singular,
  fields,
  record,
  saving,
  onCancel,
  onSave,
}: {
  singular: string;
  fields: Field[];
  record: Row;
  saving: boolean;
  onCancel: () => void;
  onSave: (row: Row) => void;
}) {
  const [row, setRow] = useState<Row>(record);
  const [picker, setPicker] = useState<string | null>(null);
  const set = (name: string, value: unknown) => setRow((r) => ({ ...r, [name]: value }));

  return (
    <div className="fixed inset-0 z-[70] flex justify-end bg-black/70 backdrop-blur-sm">
      <div className="flex h-full w-full flex-col border-l border-border bg-background sm:max-w-2xl">
        <div className="flex items-center justify-between border-b border-border px-4 py-3 sm:px-6">
          <h2 className="text-base font-semibold">
            {row.id ? `Edit ${singular}` : `New ${singular}`}
          </h2>
          <button onClick={onCancel} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-white/5">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto px-4 py-5 pb-32 sm:px-6">
          {fields.map((field) => (
            <div key={field.name}>
              <label className="mb-1.5 block text-xs uppercase tracking-[0.14em] text-muted-foreground">
                {field.label}
              </label>

              {field.type === "text" && (
                <input className={inputCls} value={row[field.name] ?? ""} onChange={(e) => set(field.name, e.target.value)} />
              )}

              {field.type === "slug" && (
                <div className="flex gap-2">
                  <input className={inputCls} value={row[field.name] ?? ""} onChange={(e) => set(field.name, slugify(e.target.value))} />
                  <button
                    type="button"
                    onClick={() => set(field.name, slugify(String(row[field.from ?? "title"] ?? "")))}
                    className="h-11 shrink-0 rounded-xl border border-border px-3 text-xs text-muted-foreground hover:text-foreground"
                  >
                    Generate
                  </button>
                </div>
              )}

              {field.type === "textarea" && (
                <textarea
                  rows={4}
                  className={`${inputCls} h-auto py-3`}
                  value={row[field.name] ?? ""}
                  onChange={(e) => set(field.name, e.target.value)}
                />
              )}

              {field.type === "richtext" && (
                <RichText value={row[field.name] ?? ""} onChange={(html) => set(field.name, html)} />
              )}

              {field.type === "number" && (
                <input
                  type="number"
                  className={inputCls}
                  value={row[field.name] ?? 0}
                  onChange={(e) => set(field.name, Number(e.target.value))}
                />
              )}

              {field.type === "boolean" && (
                <button
                  type="button"
                  onClick={() => set(field.name, !row[field.name])}
                  className={`h-11 rounded-xl border px-4 text-sm ${
                    row[field.name] ? "border-gold/50 bg-gold/10 text-gold" : "border-border text-muted-foreground"
                  }`}
                >
                  {row[field.name] ? "Yes" : "No"}
                </button>
              )}

              {(field.type === "status" || field.type === "select") && (
                <select
                  className={inputCls}
                  value={row[field.name] ?? ""}
                  onChange={(e) => set(field.name, e.target.value)}
                >
                  <option value="">—</option>
                  {(field.type === "status"
                    ? ["draft", "scheduled", "published", "archived"]
                    : (field.options ?? [])
                  ).map((o) => (
                    <option key={o} value={o}>
                      {o}
                    </option>
                  ))}
                </select>
              )}

              {field.type === "datetime" && (
                <input
                  type="datetime-local"
                  className={inputCls}
                  value={row[field.name] ? String(row[field.name]).slice(0, 16) : ""}
                  onChange={(e) =>
                    set(field.name, e.target.value ? new Date(e.target.value).toISOString() : null)
                  }
                />
              )}

              {field.type === "list" && (
                <textarea
                  rows={5}
                  placeholder="One item per line"
                  className={`${inputCls} h-auto py-3`}
                  value={(Array.isArray(row[field.name]) ? row[field.name] : []).join("\n")}
                  onChange={(e) =>
                    set(
                      field.name,
                      e.target.value.split("\n").map((s) => s.trim()).filter(Boolean),
                    )
                  }
                />
              )}

              {field.type === "json" && (
                <textarea
                  rows={6}
                  className={`${inputCls} h-auto py-3 font-mono text-xs`}
                  defaultValue={JSON.stringify(row[field.name] ?? {}, null, 2)}
                  onBlur={(e) => {
                    try {
                      set(field.name, JSON.parse(e.target.value || "{}"));
                    } catch {
                      toast.error(`${field.label}: invalid JSON`);
                    }
                  }}
                />
              )}

              {field.type === "image" && (
                <div className="space-y-2">
                  {row[field.name] && (
                    <img
                      src={row[field.name]}
                      alt=""
                      className="h-32 w-full rounded-xl border border-border object-cover"
                    />
                  )}
                  <div className="flex gap-2">
                    <input
                      className={inputCls}
                      placeholder="Image URL"
                      value={row[field.name] ?? ""}
                      onChange={(e) => set(field.name, e.target.value)}
                    />
                    <button
                      type="button"
                      onClick={() => setPicker(field.name)}
                      className="h-11 shrink-0 rounded-xl border border-border px-3 text-xs text-muted-foreground hover:text-foreground"
                    >
                      Library
                    </button>
                  </div>
                </div>
              )}

              {field.help && <p className="mt-1.5 text-xs text-muted-foreground">{field.help}</p>}
            </div>
          ))}
        </div>

        <div className="sticky bottom-0 flex gap-2 border-t border-border bg-background/95 p-4 backdrop-blur sm:px-6">
          <button
            onClick={onCancel}
            className="h-12 flex-1 rounded-xl border border-border text-sm text-muted-foreground"
          >
            Cancel
          </button>
          <button
            onClick={() => onSave(row)}
            disabled={saving}
            className="inline-flex h-12 flex-[2] items-center justify-center gap-2 rounded-xl bg-gold text-sm font-medium text-black disabled:opacity-50"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" />} Save
          </button>
        </div>
      </div>

      <MediaPicker
        open={Boolean(picker)}
        onClose={() => setPicker(null)}
        onSelect={(url) => picker && set(picker, url)}
      />
    </div>
  );
}
