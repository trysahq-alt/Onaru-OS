import lockup from "@/assets/onaru-lockup.png.asset.json";
import mark from "@/assets/onaru-mark.png.asset.json";

export function OnaruMark({ className = "" }: { className?: string }) {
  return (
    <img
      src={mark.url}
      alt=""
      aria-hidden="true"
      className={`select-none object-contain ${className}`}
      draggable={false}
    />
  );
}

export function OnaruLockup({ className = "" }: { className?: string }) {
  return (
    <img
      src={lockup.url}
      alt="ONARU"
      className={`select-none object-contain ${className}`}
      draggable={false}
    />
  );
}

/** Horizontal mark + wordmark, used in the navigation bar. */
export function Wordmark({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <OnaruMark className="h-7 w-7" />
      <span className="wordmark text-[13px] leading-none">Onaru</span>
    </span>
  );
}
