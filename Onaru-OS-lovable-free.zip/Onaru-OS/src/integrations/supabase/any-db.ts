/* eslint-disable @typescript-eslint/no-explicit-any */
import type { SupabaseClient } from "@supabase/supabase-js";

/**
 * The generated `Database` types in this workspace describe the build-time
 * backend, not the production ONARU Supabase project (`onaru-os`), whose schema
 * and Edge Functions are deployed and managed separately.
 *
 * `anyDb` leaves the runtime client untouched and only relaxes typing so the
 * ONARU data functions can address the real production tables, views and RPCs
 * by name. Swap in generated `onaru-os` types later without touching callers.
 */
export type AnyRow = Record<string, any>;

type AnyTable = {
  Row: AnyRow;
  Insert: AnyRow;
  Update: AnyRow;
  Relationships: [];
};

export type OnaruDatabase = {
  public: {
    Tables: { [key: string]: AnyTable };
    Views: { [key: string]: { Row: AnyRow; Relationships: [] } };
    Functions: { [key: string]: { Args: AnyRow; Returns: any } };
    Enums: { [key: string]: string };
    CompositeTypes: { [key: string]: AnyRow };
  };
};

export type OnaruClient = SupabaseClient<OnaruDatabase, "public">;

export function anyDb(client: unknown): OnaruClient {
  return client as OnaruClient;
}
