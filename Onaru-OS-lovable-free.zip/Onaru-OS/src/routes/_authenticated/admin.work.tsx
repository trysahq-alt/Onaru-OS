import { createFileRoute } from "@tanstack/react-router";
import { ResourceManager } from "@/components/admin/ResourceManager";

export const Route = createFileRoute("/_authenticated/admin/work")({
  component: () => (
    <ResourceManager
      table="projects"
      title="Work"
      singular="Project"
      description="Case studies and portfolio entries."
      orderBy={{ column: "sort_order", ascending: true }}
      columns={["title", "client", "industry"]}
      searchColumn="title"
      defaults={{ status: "draft", sort_order: 0, featured: false }}
      fields={[
        { name: "title", label: "Title", type: "text" },
        { name: "slug", label: "Slug", type: "slug", from: "title" },
        { name: "client", label: "Client", type: "text" },
        { name: "industry", label: "Industry", type: "text" },
        { name: "summary", label: "Summary", type: "textarea" },
        { name: "challenge", label: "Challenge", type: "richtext" },
        { name: "solution", label: "Solution", type: "richtext" },
        { name: "results", label: "Results", type: "richtext" },
        { name: "metrics", label: "Metrics (JSON)", type: "json" },
        { name: "services", label: "Services", type: "list" },
        { name: "tags", label: "Tags", type: "list" },
        { name: "cover_image", label: "Cover image", type: "image" },
        { name: "before_image", label: "Before image", type: "image" },
        { name: "after_image", label: "After image", type: "image" },
        { name: "testimonial", label: "Testimonial (JSON)", type: "json" },
        { name: "featured", label: "Featured", type: "boolean" },
        { name: "sort_order", label: "Sort order", type: "number" },
        { name: "status", label: "Status", type: "status" },
        { name: "publish_at", label: "Publish at", type: "datetime" },
        { name: "seo", label: "SEO (JSON)", type: "json" },
      ]}
    />
  ),
});
