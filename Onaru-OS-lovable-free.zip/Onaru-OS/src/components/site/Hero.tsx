import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { OnaruMark } from "./Wordmark";
import founderAsset from "@/assets/founder-abayomi.png.asset.json";

const particles = Array.from({ length: 14 }, (_, i) => ({
  left: `${(i * 7.3 + 5) % 96}%`,
  delay: `${(i * 1.7) % 14}s`,
  duration: `${18 + ((i * 3) % 12)}s`,
  size: i % 3 === 0 ? 3 : 2,
}));

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 140]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  const ease = [0.16, 1, 0.3, 1] as const;

  return (
    <section
      id="top"
      ref={ref}
      className="grain relative flex min-h-[100svh] items-center overflow-hidden pt-28 pb-20"
    >
      {/* moving light */}
      <div
        className="pointer-events-none absolute -top-1/3 left-1/2 h-[120vh] w-[120vw] -translate-x-1/2"
        style={{
          background: "var(--gradient-veil)",
          animation: reduce ? undefined : "drift 24s ease-in-out infinite",
        }}
      />
      <div
        className="pointer-events-none absolute bottom-[-30%] right-[-10%] h-[70vh] w-[70vh] rounded-full opacity-[0.18] blur-[120px]"
        style={{
          background: "var(--gradient-gold)",
          animation: reduce ? undefined : "drift 32s ease-in-out infinite reverse",
        }}
      />
      {!reduce &&
        particles.map((p, i) => (
          <span
            key={i}
            className="pointer-events-none absolute bottom-0 rounded-full bg-gold/50"
            style={{
              left: p.left,
              width: p.size,
              height: p.size,
              animation: `float-up ${p.duration} linear ${p.delay} infinite`,
            }}
          />
        ))}

      <motion.div
        style={reduce ? undefined : { y, opacity }}
        className="relative mx-auto w-full max-w-[1400px] px-6 md:px-10"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.86, filter: "blur(18px)" }}
          animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
          transition={{ duration: 1.6, ease }}
          className="mb-10 flex items-center gap-4"
        >
          <OnaruMark className="h-11 w-11 text-gold" />
          <span className="wordmark text-sm text-foreground/90">Onaru</span>
          <span className="hidden h-px w-16 bg-border sm:block" />
          <span className="eyebrow hidden sm:block">Venture Holding Company</span>
        </motion.div>

        <div className="grid items-end gap-14 lg:grid-cols-[1.35fr_0.65fr]">
          <div>
            <h1 className="display-xl max-w-[16ch]">
              {["Building Companies", "That Shape Africa's", "Future."].map((line, i) => (
                <span key={line} className="block overflow-hidden">
                  <motion.span
                    className="block"
                    initial={{ y: "110%" }}
                    animate={{ y: "0%" }}
                    transition={{ duration: 1.4, delay: 0.35 + i * 0.12, ease }}
                  >
                    {i === 2 ? (
                      <span className="text-gold-gradient">{line}</span>
                    ) : (
                      line
                    )}
                  </motion.span>
                </span>
              ))}
            </h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.2, delay: 0.9, ease }}
              className="mt-9 max-w-[52ch] text-[15px] leading-relaxed text-muted-foreground md:text-lg"
            >
              ONARU Limited is a venture holding company creating technology, media, education
              and creative businesses that solve real problems at scale.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.2, delay: 1.05, ease }}
              className="mt-11 flex flex-wrap items-center gap-4"
            >
              <a
                href="#companies"
                className="btn-gold group"
              >
                <span className="relative">Explore Our Companies</span>
                <span className="relative transition-transform duration-500 group-hover:translate-x-1">
                  →
                </span>
              </a>
              <a
                href="#founder"
                className="btn-ghost"
              >
                Read Our Story
              </a>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, filter: "blur(24px)", y: 40 }}
            animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
            transition={{ duration: 2.2, delay: 1.2, ease }}
            className="relative hidden lg:block"
          >
            <FounderFrame />
          </motion.div>
        </div>
      </motion.div>

      <div className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-3 md:flex">
        <span className="eyebrow">Scroll</span>
        <span className="h-12 w-px bg-gradient-to-b from-gold/60 to-transparent" />
      </div>
    </section>
  );
}

export function FounderFrame({ tall = false }: { tall?: boolean }) {
  return (
    <div
      className={`group relative overflow-hidden rounded-[2rem] hairline bg-card transition-transform duration-[1200ms] hover:-translate-y-1.5 ${
        tall ? "aspect-[4/5]" : "aspect-[3/4]"
      }`}
      style={{ boxShadow: "var(--shadow-lift)", transitionTimingFunction: "var(--ease-lux)" }}
    >
      <img
        src={founderAsset.url}
        alt="Abayomi Onalaru, Founder and CEO of ONARU Limited"
        className="absolute inset-0 h-full w-full object-cover object-top transition-transform duration-[1600ms] group-hover:scale-[1.04]"
        style={{ transitionTimingFunction: "var(--ease-lux)" }}
        loading="lazy"
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-60 mix-blend-soft-light"
        style={{
          background:
            "radial-gradient(90% 70% at 50% 8%, color-mix(in oklab, var(--gold) 26%, transparent), transparent 65%)",
        }}
      />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-background via-background/60 to-transparent" />
      <div className="absolute bottom-6 left-6">
        <p className="text-sm tracking-tight text-foreground">Abayomi Onalaru</p>
        <p className="eyebrow mt-1">Founder &amp; CEO</p>
      </div>
    </div>
  );
}
