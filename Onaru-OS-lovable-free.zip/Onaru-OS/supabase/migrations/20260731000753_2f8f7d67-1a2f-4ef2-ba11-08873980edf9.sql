
-- ============ ROLES ============
CREATE TYPE public.app_role AS ENUM ('super_admin','admin','editor','writer','marketing','support','viewer');
CREATE TYPE public.content_status AS ENUM ('draft','scheduled','published','archived');

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$
LANGUAGE plpgsql SET search_path = public;

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  title TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

-- any team member
CREATE OR REPLACE FUNCTION public.is_staff(_user_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id);
$$;

-- can create/edit content
CREATE OR REPLACE FUNCTION public.can_edit(_user_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND role IN ('super_admin','admin','editor','writer','marketing')
  );
$$;

CREATE OR REPLACE FUNCTION public.is_admin(_user_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role IN ('super_admin','admin')
  );
$$;

CREATE POLICY "Team can view profiles" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_staff(auth.uid()));
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR public.is_admin(auth.uid()));
CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (id = auth.uid());
CREATE POLICY "Admins delete profiles" ON public.profiles FOR DELETE TO authenticated
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Team can view roles" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_staff(auth.uid()));

-- ============ CONTENT ============
CREATE TABLE public.pages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  subtitle TEXT,
  blocks JSONB NOT NULL DEFAULT '[]'::jsonb,
  hero_image TEXT,
  seo JSONB NOT NULL DEFAULT '{}'::jsonb,
  status public.content_status NOT NULL DEFAULT 'draft',
  visibility TEXT NOT NULL DEFAULT 'public',
  publish_at TIMESTAMPTZ,
  is_system BOOLEAN NOT NULL DEFAULT false,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  icon TEXT,
  cover_image TEXT,
  category TEXT,
  description TEXT,
  overview TEXT,
  deliverables JSONB NOT NULL DEFAULT '[]'::jsonb,
  timeline TEXT,
  process JSONB NOT NULL DEFAULT '[]'::jsonb,
  faq JSONB NOT NULL DEFAULT '[]'::jsonb,
  seo JSONB NOT NULL DEFAULT '{}'::jsonb,
  featured BOOLEAN NOT NULL DEFAULT false,
  sort_order INTEGER NOT NULL DEFAULT 0,
  status public.content_status NOT NULL DEFAULT 'published',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.industries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  overview TEXT,
  cover_image TEXT,
  featured_projects JSONB NOT NULL DEFAULT '[]'::jsonb,
  cta TEXT,
  seo JSONB NOT NULL DEFAULT '{}'::jsonb,
  sort_order INTEGER NOT NULL DEFAULT 0,
  status public.content_status NOT NULL DEFAULT 'published',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  client TEXT,
  industry TEXT,
  services JSONB NOT NULL DEFAULT '[]'::jsonb,
  cover_image TEXT,
  gallery JSONB NOT NULL DEFAULT '[]'::jsonb,
  before_image TEXT,
  after_image TEXT,
  summary TEXT,
  challenge TEXT,
  solution TEXT,
  results TEXT,
  metrics JSONB NOT NULL DEFAULT '[]'::jsonb,
  testimonial JSONB NOT NULL DEFAULT '{}'::jsonb,
  tags JSONB NOT NULL DEFAULT '[]'::jsonb,
  seo JSONB NOT NULL DEFAULT '{}'::jsonb,
  featured BOOLEAN NOT NULL DEFAULT false,
  sort_order INTEGER NOT NULL DEFAULT 0,
  status public.content_status NOT NULL DEFAULT 'draft',
  publish_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  excerpt TEXT,
  featured_image TEXT,
  gallery JSONB NOT NULL DEFAULT '[]'::jsonb,
  content JSONB NOT NULL DEFAULT '{}'::jsonb,
  content_html TEXT,
  author_id UUID,
  author_name TEXT,
  category TEXT,
  tags JSONB NOT NULL DEFAULT '[]'::jsonb,
  read_time INTEGER,
  seo JSONB NOT NULL DEFAULT '{}'::jsonb,
  og_image TEXT,
  canonical_url TEXT,
  status public.content_status NOT NULL DEFAULT 'draft',
  publish_at TIMESTAMPTZ,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.media (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  path TEXT NOT NULL,
  url TEXT NOT NULL,
  filename TEXT NOT NULL,
  mime_type TEXT,
  size BIGINT,
  width INTEGER,
  height INTEGER,
  alt_text TEXT,
  folder TEXT NOT NULL DEFAULT 'general',
  uploaded_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.forms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  fields JSONB NOT NULL DEFAULT '[]'::jsonb,
  notify_emails JSONB NOT NULL DEFAULT '[]'::jsonb,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  form_slug TEXT NOT NULL DEFAULT 'contact',
  name TEXT,
  email TEXT,
  phone TEXT,
  subject TEXT,
  message TEXT,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'new',
  assigned_to UUID,
  notes TEXT,
  source_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.subscribers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  name TEXT,
  source TEXT NOT NULL DEFAULT 'website',
  tags JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'subscribed',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  subject TEXT,
  preheader TEXT,
  blocks JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'draft',
  scheduled_at TIMESTAMPTZ,
  sent_at TIMESTAMPTZ,
  recipients INTEGER NOT NULL DEFAULT 0,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  actor_name TEXT,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.site_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.page_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  path TEXT NOT NULL,
  referrer TEXT,
  device TEXT,
  session_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- updated_at triggers
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['profiles','pages','services','industries','projects','posts','media','forms','submissions','subscribers','campaigns','site_settings']
  LOOP
    EXECUTE format('CREATE TRIGGER set_updated_at BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column()', t);
  END LOOP;
END $$;

-- grants
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['pages','services','industries','projects','posts','media','forms','submissions','subscribers','campaigns','activity_log','notifications','site_settings','page_views']
  LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO authenticated', t);
    EXECUTE format('GRANT ALL ON public.%I TO service_role', t);
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- public read of published content
GRANT SELECT ON public.pages TO anon;
GRANT SELECT ON public.services TO anon;
GRANT SELECT ON public.industries TO anon;
GRANT SELECT ON public.projects TO anon;
GRANT SELECT ON public.posts TO anon;
GRANT SELECT ON public.media TO anon;
GRANT SELECT ON public.forms TO anon;
GRANT SELECT ON public.site_settings TO anon;
GRANT INSERT ON public.submissions TO anon;
GRANT INSERT ON public.subscribers TO anon;
GRANT INSERT ON public.page_views TO anon;

CREATE POLICY "Public reads published pages" ON public.pages FOR SELECT TO anon, authenticated
  USING (status = 'published' AND visibility = 'public');
CREATE POLICY "Public reads published services" ON public.services FOR SELECT TO anon, authenticated
  USING (status = 'published');
CREATE POLICY "Public reads published industries" ON public.industries FOR SELECT TO anon, authenticated
  USING (status = 'published');
CREATE POLICY "Public reads published projects" ON public.projects FOR SELECT TO anon, authenticated
  USING (status = 'published');
CREATE POLICY "Public reads published posts" ON public.posts FOR SELECT TO anon, authenticated
  USING (status = 'published');
CREATE POLICY "Public reads media" ON public.media FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Public reads active forms" ON public.forms FOR SELECT TO anon, authenticated USING (active);
CREATE POLICY "Public reads settings" ON public.site_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can submit a form" ON public.submissions FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can subscribe" ON public.subscribers FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can log a page view" ON public.page_views FOR INSERT TO anon, authenticated WITH CHECK (true);

-- staff management policies
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['pages','services','industries','projects','posts','media','forms','campaigns']
  LOOP
    EXECUTE format('CREATE POLICY "Team reads all %1$s" ON public.%1$I FOR SELECT TO authenticated USING (public.is_staff(auth.uid()))', t);
    EXECUTE format('CREATE POLICY "Editors manage %1$s" ON public.%1$I FOR INSERT TO authenticated WITH CHECK (public.can_edit(auth.uid()))', t);
    EXECUTE format('CREATE POLICY "Editors update %1$s" ON public.%1$I FOR UPDATE TO authenticated USING (public.can_edit(auth.uid()))', t);
    EXECUTE format('CREATE POLICY "Admins delete %1$s" ON public.%1$I FOR DELETE TO authenticated USING (public.is_admin(auth.uid()))', t);
  END LOOP;
END $$;

CREATE POLICY "Team reads submissions" ON public.submissions FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "Team updates submissions" ON public.submissions FOR UPDATE TO authenticated USING (public.can_edit(auth.uid()));
CREATE POLICY "Admins delete submissions" ON public.submissions FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));

CREATE POLICY "Team reads subscribers" ON public.subscribers FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "Team updates subscribers" ON public.subscribers FOR UPDATE TO authenticated USING (public.can_edit(auth.uid()));
CREATE POLICY "Admins delete subscribers" ON public.subscribers FOR DELETE TO authenticated USING (public.is_admin(auth.uid()));

CREATE POLICY "Team reads activity" ON public.activity_log FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "Team writes activity" ON public.activity_log FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Own notifications" ON public.notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Update own notifications" ON public.notifications FOR UPDATE TO authenticated USING (user_id = auth.uid());

CREATE POLICY "Admins manage settings" ON public.site_settings FOR INSERT TO authenticated WITH CHECK (public.is_admin(auth.uid()));
CREATE POLICY "Admins update settings" ON public.site_settings FOR UPDATE TO authenticated USING (public.is_admin(auth.uid()));

CREATE POLICY "Team reads page views" ON public.page_views FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));

CREATE INDEX idx_posts_status ON public.posts(status, publish_at DESC);
CREATE INDEX idx_projects_status ON public.projects(status);
CREATE INDEX idx_page_views_created ON public.page_views(created_at DESC);
CREATE INDEX idx_activity_created ON public.activity_log(created_at DESC);

INSERT INTO public.site_settings (key, value) VALUES
  ('brand', '{"name":"ONARU","tagline":"We Build Brands That Grow.","logo":"","favicon":"","accent":"#C9A227"}'::jsonb),
  ('contact', '{"email":"hello@onaru.com","phone":"","whatsapp":"","address":"Lagos, Nigeria"}'::jsonb),
  ('social', '{"instagram":"","linkedin":"","x":"","youtube":""}'::jsonb),
  ('analytics', '{"ga4":"","gtm":"","cookieBanner":true}'::jsonb);

INSERT INTO public.pages (slug, title, subtitle, status, is_system, sort_order) VALUES
  ('home','Home','We Build Brands That Grow.','published',true,1),
  ('about','About','Why ONARU exists.','published',true,2),
  ('services','Services','Everything growth demands.','published',true,3),
  ('industries','Industries','Where we do our best work.','published',true,4),
  ('work','Work','Proof, not promises.','published',true,5),
  ('pricing','Pricing','Engagements built to scale.','published',true,6),
  ('consultation','Consultation','Book time with a strategist.','published',true,7),
  ('build','Build My Growth Plan','Tell us what you need.','published',true,8),
  ('insights','Insights','Thinking from the ONARU team.','published',true,9),
  ('contact','Contact','Start a conversation.','published',true,10),
  ('privacy','Privacy Policy',null,'published',true,11),
  ('terms','Terms of Service',null,'published',true,12),
  ('404','Page Not Found',null,'published',true,13);

INSERT INTO public.forms (slug, name, description, fields) VALUES
  ('contact','Contact','Main website contact form','[{"name":"name","label":"Full name","type":"text","required":true},{"name":"email","label":"Email","type":"email","required":true},{"name":"message","label":"Message","type":"textarea","required":true}]'::jsonb),
  ('consultation','Consultation Request','Booking enquiries','[{"name":"name","label":"Full name","type":"text","required":true},{"name":"email","label":"Email","type":"email","required":true},{"name":"type","label":"Consultation type","type":"text","required":false}]'::jsonb);
