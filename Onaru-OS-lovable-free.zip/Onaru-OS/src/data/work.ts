export type CaseStudy = {
  slug: string;
  client: string;
  industry: string;
  service: string;
  year: string;
  headline: string;
  summary: string;
  challenge: string;
  approach: string[];
  results: { value: string; label: string }[];
  before: string;
  after: string;
  quote?: { text: string; author: string; role: string };
  accent: string;
};

export const caseStudies: CaseStudy[] = [
  {
    slug: "trysa-operating-system",
    client: "TRYSA",
    industry: "Technology",
    service: "Brand Strategy · Web Design · Growth",
    year: "2025",
    headline: "Repositioning a tool as an operating system.",
    summary:
      "TRYSA was competing as another business app. We repositioned it as the operating layer African businesses run on, and rebuilt the go-to-market around that claim.",
    challenge:
      "Strong product, invisible category. Sign-ups came from referrals only, activation was under 30%, and the pitch changed depending on who was giving it.",
    approach: [
      "Category definition and positioning workshop with leadership",
      "New narrative, messaging architecture and pricing story",
      "Complete site rebuild around a single conversion path",
      "Onboarding redesign to shorten time-to-first-value",
      "Demand generation across search and paid social",
    ],
    results: [
      { value: "+218%", label: "qualified sign-ups in six months" },
      { value: "31→68%", label: "activation rate" },
      { value: "-44%", label: "cost per acquisition" },
      { value: "2.7×", label: "average contract value" },
    ],
    before: "A feature list on a template site, and a different pitch in every meeting.",
    after: "One category claim, one funnel, one number the whole team reports against.",
    quote: {
      text: "They didn't give us a campaign. They gave us a way to explain ourselves that finally stuck.",
      author: "Product Lead",
      role: "TRYSA",
    },
    accent: "oklch(0.83 0.13 88)",
  },
  {
    slug: "nuwa-direct-bookings",
    client: "NUWA",
    industry: "Hospitality",
    service: "Brand Films · Web Design · Paid Media",
    year: "2025",
    headline: "Taking hospitality margin back from the aggregators.",
    summary:
      "NUWA was paying away a fifth of revenue in platform commission. We built the brand, the film and the direct booking engine that changed the split.",
    challenge:
      "Beautiful properties, generic listings. Over 80% of bookings came through OTAs, and guests left no data behind.",
    approach: [
      "Property film and photography across the portfolio",
      "Direct-booking site with real-time availability",
      "Rate parity and best-price messaging strategy",
      "Guest lifecycle email programme",
      "Geo and interest-targeted paid campaigns",
    ],
    results: [
      { value: "+52%", label: "direct bookings" },
      { value: "-19%", label: "commission cost as share of revenue" },
      { value: "+34%", label: "average length of stay" },
      { value: "11k", label: "first-party guest records built" },
    ],
    before: "Aggregator-dependent, anonymous guests, thin margins.",
    after: "A direct channel with owned guest data and repeat-stay economics.",
    accent: "oklch(0.78 0.11 78)",
  },
  {
    slug: "yofa-launch",
    client: "YOFA",
    industry: "Food & Beverage",
    service: "Brand Identity · Photography · Social",
    year: "2024",
    headline: "A consumer brand that sold out its first run.",
    summary:
      "From naming and identity through to a launch campaign that cleared inventory in eleven days.",
    challenge:
      "A category with no shortage of options and no loyalty. The product was excellent; nothing about the presentation said so.",
    approach: [
      "Full identity system and packaging design",
      "Product and lifestyle photography library",
      "Pre-launch waitlist mechanic across social",
      "Launch campaign with creator seeding",
      "Retention flows from the first order",
    ],
    results: [
      { value: "11 days", label: "to sell through first production run" },
      { value: "6,400", label: "pre-launch waitlist signups" },
      { value: "+29%", label: "repeat purchase within 90 days" },
      { value: "4.8/5", label: "average customer rating" },
    ],
    before: "A good product with no story and no queue.",
    after: "A brand people wait for, with data on every buyer.",
    accent: "oklch(0.86 0.1 92)",
  },
  {
    slug: "yv-studios-utilisation",
    client: "YV Studios Africa",
    industry: "Creative Infrastructure",
    service: "Marketing Strategy · Automation · SEO",
    year: "2025",
    headline: "Filling a studio calendar with systems, not sales calls.",
    summary:
      "Studio utilisation was the whole business model. We built the demand engine and the booking automation to raise it.",
    challenge:
      "Studios sat empty midweek. Booking ran through WhatsApp, quotes were manual, and nobody followed up on a lapsed client.",
    approach: [
      "Local and category search strategy",
      "Online booking system with instant quoting",
      "Automated follow-up and re-booking sequences",
      "Creator partnership programme",
      "Midweek pricing and package design",
    ],
    results: [
      { value: "41→79%", label: "studio utilisation" },
      { value: "-86%", label: "time spent quoting" },
      { value: "+63%", label: "repeat bookings" },
      { value: "#1", label: "local search position for core terms" },
    ],
    before: "A calendar managed in WhatsApp and a lot of empty Tuesdays.",
    after: "Self-serve booking, automated follow-up, and a waitlist on weekends.",
    accent: "oklch(0.8 0.12 84)",
  },
  {
    slug: "playbaaq-performance",
    client: "PlayBaaq",
    industry: "Sports Technology",
    service: "UI/UX · Product Marketing · Analytics",
    year: "2025",
    headline: "Turning weekend players into weekly users.",
    summary:
      "A performance platform with strong signup and weak retention. We rebuilt the first-session experience and the loop that brings people back.",
    challenge:
      "Users signed up, recorded one session, and disappeared. There was no habit and no instrumentation to explain why.",
    approach: [
      "User research with athletes, coaches and organisers",
      "Onboarding and first-session redesign",
      "Retention loop and notification strategy",
      "Full product analytics implementation",
      "Launch campaign around competitive leagues",
    ],
    results: [
      { value: "+147%", label: "week-4 retention" },
      { value: "2.9×", label: "sessions per active user" },
      { value: "-38%", label: "onboarding drop-off" },
      { value: "+81%", label: "organic referrals" },
    ],
    before: "High signup, no habit, no data on the gap between them.",
    after: "A weekly ritual with the analytics to keep improving it.",
    accent: "oklch(0.82 0.13 88)",
  },
  {
    slug: "laruu-luxury-launch",
    client: "Laruu",
    industry: "Luxury",
    service: "Brand Identity · Campaign · Clienteling",
    year: "2026",
    headline: "Restraint as a growth strategy.",
    summary:
      "A luxury house brand launched without a single discount, built entirely on craft, scarcity and invitation.",
    challenge:
      "Launching a premium price point in a market conditioned to expect promotions, without ever competing on price.",
    approach: [
      "Identity system with strict governance rules",
      "Editorial campaign photography and film",
      "Invitation-only launch with private previews",
      "Clienteling programme for founding customers",
      "Precision paid targeting, no broad reach buying",
    ],
    results: [
      { value: "0", label: "discounts offered in year one" },
      { value: "+22%", label: "average order value vs. category" },
      { value: "94%", label: "of launch inventory sold at full price" },
      { value: "1,200", label: "invitation waitlist" },
    ],
    before: "A premium product with no reason to believe the premium.",
    after: "A brand with a waitlist and no discount habit to unlearn.",
    accent: "oklch(0.88 0.08 94)",
  },
];

export const getCaseStudy = (slug: string) => caseStudies.find((c) => c.slug === slug);
