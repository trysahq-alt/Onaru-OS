import trysaLogo from "@/assets/trysa.png.asset.json";
import yvstudiosLogo from "@/assets/yvstudios.png.asset.json";
import playbaaqLogo from "@/assets/playbaaq.jpg.asset.json";
import yofaLogo from "@/assets/yofa.png.asset.json";

import trysaImg from "@/assets/co-trysa.jpg";
import yomiImg from "@/assets/co-yomivisuals.jpg";
import yvstudiosImg from "@/assets/co-yvstudios.jpg";
import yofaImg from "@/assets/co-yofa.jpg";
import yvexpImg from "@/assets/co-yvexperience.jpg";
import playbaaqImg from "@/assets/co-playbaaq.jpg";

export type Company = {
  slug: string;
  name: string;
  label: string;
  category: string;
  tagline: string;
  description: string;
  long: string;
  highlights: string[];
  status: string;
  location: string;
  cta: string;
  href: string;
  image: string;
  logo?: string;
  /** logo plate needs a light backing (dark artwork) */
  tone?: "light" | "dark";
  zoom?: number;
  /** editorial grid emphasis */
  feature?: boolean;
};

export const companies: Company[] = [
  {
    slug: "trysa",
    name: "TRYSA",
    label: "Technology",
    category: "Technology / Business Software",
    tagline: "One system to run the business on.",
    description:
      "A business operating system built for creatives, studios, agencies and growing businesses.",
    long:
      "TRYSA brings clients, projects, bookings, payments and reporting into a single calm interface — replacing the spreadsheets, chat threads and disconnected tools that growing businesses outgrow.",
    highlights: ["Clients & CRM", "Bookings & Projects", "Payments & Invoicing", "Reporting"],
    status: "Live",
    location: "Lagos, Nigeria",
    cta: "Explore TRYSA",
    href: "#contact",
    image: trysaImg,
    logo: trysaLogo.url,
    tone: "light",
    zoom: 1.25,
    feature: true,
  },
  {
    slug: "yomi-visuals",
    name: "YOMI VISUALS",
    label: "Creative",
    category: "Creative / Photography",
    tagline: "Imagery made to last.",
    description:
      "A premium photography and visual production company creating portraits, campaigns, weddings, events and commercial imagery.",
    long:
      "Yomi Visuals is where the group's craft began — a production practice trusted for portraiture, brand campaigns, weddings and commercial work shot to an international standard.",
    highlights: ["Portraiture", "Brand Campaigns", "Weddings", "Commercial"],
    status: "Live",
    location: "Lagos, Nigeria",
    cta: "Explore Yomi Visuals",
    href: "#contact",
    image: yomiImg,
  },
  {
    slug: "yv-studios",
    name: "YV STUDIOS",
    label: "Spaces",
    category: "Creative Spaces / Production",
    tagline: "Space to make the work.",
    description:
      "Premium studio spaces and production environments for photographers, creators, brands and production teams.",
    long:
      "YV Studios operates production-ready spaces — cycloramas, lighting, sets and crew support — available by the hour or by the project, so independent creators can produce at the standard of a global brand.",
    highlights: ["Studio Hire", "Lighting & Grip", "Set Build", "Crew Support"],
    status: "Live",
    location: "Lagos, Nigeria",
    cta: "Explore YV Studios",
    href: "#contact",
    image: yvstudiosImg,
    logo: yvstudiosLogo.url,
    zoom: 2.6,
  },
  {
    slug: "yofa",
    name: "YOFA",
    label: "Bakery",
    category: "Food / Bakery",
    tagline: "Crafted fresh. Shared often.",
    description:
      "A modern premium bakery creating beautifully crafted baked goods, pastries, cakes and food experiences.",
    long:
      "YOFA is a contemporary bakery built around craft and warmth — laminated pastries, celebration cakes, daily breads and food experiences made to be shared.",
    highlights: ["Pastries", "Celebration Cakes", "Daily Breads", "Food Experiences"],
    status: "Live",
    location: "Lagos, Nigeria",
    cta: "Explore YOFA",
    href: "#contact",
    image: yofaImg,
    logo: yofaLogo.url,
    zoom: 1.6,
    feature: true,
  },
  {
    slug: "yv-experience",
    name: "YV EXPERIENCE",
    label: "Experiences",
    category: "Experiences / Activations",
    tagline: "Made to be remembered.",
    description:
      "An experience brand creating curated photography experiences, pop-ups, creative activations and memorable physical moments.",
    long:
      "YV Experience designs and runs experiences — curated shoot days, pop-ups, brand activations and cultural moments where people participate rather than watch.",
    highlights: ["Curated Experiences", "Pop-Ups", "Brand Activations", "Cultural Moments"],
    status: "Live",
    location: "Lagos, Nigeria",
    cta: "Explore YV Experience",
    href: "#contact",
    image: yvexpImg,
  },
  {
    slug: "playbaaq",
    name: "PLAYBAAQ",
    label: "Entertainment",
    category: "Entertainment / Experiences",
    tagline: "Built around play.",
    description:
      "An entertainment and social experience brand built around play, interaction, community and memorable nights.",
    long:
      "Playbaaq creates social entertainment — games, competition and community formats designed to bring people together in the room and keep them coming back.",
    highlights: ["Social Play", "Community", "Events", "Competitions"],
    status: "Live",
    location: "Lagos, Nigeria",
    cta: "Explore Playbaaq",
    href: "#contact",
    image: playbaaqImg,
    logo: playbaaqLogo.url,
    zoom: 1.4,
  },
];

export const studioCapabilities = [
  {
    title: "Brand & Strategy",
    body: "Positioning, naming, identity systems and the strategy that decides what gets built.",
  },
  {
    title: "Creative & Production",
    body: "Photography, film, art direction and content produced end-to-end in our own studios.",
  },
  {
    title: "Digital Products",
    body: "Websites, platforms and product design built for performance and longevity.",
  },
  {
    title: "Marketing & Growth",
    body: "Advertising, campaigns, funnels and the measurement that keeps them honest.",
  },
  {
    title: "Business Technology",
    body: "Automation, internal systems and the operational tooling that lets a business scale.",
  },
];
