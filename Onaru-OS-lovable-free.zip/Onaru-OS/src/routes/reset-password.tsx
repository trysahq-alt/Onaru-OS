import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { OnaruMark } from "@/components/site/Wordmark";
import { toast } from "sonner";

export const Route = createFileRoute("/reset-password")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Reset password — ONARU Studio" },
      { name: "description", content: "Set a new password for your ONARU Studio account." },
      { property: "og:title", content: "Reset password — ONARU Studio" },
      { property: "og:description", content: "Set a new password for your ONARU Studio account." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setReady(Boolean(data.session)));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) =>
      setReady(Boolean(session)),
    );
    return () => sub.subscription.unsubscribe();
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) {
      toast.error("Use at least 8 characters");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Password updated");
    navigate({ to: "/admin", replace: true });
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-5">
      <div className="w-full max-w-[380px]">
        <div className="mb-8 flex flex-col items-center text-center">
          <OnaruMark className="h-11 w-11" />
          <h1 className="mt-5 text-xl font-semibold text-foreground">Set a new password</h1>
        </div>
        <form
          onSubmit={submit}
          className="space-y-4 rounded-2xl border border-border bg-card/70 p-6 backdrop-blur-xl"
        >
          <input
            type="password"
            required
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="New password"
            className="h-12 w-full rounded-xl border border-border bg-background/60 px-4 text-base text-foreground outline-none focus:border-gold/60"
          />
          <button
            type="submit"
            disabled={busy || !ready}
            className="h-12 w-full rounded-xl bg-gold text-base font-medium text-black transition hover:opacity-90 disabled:opacity-50"
          >
            {ready ? (busy ? "Saving…" : "Update password") : "Open the link from your email"}
          </button>
        </form>
      </div>
    </main>
  );
}
