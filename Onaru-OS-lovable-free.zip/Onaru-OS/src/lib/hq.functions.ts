import { anyDb } from "@/integrations/supabase/any-db";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * ONARU HQ — authenticated server functions. Every function re-checks HQ
 * authorization server-side; hiding navigation is never the control.
 */

type Ctx = { supabase: any; userId: string; claims: Record<string, unknown> }; // eslint-disable-line @typescript-eslint/no-explicit-any

async function assertHq(context: Ctx) {
  const { data, error } = await anyDb(context.supabase).rpc("is_onaru_hq", { _user_id: context.userId });
  if (error || !data) throw new Error("Forbidden: Onaru HQ access required");
}

export const hqOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertHq(context as Ctx);
    const [overview, series, cross] = await Promise.all([
      anyDb(context.supabase).rpc("onaru_hq_overview"),
      anyDb(context.supabase).rpc("onaru_hq_timeseries", { _days: 30 }),
      anyDb(context.supabase).rpc("onaru_hq_cross_product"),
    ]);
    const { data: activity } = await anyDb(context.supabase)
      .from("onaru_events")
      .select("id, event_name, occurred_at, properties, product_id, user_id")
      .order("occurred_at", { ascending: false })
      .limit(25);
    const { data: products } = await anyDb(context.supabase)
      .from("onaru_products")
      .select("id, name, slug");
    return {
      overview: (overview.data ?? {}) as Record<string, number>,
      series: (series.data ?? []) as { day: string; new_users: number; events: number; active_users: number }[],
      cross: (cross.data ?? {}) as {
        distribution?: { products: number; users: number }[];
        overlaps?: { product_a: string; product_b: string; shared_users: number }[];
      },
      activity: activity ?? [],
      products: products ?? [],
    };
  });

export const hqProducts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertHq(context as Ctx);
    const { data, error } = await anyDb(context.supabase).rpc("onaru_hq_product_stats");
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const hqProduct = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const [{ data: product }, { data: stats }, { data: events }, { data: clients }] =
      await Promise.all([
        anyDb(context.supabase).from("onaru_products").select("*").eq("id", data.id).maybeSingle(),
        anyDb(context.supabase).rpc("onaru_hq_product_stats"),
        anyDb(context.supabase)
          .from("onaru_events")
          .select("id, event_name, occurred_at, external_user_id, user_id, environment")
          .eq("product_id", data.id)
          .order("occurred_at", { ascending: false })
          .limit(50),
        anyDb(context.supabase)
          .from("onaru_api_requests")
          .select("id, endpoint, status_code, error, created_at")
          .eq("product_id", data.id)
          .order("created_at", { ascending: false })
          .limit(25),
      ]);
    if (!product) throw new Error("Product not found");
    return {
      product,
      stats:
        (stats ?? []).find((s: { product_id: string }) => s.product_id === data.id) ?? null,
      events: events ?? [],
      requests: clients ?? [],
    };
  });

export const hqUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ query: z.string().trim().max(200).optional() }).parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const q = data.query?.trim();
    let ids: string[] | null = null;
    if (q) {
      const { data: byExternal } = await anyDb(context.supabase)
        .from("onaru_product_memberships")
        .select("user_id")
        .eq("external_user_id", q);
      ids = (byExternal ?? []).map((m: { user_id: string }) => m.user_id);
    }
    let builder = anyDb(context.supabase)
      .from("onaru_users")
      .select(
        "id, primary_email, phone, display_name, first_name, last_name, country, status, email_verified, identity_verified, created_at, last_seen_at",
      )
      .order("created_at", { ascending: false })
      .limit(100);
    if (q) {
      const like = `%${q.replace(/[%,]/g, "")}%`;
      const clauses = [
        `primary_email.ilike.${like}`,
        `display_name.ilike.${like}`,
        `first_name.ilike.${like}`,
        `last_name.ilike.${like}`,
        `phone.ilike.${like}`,
      ];
      if (/^[0-9a-f-]{36}$/i.test(q)) clauses.push(`id.eq.${q}`);
      if (ids && ids.length) clauses.push(`id.in.(${ids.join(",")})`);
      builder = builder.or(clauses.join(","));
    }
    const { data: users, error } = await builder;
    if (error) throw new Error(error.message);
    return users ?? [];
  });

export const hqUser = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const [{ data: user }, { data: memberships }, { data: orgs }, { data: events }, { data: links }] =
      await Promise.all([
        anyDb(context.supabase)
          .from("onaru_users")
          .select(
            "id, primary_email, phone, first_name, last_name, display_name, avatar_url, country, timezone, status, email_verified, phone_verified, identity_verified, created_at, updated_at, last_seen_at",
          )
          .eq("id", data.id)
          .maybeSingle(),
        anyDb(context.supabase)
          .from("onaru_product_memberships")
          .select("id, product_id, external_user_id, role, status, joined_at, last_active_at")
          .eq("user_id", data.id),
        anyDb(context.supabase)
          .from("onaru_organization_members")
          .select("organization_id, role, status, joined_at")
          .eq("user_id", data.id),
        anyDb(context.supabase)
          .from("onaru_events")
          .select("id, event_name, product_id, occurred_at, properties")
          .eq("user_id", data.id)
          .order("occurred_at", { ascending: false })
          .limit(50),
        anyDb(context.supabase)
          .from("onaru_identity_links")
          .select("id, status, product_id, email, created_at, verified_at")
          .eq("primary_user_id", data.id),
      ]);
    if (!user) throw new Error("Identity not found");
    const { data: products } = await anyDb(context.supabase)
      .from("onaru_products")
      .select("id, name, slug");
    const { data: organizations } = await anyDb(context.supabase)
      .from("onaru_organizations")
      .select("id, name, slug");
    return {
      user,
      memberships: memberships ?? [],
      orgs: orgs ?? [],
      events: events ?? [],
      links: links ?? [],
      products: products ?? [],
      organizations: organizations ?? [],
    };
  });

export const hqOrganizations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertHq(context as Ctx);
    const { data: orgs } = await anyDb(context.supabase)
      .from("onaru_organizations")
      .select("id, name, slug, organization_type, country, status, owner_user_id, created_at")
      .order("created_at", { ascending: false })
      .limit(200);
    const { data: members } = await anyDb(context.supabase)
      .from("onaru_organization_members")
      .select("organization_id");
    return (orgs ?? []).map((o: { id: string }) => ({
      ...o,
      member_count: (members ?? []).filter(
        (m: { organization_id: string }) => m.organization_id === o.id,
      ).length,
    }));
  });

export const hqOrganization = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const [{ data: org }, { data: members }, { data: events }] = await Promise.all([
      anyDb(context.supabase).from("onaru_organizations").select("*").eq("id", data.id).maybeSingle(),
      anyDb(context.supabase)
        .from("onaru_organization_members")
        .select("id, user_id, role, status, joined_at, permissions")
        .eq("organization_id", data.id),
      anyDb(context.supabase)
        .from("onaru_events")
        .select("id, event_name, product_id, occurred_at, properties")
        .eq("organization_id", data.id)
        .order("occurred_at", { ascending: false })
        .limit(50),
    ]);
    if (!org) throw new Error("Organization not found");
    const memberIds = (members ?? []).map((m: { user_id: string }) => m.user_id);
    const { data: identities } = memberIds.length
      ? await anyDb(context.supabase)
          .from("onaru_users")
          .select("id, display_name, primary_email")
          .in("id", memberIds)
      : { data: [] };
    const { data: products } = await anyDb(context.supabase)
      .from("onaru_products")
      .select("id, name, slug");
    const revenue = ((events ?? []) as { event_name: string; properties: unknown }[])
      .filter((e) => e.event_name === "payment.received")
      .reduce((sum, e) => {
        const props = (e.properties ?? {}) as Record<string, unknown>;
        const amount = Number(props.amount);
        return sum + (Number.isFinite(amount) ? amount : 0);
      }, 0);
    return { org, members: members ?? [], identities: identities ?? [], events: events ?? [], products: products ?? [], revenue };
  });

export const hqEvents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        productId: z.string().uuid().optional(),
        eventName: z.string().trim().max(120).optional(),
        environment: z.enum(["development", "staging", "production"]).optional(),
        userId: z.string().uuid().optional(),
        organizationId: z.string().uuid().optional(),
        since: z.string().optional(),
        search: z.string().trim().max(200).optional(),
      })
      .parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    let builder = anyDb(context.supabase)
      .from("onaru_events")
      .select(
        "id, event_name, product_id, user_id, organization_id, external_user_id, external_event_id, session_id, event_version, properties, occurred_at, received_at, environment",
      )
      .order("occurred_at", { ascending: false })
      .limit(200);
    if (data.productId) builder = builder.eq("product_id", data.productId);
    if (data.eventName) builder = builder.eq("event_name", data.eventName);
    if (data.environment) builder = builder.eq("environment", data.environment);
    if (data.userId) builder = builder.eq("user_id", data.userId);
    if (data.organizationId) builder = builder.eq("organization_id", data.organizationId);
    if (data.since) builder = builder.gte("occurred_at", data.since);
    if (data.search) builder = builder.ilike("event_name", `%${data.search.replace(/[%,]/g, "")}%`);
    const { data: events, error } = await builder;
    if (error) throw new Error(error.message);
    const { data: products } = await anyDb(context.supabase)
      .from("onaru_products")
      .select("id, name, slug");
    const { data: names } = await anyDb(context.supabase)
      .from("onaru_events")
      .select("event_name")
      .limit(1000);
    return {
      events: events ?? [],
      products: products ?? [],
      eventNames: [...new Set((names ?? []).map((n: { event_name: string }) => n.event_name))].sort(),
    };
  });

export const hqIntegrations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertHq(context as Ctx);
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
    const { data: products } = await anyDb(context.supabase)
      .from("onaru_products")
      .select("*")
      .order("created_at", { ascending: true });
    // secret_hash is never selected, so it can never reach the browser.
    const { data: clients } = await supabaseAdmin
      .from("onaru_api_clients")
      .select("id, product_id, name, key_prefix, environment, scopes, status, last_used_at, expires_at, created_at")
      .order("created_at", { ascending: false });
    const { data: requests } = await anyDb(context.supabase)
      .from("onaru_api_requests")
      .select("id, product_id, endpoint, status_code, error, created_at")
      .order("created_at", { ascending: false })
      .limit(100);
    const { data: lastEvents } = await anyDb(context.supabase)
      .from("onaru_events")
      .select("product_id, occurred_at")
      .order("occurred_at", { ascending: false })
      .limit(500);
    return {
      products: products ?? [],
      clients: clients ?? [],
      requests: requests ?? [],
      lastEvents: lastEvents ?? [],
    };
  });

export const hqCreateProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        name: z.string().trim().min(1).max(120),
        slug: z.string().trim().min(1).max(80).regex(/^[a-z0-9-]+$/),
        description: z.string().trim().max(600).optional(),
        environment: z.enum(["development", "staging", "production"]),
        status: z.enum(["active", "beta", "disabled"]),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
    const core = await import("@/lib/onaru/core.server");
    const { data: product, error } = await supabaseAdmin
      .from("onaru_products")
      .insert({
        name: data.name,
        slug: data.slug,
        description: data.description ?? null,
        environment: data.environment,
        status: data.status,
        api_identifier: `prd_${data.slug}`,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    await core.writeAudit({
      actorId: context.userId,
      actorLabel: String(context.claims.email ?? ""),
      action: "product.created",
      resourceType: "onaru_products",
      resourceId: product.id,
      metadata: { slug: data.slug },
    });
    return { id: product.id };
  });

export const hqCreateCredential = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        productId: z.string().uuid(),
        name: z.string().trim().min(1).max(120),
        environment: z.enum(["development", "staging", "production"]),
        scopes: z.array(
          z.enum([
            "identity:read",
            "identity:write",
            "events:write",
            "organizations:read",
            "organizations:write",
            "memberships:write",
          ]),
        ).min(1),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
    const core = await import("@/lib/onaru/core.server");
    const cred = core.generateCredential(data.environment);
    const secretHash = await core.hashSecret(cred.secret);
    const { data: created, error } = await supabaseAdmin
      .from("onaru_api_clients")
      .insert({
        product_id: data.productId,
        name: data.name,
        key_prefix: cred.keyPrefix,
        secret_hash: secretHash,
        environment: data.environment,
        scopes: data.scopes as never,
        created_by: context.userId,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    await core.writeAudit({
      actorId: context.userId,
      actorLabel: String(context.claims.email ?? ""),
      action: "api_credential.created",
      resourceType: "onaru_api_clients",
      resourceId: created.id,
      metadata: { product_id: data.productId, environment: data.environment, scopes: data.scopes },
    });
    // The full key is returned exactly once and never stored in plaintext.
    return { id: created.id, key: cred.fullKey };
  });

export const hqRotateCredential = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
    const core = await import("@/lib/onaru/core.server");
    const { data: existing } = await supabaseAdmin
      .from("onaru_api_clients")
      .select("id, environment")
      .eq("id", data.id)
      .maybeSingle();
    if (!existing) throw new Error("Credential not found");
    const cred = core.generateCredential(existing.environment);
    const secretHash = await core.hashSecret(cred.secret);
    const { error } = await supabaseAdmin
      .from("onaru_api_clients")
      .update({ key_prefix: cred.keyPrefix, secret_hash: secretHash, status: "active" })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    await core.writeAudit({
      actorId: context.userId,
      actorLabel: String(context.claims.email ?? ""),
      action: "api_credential.rotated",
      resourceType: "onaru_api_clients",
      resourceId: data.id,
    });
    return { key: cred.fullKey };
  });

export const hqRevokeCredential = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
    const core = await import("@/lib/onaru/core.server");
    const { error } = await supabaseAdmin
      .from("onaru_api_clients")
      .update({ status: "revoked" })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    await core.writeAudit({
      actorId: context.userId,
      actorLabel: String(context.claims.email ?? ""),
      action: "api_credential.revoked",
      resourceType: "onaru_api_clients",
      resourceId: data.id,
    });
    return { ok: true };
  });

export const hqAudit = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertHq(context as Ctx);
    const { data } = await anyDb(context.supabase)
      .from("onaru_audit_logs")
      .select("id, actor_type, actor_id, actor_label, action, resource_type, resource_id, metadata, ip, created_at")
      .order("created_at", { ascending: false })
      .limit(200);
    return data ?? [];
  });

export const hqIdentityLinks = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertHq(context as Ctx);
    const { data } = await anyDb(context.supabase)
      .from("onaru_identity_links")
      .select("id, primary_user_id, candidate_user_id, product_id, external_user_id, email, status, created_at, verified_at, expires_at")
      .order("created_at", { ascending: false })
      .limit(100);
    return data ?? [];
  });

export const hqResolveLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ id: z.string().uuid(), decision: z.enum(["verified", "rejected", "unlinked"]) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
    const core = await import("@/lib/onaru/core.server");
    const { data: link } = await supabaseAdmin
      .from("onaru_identity_links")
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (!link) throw new Error("Link request not found");

    if (data.decision === "verified") {
      if (!link.product_id || !link.external_user_id) {
        throw new Error("Link request is missing product mapping");
      }
      await supabaseAdmin.from("onaru_product_memberships").upsert(
        {
          user_id: link.primary_user_id,
          product_id: link.product_id,
          external_user_id: link.external_user_id,
          last_active_at: new Date().toISOString(),
        },
        { onConflict: "user_id,product_id" },
      );
    }
    if (data.decision === "unlinked" && link.product_id) {
      await supabaseAdmin
        .from("onaru_product_memberships")
        .delete()
        .eq("user_id", link.primary_user_id)
        .eq("product_id", link.product_id);
    }

    await supabaseAdmin
      .from("onaru_identity_links")
      .update({
        status: data.decision,
        verified_at: data.decision === "verified" ? new Date().toISOString() : null,
      })
      .eq("id", data.id);

    await core.writeAudit({
      actorId: context.userId,
      actorLabel: String(context.claims.email ?? ""),
      action:
        data.decision === "verified"
          ? "account.linked"
          : data.decision === "unlinked"
            ? "account.unlinked"
            : "account.link_rejected",
      resourceType: "onaru_identity_links",
      resourceId: data.id,
      metadata: { primary_user_id: link.primary_user_id },
    });
    return { ok: true };
  });

export const hqSetUserStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({ id: z.string().uuid(), status: z.enum(["active", "suspended", "pending", "deleted"]) })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertHq(context as Ctx);
    const { supabaseAdmin: _rawAdmin } = await import("@/integrations/supabase/client.server"); const supabaseAdmin = anyDb(_rawAdmin);
    const core = await import("@/lib/onaru/core.server");
    const { error } = await supabaseAdmin
      .from("onaru_users")
      .update({ status: data.status })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    await core.writeAudit({
      actorId: context.userId,
      actorLabel: String(context.claims.email ?? ""),
      action: "user.status_changed",
      resourceType: "onaru_users",
      resourceId: data.id,
      metadata: { status: data.status },
    });
    return { ok: true };
  });
