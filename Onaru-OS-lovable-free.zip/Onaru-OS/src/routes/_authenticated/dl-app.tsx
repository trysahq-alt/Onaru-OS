import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Download, ShieldCheck, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { OnaruMark } from "@/components/site/Wordmark";
import { listAppReleases, getAppDownloadUrl, type AppRelease } from "@/lib/releases.functions";

const title = "Download ONARU";
const description = "Private download portal for the ONARU application.";

export const Route = createFileRoute("/_authenticated/dl-app")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DownloadPortal,
});

function formatSize(bytes: number | null) {
  if (!bytes) return null;
  const mb = bytes / (1024 * 1024);
  return `${mb >= 100 ? Math.round(mb) : mb.toFixed(1)} MB`;
}

function DownloadPortal() {
  const fetchReleases = useServerFn(listAppReleases);
  const requestUrl = useServerFn(getAppDownloadUrl);
  const [pending, setPending] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["app-releases"],
    queryFn: () => fetchReleases(),
  });
  const releases = (data ?? []) as AppRelease[];

  async function download(release: AppRelease) {
    setPending(release.id);
    try {
      const { url } = await requestUrl({ data: { releaseId: release.id } });
      window.location.href = url;
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Download unavailable");
    } finally {
      setPending(null);
    }
  }

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-5 py-20">
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-[-30%] h-[80vh] w-[110vw] -translate-x-1/2 rounded-full opacity-40 blur-3xl"
        style={{
          background:
            "var(--gradient-gold, radial-gradient(circle, rgba(201,162,39,.25), transparent 70%))",
        }}
      />

      <div className="relative w-full max-w-[520px]">
        <div className="flex flex-col items-center text-center">
          <OnaruMark className="h-12 w-12" />
          <h1 className="mt-6 text-2xl font-semibold tracking-tight text-foreground">
            Download ONARU
          </h1>
          <p className="mt-3 max-w-[420px] text-sm leading-relaxed text-muted-foreground">
            The ONARU application — one workspace for your companies, work, approvals and
            intelligence. This portal is private to ONARU people.
          </p>
        </div>

        <div className="mt-10 space-y-3">
          {isLoading && (
            <div className="rounded-2xl border border-border bg-card/40 p-6 text-center text-sm text-muted-foreground">
              Checking for the latest build…
            </div>
          )}

          {!isLoading && releases.length === 0 && (
            <div className="rounded-2xl border border-border bg-card/40 p-6 text-center">
              <p className="text-sm text-foreground">No build published yet</p>
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                Releases appear here as soon as the first installer is published.
              </p>
            </div>
          )}

          {releases.map((release) => (
            <article
              key={release.id}
              className="rounded-2xl border border-border bg-card/40 p-5 backdrop-blur-sm"
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    {release.platform}
                  </p>
                  <p className="mt-1 text-lg font-semibold tracking-tight text-foreground">
                    Version {release.version}
                    {release.build ? (
                      <span className="ml-2 text-xs font-normal text-muted-foreground">
                        build {release.build}
                      </span>
                    ) : null}
                  </p>
                </div>
                <button
                  type="button"
                  disabled={pending === release.id}
                  onClick={() => void download(release)}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
                >
                  {pending === release.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Download className="h-4 w-4" />
                  )}
                  Download
                </button>
              </div>

              <dl className="mt-4 flex flex-wrap gap-x-6 gap-y-1 text-xs text-muted-foreground">
                <div className="flex gap-2">
                  <dt>Channel</dt>
                  <dd className="text-foreground/80">{release.channel}</dd>
                </div>
                <div className="flex gap-2">
                  <dt>Released</dt>
                  <dd className="text-foreground/80">
                    {new Date(release.released_at).toLocaleDateString()}
                  </dd>
                </div>
                {formatSize(release.file_size) && (
                  <div className="flex gap-2">
                    <dt>Size</dt>
                    <dd className="text-foreground/80">{formatSize(release.file_size)}</dd>
                  </div>
                )}
              </dl>

              {release.notes && (
                <p className="mt-4 whitespace-pre-line border-t border-border pt-4 text-xs leading-relaxed text-muted-foreground">
                  {release.notes}
                </p>
              )}
            </article>
          ))}
        </div>

        <p className="mt-8 flex items-center justify-center gap-2 text-center text-[11px] text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5" />
          Download links are personal and expire after two minutes.
        </p>
      </div>
    </main>
  );
}
