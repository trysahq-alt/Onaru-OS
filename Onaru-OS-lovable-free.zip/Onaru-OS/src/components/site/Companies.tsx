import { Reveal } from "./Reveal";
import { companies, type Company } from "@/data/companies";

function EcosystemCard({ c, index }: { c: Company; index: number }) {
  return (
    <a
      href={c.href}
      className={`group relative flex min-h-[420px] flex-col justify-end overflow-hidden rounded-[1.75rem] bg-card p-7 hairline float-card md:min-h-[460px] ${
        c.feature ? "lg:col-span-2" : ""
      }`}
      style={{ transitionTimingFunction: "var(--ease-lux)" }}
      aria-label={c.cta}
    >
      <img
        src={c.image}
        alt=""
        aria-hidden="true"
        loading="lazy"
        width={1600}
        height={1100}
        className="absolute inset-0 h-full w-full object-cover opacity-35 transition-[transform,opacity] duration-[1400ms] group-hover:scale-[1.06] group-hover:opacity-50"
        style={{ transitionTimingFunction: "var(--ease-lux)" }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/35" />

      <div className="relative">
        <div className="flex items-start justify-between gap-4">
          {c.logo ? (
            <div
              className={`flex h-14 w-28 shrink-0 items-center justify-center overflow-hidden rounded-xl ${
                c.tone === "light" ? "bg-foreground/95" : "bg-background/70 hairline"
              }`}
            >
              <img
                src={c.logo}
                alt={`${c.name} logo`}
                loading="lazy"
                className="h-full w-full object-contain p-2"
                style={{ transform: `scale(${c.zoom ?? 1})` }}
              />
            </div>
          ) : (
            <div className="flex h-14 items-center rounded-xl bg-background/60 px-4 hairline">
              <span className="wordmark text-[13px] text-foreground/80">{c.name}</span>
            </div>
          )}
          <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
            {String(index + 1).padStart(2, "0")}
          </span>
        </div>

        <div className="mt-8 flex items-center gap-3">
          <h3 className="text-[22px] tracking-tight text-foreground md:text-2xl">{c.name}</h3>
          <span className="h-1 w-1 rounded-full bg-gold/60" />
          <span className="text-[13px] text-muted-foreground">{c.label}</span>
        </div>

        <p className="mt-3 text-[13px] italic text-gold-soft/80">{c.tagline}</p>
        <p className="mt-3 max-w-[46ch] text-[14px] leading-relaxed text-muted-foreground">
          {c.description}
        </p>

        <div
          className="grid overflow-hidden transition-[grid-template-rows,opacity] duration-700 [grid-template-rows:0fr] opacity-0 group-hover:[grid-template-rows:1fr] group-hover:opacity-100 group-focus-visible:[grid-template-rows:1fr] group-focus-visible:opacity-100"
          style={{ transitionTimingFunction: "var(--ease-lux)" }}
        >
          <div className="min-h-0">
            <div className="flex flex-wrap gap-2 pt-5">
              {c.highlights.map((h) => (
                <span
                  key={h}
                  className="rounded-full border border-border px-3 py-1 text-[11px] text-muted-foreground"
                >
                  {h}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-7 flex items-center justify-between border-t border-border pt-5">
          <span className="eyebrow">{c.category}</span>
          <span className="text-[13px] text-muted-foreground transition-colors duration-500 group-hover:text-gold">
            {c.cta}&nbsp;→
          </span>
        </div>
      </div>
    </a>
  );
}

export function Companies() {
  return (
    <section id="companies" className="relative border-t border-border py-32 md:py-52">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10">
        <Reveal>
          <p className="eyebrow">01 — ONARU Companies</p>
          <h2 className="display-lg mt-6 max-w-[16ch]">
            The ONARU <span className="text-gold-gradient">Ecosystem.</span>
          </h2>
          <p className="mt-7 max-w-[58ch] text-[15px] leading-relaxed text-muted-foreground md:text-lg">
            We build brands, products and experiences designed for modern life.
          </p>
        </Reveal>

        <div className="mt-16 grid gap-5 md:mt-24 md:grid-cols-2 lg:grid-cols-3">
          {companies.map((c, i) => (
            <Reveal
              key={c.slug}
              delay={(i % 3) * 0.06}
              className={c.feature ? "lg:col-span-2" : undefined}
            >
              <EcosystemCard c={c} index={i} />
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="mt-12 flex flex-wrap items-center gap-4">
            <a href="/companies" className="btn-gold">
              View all companies
            </a>
            <span className="text-[13px] text-muted-foreground">
              Six companies. One operating thesis.
            </span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
