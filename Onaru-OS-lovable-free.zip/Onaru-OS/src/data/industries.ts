export type Industry = {
  slug: string;
  name: string;
  headline: string;
  summary: string;
  challenges: string[];
  approach: string[];
  services: string[];
  metric: { value: string; label: string };
};

export const industries: Industry[] = [
  {
    slug: "fashion",
    name: "Fashion",
    headline: "Desire is manufactured. We know how it's made.",
    summary:
      "Fashion brands live and die on imagery, drop cadence and community. We build the visual language and the commerce engine behind it.",
    challenges: [
      "Imagery that doesn't justify the price point",
      "Drops that sell out with no data captured",
      "High returns from poor product presentation",
      "Paid spend that stops working after the first month",
    ],
    approach: [
      "Editorial-grade campaign and lookbook production",
      "Drop calendars with waitlist and scarcity mechanics",
      "Product photography engineered for lower returns",
      "Creative-led paid social with weekly refresh",
    ],
    services: ["brand-identity", "commercial-photography", "product-photography", "paid-advertising", "social-media-marketing"],
    metric: { value: "3.4×", label: "average return on ad spend across fashion clients" },
  },
  {
    slug: "beauty",
    name: "Beauty",
    headline: "Proof, ritual and repeat purchase.",
    summary:
      "Beauty is won on before-and-after evidence and retention economics. We build both.",
    challenges: [
      "Crowded category with weak differentiation",
      "Claims that need substantiating without sounding clinical",
      "Low repeat purchase rates",
      "Creator partnerships with no measurable return",
    ],
    approach: [
      "Ingredient and results-led messaging architecture",
      "UGC and creator pipelines at production volume",
      "Retention email and subscription flows",
      "Full-funnel measurement to true LTV",
    ],
    services: ["brand-strategy", "content-strategy", "email-marketing", "paid-advertising", "product-photography"],
    metric: { value: "+41%", label: "average lift in repeat purchase rate" },
  },
  {
    slug: "healthcare",
    name: "Healthcare",
    headline: "Trust first. Everything else follows.",
    summary:
      "Healthcare marketing has to be accurate, compliant and human at the same time. We build patient journeys that respect all three.",
    challenges: [
      "Compliance constraints on claims and creative",
      "Long, high-consideration decision cycles",
      "Fragmented patient acquisition and booking",
      "Reputation exposure across review platforms",
    ],
    approach: [
      "Evidence-led content and clinician-reviewed messaging",
      "Local and organic search dominance",
      "Booking journey and intake automation",
      "Reputation and review management",
    ],
    services: ["seo", "web-design", "marketing-automation", "content-strategy", "analytics-reporting"],
    metric: { value: "2.1×", label: "average increase in qualified patient enquiries" },
  },
  {
    slug: "restaurants",
    name: "Restaurants",
    headline: "Full tables on the nights that matter.",
    summary:
      "Restaurant marketing is a local, visual and repeat-visit game. We handle discovery, desire and the return trip.",
    challenges: [
      "Inconsistent weekday covers",
      "Food photography that doesn't do the kitchen justice",
      "Discovery dominated by aggregators",
      "No direct relationship with regulars",
    ],
    approach: [
      "Food and interior photography built for appetite appeal",
      "Local SEO and map pack dominance",
      "Reservation and loyalty automation",
      "Geo-targeted social campaigns around peak windows",
    ],
    services: ["commercial-photography", "social-media-marketing", "seo", "paid-advertising", "email-marketing"],
    metric: { value: "+28%", label: "average increase in midweek covers" },
  },
  {
    slug: "hospitality",
    name: "Hospitality",
    headline: "Direct bookings beat commission every time.",
    summary:
      "Every booking through an aggregator costs you margin and the guest relationship. We shift the balance toward direct.",
    challenges: [
      "OTA commission eroding margin",
      "Seasonal demand swings",
      "Property imagery that undersells the experience",
      "No guest data for repeat marketing",
    ],
    approach: [
      "Cinematic property films and stills",
      "Direct-booking site with rate parity messaging",
      "Seasonal campaign calendars and packages",
      "Guest lifecycle email and loyalty programmes",
    ],
    services: ["brand-films", "web-design", "commercial-photography", "email-marketing", "paid-advertising"],
    metric: { value: "+52%", label: "average growth in direct bookings" },
  },
  {
    slug: "real-estate",
    name: "Real Estate",
    headline: "Fewer, better leads. Faster sell-through.",
    summary:
      "Real estate marketing wastes money on volume. We optimise for qualified buyers and shorter cycles.",
    challenges: [
      "High lead volume, low qualification",
      "Long sales cycles with poor follow-up",
      "Listings that look like every other listing",
      "Sales teams with no CRM discipline",
    ],
    approach: [
      "Development brand and film production",
      "Qualified lead capture with scoring and routing",
      "Automated nurture across long consideration windows",
      "Sales enablement and CRM implementation",
    ],
    services: ["brand-films", "marketing-automation", "paid-advertising", "web-design", "analytics-reporting"],
    metric: { value: "-34%", label: "average reduction in cost per qualified lead" },
  },
  {
    slug: "technology",
    name: "Technology",
    headline: "Positioning that makes the product obvious.",
    summary:
      "Great products lose to well-positioned ones constantly. We fix the story, the funnel and the activation path.",
    challenges: [
      "Feature-led messaging nobody remembers",
      "Trial-to-paid conversion leaking value",
      "Long enterprise cycles with no nurture",
      "Product-led growth without instrumentation",
    ],
    approach: [
      "Category and positioning strategy",
      "Product marketing and launch systems",
      "Onboarding and activation optimisation",
      "Demand generation with full attribution",
    ],
    services: ["brand-strategy", "ui-ux-design", "content-strategy", "marketing-automation", "analytics-reporting"],
    metric: { value: "+63%", label: "average improvement in trial-to-paid conversion" },
  },
  {
    slug: "creators",
    name: "Creators",
    headline: "Turn an audience into a business.",
    summary:
      "Audience is not income. We build the products, funnels and operations that convert attention into durable revenue.",
    challenges: [
      "Revenue entirely dependent on brand deals",
      "No owned audience outside the platform",
      "Product launches with no infrastructure",
      "Burnout from doing everything personally",
    ],
    approach: [
      "Revenue model design across products and services",
      "Email list and owned-audience build",
      "Launch systems and sales pages",
      "Production and operations support",
    ],
    services: ["growth-consulting", "email-marketing", "web-design", "brand-films", "marketing-automation"],
    metric: { value: "5", label: "average revenue streams built per creator client" },
  },
  {
    slug: "personal-brands",
    name: "Personal Brands",
    headline: "Authority, engineered.",
    summary:
      "Founders, executives and experts who want the market to know exactly what they stand for — and to inbound accordingly.",
    challenges: [
      "Visibility without commercial return",
      "Inconsistent presence across platforms",
      "No clear point of view",
      "Time scarcity for content production",
    ],
    approach: [
      "Personal positioning and point-of-view definition",
      "Executive portrait and film production",
      "Low-time-cost content systems",
      "Speaking, PR and inbound pipeline",
    ],
    services: ["brand-strategy", "content-strategy", "commercial-photography", "social-media-marketing", "growth-consulting"],
    metric: { value: "4×", label: "average growth in inbound opportunities" },
  },
  {
    slug: "luxury",
    name: "Luxury",
    headline: "Restraint is the strategy.",
    summary:
      "Luxury marketing fails when it shouts. We build desire through scarcity, craft and disciplined visual language.",
    challenges: [
      "Discounting pressure eroding brand equity",
      "Digital presence that cheapens the product",
      "Clienteling with no data behind it",
      "Reaching high-net-worth audiences efficiently",
    ],
    approach: [
      "Refined identity systems with strict governance",
      "Editorial campaign production",
      "Invitation-only and clienteling programmes",
      "Precision targeting over reach",
    ],
    services: ["brand-identity", "creative-campaigns", "commercial-photography", "web-design", "email-marketing"],
    metric: { value: "+22%", label: "average increase in average order value" },
  },
  {
    slug: "retail",
    name: "Retail",
    headline: "One customer, every channel.",
    summary:
      "Retail growth now depends on connecting store, marketplace and direct channels into a single view of the customer.",
    challenges: [
      "Disconnected online and in-store data",
      "Marketplace dependency squeezing margin",
      "Inventory and campaign timing misalignment",
      "Weak retention beyond the first purchase",
    ],
    approach: [
      "Omnichannel measurement and unified customer data",
      "Direct channel growth and margin recovery",
      "Catalogue photography at scale",
      "Lifecycle retention programmes",
    ],
    services: ["product-photography", "analytics-reporting", "email-marketing", "paid-advertising", "marketing-automation"],
    metric: { value: "+37%", label: "average growth in direct channel revenue" },
  },
  {
    slug: "professional-services",
    name: "Professional Services",
    headline: "Expertise that generates its own pipeline.",
    summary:
      "Law, finance, consulting and agencies win on credibility and referral. We make both systematic.",
    challenges: [
      "Pipeline entirely dependent on referrals",
      "Undifferentiated positioning in a crowded field",
      "Partners with no time for business development",
      "Long cycles with no structured follow-up",
    ],
    approach: [
      "Specialist positioning and proof architecture",
      "Thought leadership and publishing systems",
      "Referral programme design",
      "CRM and pipeline automation",
    ],
    services: ["brand-strategy", "content-strategy", "seo", "marketing-automation", "growth-consulting"],
    metric: { value: "3×", label: "average growth in non-referral pipeline" },
  },
];

export const getIndustry = (slug: string) => industries.find((i) => i.slug === slug);
