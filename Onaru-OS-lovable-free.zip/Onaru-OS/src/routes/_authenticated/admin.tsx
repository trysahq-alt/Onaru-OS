import { createFileRoute, Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSessionAccount, roleLabels } from "@/hooks/useSession";
import { OnaruMark } from "@/components/site/Wordmark";
import {
  Activity,
  BarChart3,
  Briefcase,
  Building2,
  FileText,
  Image as ImageIcon,
  Inbox,
  LayoutDashboard,
  LogOut,
  Mail,
  Newspaper,
  Settings,
  Sparkles,
  Users,
  Layers,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "ONARU Studio — Content & Growth OS" },
      { name: "description", content: "Manage the ONARU website, content, media and enquiries." },
      { property: "og:title", content: "ONARU Studio" },
      { property: "og:description", content: "Manage the ONARU website, content, media and enquiries." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminShell,
});

type NavItem = {
  to: string;
  label: string;
  icon: React.ElementType;
  exact?: boolean;
};

const nav: NavItem[] = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/pages", label: "Pages", icon: Layers },
  { to: "/admin/services", label: "Services", icon: Sparkles },
  { to: "/admin/industries", label: "Industries", icon: Building2 },
  { to: "/admin/work", label: "Work", icon: Briefcase },
  { to: "/admin/insights", label: "Insights", icon: Newspaper },
];

const mobileNav = nav.filter((n) =>
  ["/admin", "/admin/pages", "/admin/services", "/admin/work", "/admin/insights"].includes(n.to),
);

function AdminShell() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const account = useSessionAccount();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", search: { redirect: "/admin" }, replace: true });
  }

  const isActive = (to: string, exact?: boolean) =>
    exact ? pathname === to : pathname.startsWith(to);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[248px] flex-col border-r border-border bg-card/40 lg:flex">
        <div className="flex items-center gap-3 px-5 py-6">
          <OnaruMark className="h-8 w-8" />
          <div>
            <p className="text-sm font-semibold leading-tight">ONARU Studio</p>
            <p className="text-[11px] text-muted-foreground">Content & Growth OS</p>
          </div>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 pb-4">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to as never}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${
                isActive(item.to, item.exact)
                  ? "bg-gold/10 text-gold"
                  : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              }`}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="border-t border-border p-3">
          <div className="mb-2 px-2">
            <p className="truncate text-xs text-foreground">{account.data?.email}</p>
            <p className="text-[11px] text-muted-foreground">
              {account.data?.roles?.length
                ? account.data.roles.map((r) => roleLabels[r]).join(", ")
                : "No role assigned"}
            </p>
          </div>
          <button
            onClick={signOut}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-muted-foreground transition hover:bg-white/5 hover:text-foreground"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      </aside>

      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-background/85 px-4 py-3 backdrop-blur lg:hidden">
        <div className="flex items-center gap-2.5">
          <OnaruMark className="h-7 w-7" />
          <span className="text-sm font-semibold">ONARU Studio</span>
        </div>
        <button onClick={signOut} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-white/5">
          <LogOut className="h-4 w-4" />
        </button>
      </header>

      <div className="lg:pl-[248px]">
        <div className="mx-auto w-full max-w-[1100px] px-4 py-6 pb-28 sm:px-6 lg:py-10 lg:pb-16">
          {account.data && account.data.roles.length === 0 ? (
            <div className="rounded-2xl border border-border bg-card/60 p-10 text-center">
              <h1 className="text-lg font-semibold">Awaiting access</h1>
              <p className="mt-2 text-sm text-muted-foreground">
                Your account has no role yet. Ask a Super Admin to assign one.
              </p>
            </div>
          ) : (
            <Outlet />
          )}
        </div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-border bg-background/95 backdrop-blur lg:hidden">
        {mobileNav.map((item) => (
          <Link
            key={item.to}
            to={item.to as never}
            className={`flex flex-col items-center gap-1 py-3 text-[10px] ${
              isActive(item.to, item.exact) ? "text-gold" : "text-muted-foreground"
            }`}
          >
            <item.icon className="h-5 w-5" />
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
