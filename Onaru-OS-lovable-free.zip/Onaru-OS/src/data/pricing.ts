export type Package = {
  slug: string;
  name: string;
  positioning: string;
  bestFor: string;
  priceHint: string;
  commitment: string;
  includes: string[];
  featured?: boolean;
};

export const packages: Package[] = [
  {
    slug: "growth-starter",
    name: "Growth Starter",
    positioning: "Get clarity before you spend another naira.",
    bestFor: "Startups and founders who need direction, not a retainer.",
    priceHint: "From $1,500",
    commitment: "One-off engagement · 3–4 weeks",
    includes: [
      "Deep-dive strategy session with a senior strategist",
      "Full marketing and funnel audit",
      "Competitor and category analysis",
      "12-month growth roadmap",
      "Prioritised recommendation list with effort/impact scoring",
      "60-minute walkthrough and Q&A",
    ],
  },
  {
    slug: "growth-accelerator",
    name: "Growth Accelerator",
    positioning: "Build the machine, then hand you the keys.",
    bestFor: "Brands with product-market fit ready to scale deliberately.",
    priceHint: "From $6,000",
    commitment: "Project engagement · 8–10 weeks",
    featured: true,
    includes: [
      "Everything in Growth Starter",
      "Brand strategy and messaging architecture",
      "Campaign planning and creative direction",
      "Content strategy and quarterly calendar",
      "Paid advertising account setup and first campaigns",
      "Analytics dashboard and measurement framework",
      "Team enablement and handover",
    ],
  },
  {
    slug: "growth-partner",
    name: "Growth Partner",
    positioning: "We run growth with you, every month.",
    bestFor: "Established brands that want an accountable growth team.",
    priceHint: "From $4,500 / month",
    commitment: "Monthly retainer · 6-month minimum",
    includes: [
      "Dedicated growth strategist and delivery pod",
      "Full campaign management across channels",
      "Advertising management and creative production",
      "Monthly creative planning and asset production",
      "Continuous optimisation and testing programme",
      "Weekly reporting and monthly strategy review",
      "Priority access to studio and production capacity",
    ],
  },
  {
    slug: "enterprise",
    name: "Enterprise",
    positioning: "A growth department, without the headcount.",
    bestFor: "Multi-brand groups and enterprises with complex requirements.",
    priceHint: "Bespoke",
    commitment: "Annual partnership",
    includes: [
      "Completely tailored scope and team",
      "Dedicated cross-functional growth team",
      "Full marketing systems architecture",
      "AI and automation implementation",
      "Unlimited creative production capacity",
      "Executive and board-level reporting",
      "Unlimited strategy sessions",
      "Enterprise SLA and dedicated support channel",
    ],
  },
];

export const getPackage = (slug: string) => packages.find((p) => p.slug === slug);

export type Consultation = {
  slug: string;
  name: string;
  duration: string;
  price: string;
  summary: string;
  includes: string[];
  preparation: string[];
};

export const consultations: Consultation[] = [
  {
    slug: "strategy-call",
    name: "30-Minute Strategy Call",
    duration: "30 minutes",
    price: "$95",
    summary: "A focused conversation on one specific growth problem, with clear next steps.",
    includes: [
      "Pre-call brief review",
      "30 minutes with a senior strategist",
      "Three prioritised recommendations",
      "Written follow-up summary",
    ],
    preparation: [
      "Describe the single problem you most want solved",
      "Share access to analytics if relevant",
      "Have your current numbers to hand",
    ],
  },
  {
    slug: "growth-session",
    name: "60-Minute Growth Session",
    duration: "60 minutes",
    price: "$180",
    summary: "A working session on your growth model, funnel maths and channel priorities.",
    includes: [
      "Pre-session data review",
      "60-minute working session",
      "Growth model walkthrough",
      "Channel priority recommendations",
      "Written action plan",
    ],
    preparation: [
      "Share revenue, CAC and conversion data in advance",
      "Bring the decision-makers, not just the marketer",
      "Define what a good next quarter looks like",
    ],
  },
  {
    slug: "brand-audit",
    name: "Brand Audit Session",
    duration: "90 minutes",
    price: "$320",
    summary: "An honest external read on your positioning, identity and market perception.",
    includes: [
      "Full brand and competitor review before the session",
      "90-minute audit presentation",
      "Positioning gap analysis",
      "Identity and messaging assessment",
      "Written audit document",
    ],
    preparation: [
      "Send brand guidelines and recent campaign work",
      "List your three closest competitors",
      "Share any customer research you hold",
    ],
  },
  {
    slug: "marketing-audit",
    name: "Marketing Audit",
    duration: "90 minutes",
    price: "$320",
    summary: "A forensic review of channels, spend and performance, with the leaks marked.",
    includes: [
      "Ad account, analytics and CRM review",
      "90-minute findings session",
      "Wasted-spend analysis",
      "Channel reallocation recommendations",
      "Written audit report",
    ],
    preparation: [
      "Grant read access to ad accounts and analytics",
      "Share the last 12 months of spend by channel",
      "Confirm your target CAC and payback period",
    ],
  },
  {
    slug: "ai-automation",
    name: "AI & Automation Consultation",
    duration: "60 minutes",
    price: "$220",
    summary: "Find the workflows in your business where AI changes a real number.",
    includes: [
      "Workflow discovery questionnaire",
      "60-minute opportunity session",
      "Prioritised use-case shortlist",
      "Rough ROI sizing per use case",
      "Written roadmap outline",
    ],
    preparation: [
      "List the repetitive tasks eating your team's week",
      "Note the tools you already pay for",
      "Bring one process you'd love to never do again",
    ],
  },
  {
    slug: "website-strategy",
    name: "Website Strategy",
    duration: "60 minutes",
    price: "$180",
    summary: "Structure, conversion path and technical priorities for a site that performs.",
    includes: [
      "Pre-session site and speed audit",
      "60-minute strategy session",
      "Conversion path recommendations",
      "Technical and SEO priority list",
      "Written summary",
    ],
    preparation: [
      "Share your current site and analytics access",
      "Define the one action visitors should take",
      "Collect examples of sites you admire",
    ],
  },
  {
    slug: "campaign-strategy",
    name: "Campaign Strategy",
    duration: "90 minutes",
    price: "$280",
    summary: "Shape a campaign platform, creative direction and rollout plan in one sitting.",
    includes: [
      "Brief review and category scan",
      "90-minute creative strategy session",
      "Campaign platform direction",
      "Channel and rollout plan",
      "Written creative brief you can hand to any team",
    ],
    preparation: [
      "Define the business objective, not the deliverable",
      "Share budget range and launch window",
      "Bring any existing creative assets",
    ],
  },
  {
    slug: "founder-advisory",
    name: "Founder Advisory",
    duration: "90 minutes",
    price: "$450",
    summary: "Direct time with ONARU's founder on positioning, growth and building a company.",
    includes: [
      "Pre-session business review",
      "90 minutes of founder-level counsel",
      "Candid assessment of the business",
      "Priority and sequencing guidance",
      "Written follow-up with next steps",
    ],
    preparation: [
      "Write down the decision you're stuck on",
      "Share your last board or investor update",
      "Be ready for a direct conversation",
    ],
  },
];

export const getConsultation = (slug: string) => consultations.find((c) => c.slug === slug);
