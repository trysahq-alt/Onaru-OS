import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { hqProducts } from "@/lib/hq.functions";
import { Panel, Empty, Tag, num, relativeTime } from "@/components/hq/ui";

export const Route = createFileRoute("/_authenticated/hq/products/")({ component: HQProducts });

function HQProducts() {
  const fetchProducts = useServerFn(hqProducts);
  const { data, isLoading, error } = useQuery({ queryKey: ["hq", "products"], queryFn: () => fetchProducts() });

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading products…</p>;
  if (error) return <p className="text-sm text-red-300">{(error as Error).message}</p>;

  const rows = (data ?? []) as Array<Record<string, unknown>>;

  return (
    <div className="space-y-6">
      <header>
        <p className="text-[10px] uppercase tracking-[0.3em] text-gold">Onaru Core</p>
        <h1 className="mt-2 text-2xl font-semibold sm:text-3xl">Product performance</h1>
      </header>

      {rows.length === 0 ? (
        <Empty
          title="No products connected yet."
          body="Register a product in the Integration Center to begin tracking performance."
          action={
            <Link to="/hq/integrations" className="rounded-full bg-gold px-4 py-2 text-xs font-medium text-black">
              Connect your first product →
            </Link>
          }
        />
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {rows.map((p) => {
            const events = Number(p.events_30d ?? 0);
            const prev = Number(p.events_prev_30d ?? 0);
            const growth = prev > 0 ? Math.round(((events - prev) / prev) * 100) : null;
            return (
              <Link key={String(p.product_id)} to="/hq/products/$id" params={{ id: String(p.product_id) }}>
                <Panel className="transition hover:border-gold/30">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-base font-semibold">{String(p.name)}</p>
                      <p className="text-xs text-muted-foreground">{String(p.slug)}</p>
                    </div>
                    <div className="flex gap-1.5">
                      <Tag tone={p.status === "active" ? "good" : "muted"}>{String(p.status)}</Tag>
                      <Tag>{String(p.environment)}</Tag>
                    </div>
                  </div>
                  <dl className="mt-4 grid grid-cols-3 gap-3 text-sm">
                    <div><dt className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Users</dt><dd className="tabular-nums">{num(p.users)}</dd></div>
                    <div><dt className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Active 30d</dt><dd className="tabular-nums">{num(p.active_users_30d)}</dd></div>
                    <div><dt className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Events 30d</dt><dd className="tabular-nums">{num(events)}</dd></div>
                    <div><dt className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Orgs</dt><dd className="tabular-nums">{num(p.organizations)}</dd></div>
                    <div><dt className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Revenue 30d</dt><dd className="tabular-nums">{num(p.revenue_30d)}</dd></div>
                    <div><dt className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Growth</dt><dd className="tabular-nums">{growth === null ? "—" : `${growth >= 0 ? "+" : ""}${growth}%`}</dd></div>
                  </dl>
                  <p className="mt-3 text-xs text-muted-foreground">
                    Last activity {relativeTime(p.last_activity_at as string | null)}
                  </p>
                </Panel>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
