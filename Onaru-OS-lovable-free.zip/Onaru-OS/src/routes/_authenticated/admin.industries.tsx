import { createFileRoute } from "@tanstack/react-router";
import { ResourceManager } from "@/components/admin/ResourceManager";

export const Route = createFileRoute("/_authenticated/admin/industries")({
  component: () => (
    <ResourceManager
      table="industries"
      title="Industries"
      singular="Industry"
      orderBy={{ column: "sort_order", ascending: true }}
      columns={["title", "slug"]}
      searchColumn="title"
      defaults={{ status: "draft", sort_order: 0 }}
      fields={[
        { name: "title", label: "Title", type: "text" },
        { name: "slug", label: "Slug", type: "slug", from: "title" },
        { name: "description", label: "Short description", type: "textarea" },
        { name: "overview", label: "Overview", type: "richtext" },
        { name: "cta", label: "CTA text", type: "text" },
        { name: "cover_image", label: "Cover image", type: "image" },
        { name: "sort_order", label: "Sort order", type: "number" },
        { name: "status", label: "Status", type: "status" },
        { name: "seo", label: "SEO (JSON)", type: "json" },
      ]}
    />
  ),
});
