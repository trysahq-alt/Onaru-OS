import { createFileRoute } from "@tanstack/react-router";
import { ResourceManager } from "@/components/admin/ResourceManager";

export const Route = createFileRoute("/_authenticated/admin/services")({
  component: () => (
    <ResourceManager
      table="services"
      title="Services"
      singular="Service"
      description="The 19 service offerings shown across the site."
      orderBy={{ column: "sort_order", ascending: true }}
      columns={["name", "category", "slug"]}
      searchColumn="name"
      defaults={{ status: "draft", sort_order: 0, featured: false }}
      fields={[
        { name: "name", label: "Name", type: "text" },
        { name: "slug", label: "Slug", type: "slug", from: "name" },
        { name: "category", label: "Category", type: "text" },
        { name: "description", label: "Short description", type: "textarea" },
        { name: "overview", label: "Overview", type: "richtext" },
        { name: "deliverables", label: "Deliverables", type: "list" },
        { name: "process", label: "Process steps", type: "list" },
        { name: "timeline", label: "Timeline", type: "text" },
        { name: "faq", label: "FAQ (JSON array)", type: "json" },
        { name: "cover_image", label: "Cover image", type: "image" },
        { name: "featured", label: "Featured", type: "boolean" },
        { name: "sort_order", label: "Sort order", type: "number" },
        { name: "status", label: "Status", type: "status" },
        { name: "seo", label: "SEO (JSON)", type: "json" },
      ]}
    />
  ),
});
