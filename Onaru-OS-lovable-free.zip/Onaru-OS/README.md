# ONARU Digital Legacy

ONARU LIMITED — Premium Corporate Website (Master Prompt)

Build a world-class, award-winning corporate website for ONARU LIMITED, inspired by Apple, Stripe, Framer, Linear, Notion, Arc Browser, and Vercel.

This is not a portfolio website.

This is the digital headquarters of a modern African holding company building technology, media, creative infrastructure, education, AI, and impact-driven businesses.

The design should feel timeless, premium, cinematic, and minimal.

Think:

Apple keynote

Stripe gradients

Framer interactions

Linear simplicity

Porsche luxury

Nothing generic.



Files I’ll Attach

I’ll attach:

ONARU Logo

Founder portrait (Abayomi Onalaru)

Logos of all portfolio companies

Use these throughout the experience.



Design Language

Background

Matte Black

#060606

Cards

#111111

Borders

rgba(255,255,255,.08)

Typography

SF Pro Display

Inter

IBM Plex Mono

Accent

Luxury Gold

White

Very subtle gradients

Large spacing

Massive typography

Glass effects

Smooth blur

Premium animations

No bright colors.

No SaaS templates.

No generic icons.

Every section should feel editorial.



Hero Section

Full-screen cinematic hero.

Imagine a Framer landing page.

Huge typography.

Animated logo reveal.

Founder portrait slowly fades in.

Luxury motion.

Headline:

Building Companies That Shape Africa’s Future.

Subheadline:

ONARU Limited is a venture holding company creating technology, media, education and creative businesses that solve real problems at scale.

Buttons

Explore Our Companies

Read Our Story

Background animation

Subtle moving light

Noise texture

Floating particles

Gold light reflections



Founder Section

Large editorial section.

Use my portrait.

Title

Meet The Founder

Name

Abayomi Onalaru

CEO & Founder

Write a premium founder story.

Explain

• photographer turned entrepreneur

• building systems instead of freelancing

• creating companies

• solving problems

• empowering African creators

• long-term vision

Include signature.



Companies Section

Display beautiful premium cards.

Each logo appears beautifully.

Hover animations.

Each opens its own detail page.

Companies include

TRYSA

Business Operating System

YV Studios Africa

Creative Spaces

PlayBaaq

Performance Platform

Yomi Unscripted

Media

TRYSA Academy

Education

YV Entertainment

Media

Laruu

Luxury Brand

Future Ventures

Coming Soon

Each company card includes

Logo

Mission

Short description

Industry

Launch status

Visit Company



About ONARU

Timeline animation.

Beginning

Today

Future

Tell the story of building an African holding company.

Explain why ONARU exists.



Philosophy

Large typography.

Beautiful cards.

“We don’t chase trends.”

“We build systems.”

“We solve meaningful problems.”

“We think in decades.”

“We create impact before profit.”



10 Articles from the Founder

Beautiful editorial magazine layout.

Each article opens into a reading page.

Articles:

1.

Why Africa Doesn’t Need More Startups. It Needs Better Systems.

2.

How I Went From Photographer To Building Companies

3.

The Future Of African Creators

4.

Building Products That Outlive Their Founders

5.

Why Great Design Wins

6.

Lessons From Failing Fast

7.

Building TRYSA

8.

How Small Teams Build Big Companies

9.

Why I Believe Creativity Is Infrastructure

10.

The Long Game



10 Articles from ONARU

Company publications.

Topics

The Future of AI in Africa

The Creator Economy

Business Systems

Creative Infrastructure

Technology

Design

Education

Media

Innovation

Economic Development

Magazine-style layout.



Newsroom

Latest updates.

Press releases.

Announcements.

Investments.

New launches.



Impact

Animated statistics.

Companies Built

Creators Empowered

Countries Reached

Projects Completed

Years Building



Vision

Massive typography.

“Our ambition is simple.”

Build companies that improve how Africa creates, works and grows.



Careers

Join ONARU.

Beautiful hiring page.

Future opportunities.

Culture.

Benefits.



Media Kit

Download

Logo

Brand assets

Press kit

Founder photos



Investor Relations

Holding structure

Mission

Long-term strategy

Governance

Company overview



Contact

Minimal form.

Email

LinkedIn

Instagram

Office location



Footer

Elegant.

Minimal.

ONARU Logo

Navigation

Legal

Privacy

Terms

Copyright



Motion Design

Everything should move beautifully.

Framer-quality animations.

Luxury easing.

Fade

Blur

Parallax

Reveal

Scroll storytelling

Floating cards

Hover interactions

Animated gradients

Smooth page transitions



Performance

95+ Lighthouse

Responsive

Mobile-first

SEO optimized

Accessible

Fast loading



Technical Stack

Next.js 15

React 19

TypeScript

Tailwind CSS

Framer Motion

GSAP (only where needed)

Lenis smooth scrolling

Shadcn UI

Dark mode

CMS-ready architecture



CMS Features (Admin)

Create a secure admin dashboard where I can manage the website without editing code.

I should be able to:

Upload and replace the homepage hero content.

Manage all founder articles.

Manage all ONARU publications.

Publish news and press releases.

Add, edit, archive, or remove portfolio companies.

Upload company logos and brand assets.

Update the founder biography and portrait.

Manage careers and job openings.

Upload downloadable media kits.

Edit every page’s SEO title, description, and Open Graph image.

Schedule future posts.

Save drafts before publishing.

Manage navigation and footer links.


**Live app**: https://onaru.app




## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
