import { createFileRoute } from "@tanstack/react-router";
import { ResourceManager } from "@/components/admin/ResourceManager";

export const Route = createFileRoute("/_authenticated/admin/pages")({
  component: () => (
    <ResourceManager
      table="pages"
      title="Pages"
      singular="Page"
      description="Website pages built from content blocks."
      orderBy={{ column: "sort_order", ascending: true }}
      columns={["title", "slug"]}
      searchColumn="title"
      defaults={{ status: "draft", sort_order: 0, blocks: [], visibility: "public" }}
      fields={[
        { name: "title", label: "Title", type: "text" },
        { name: "slug", label: "Slug", type: "slug", from: "title" },
        { name: "subtitle", label: "Subtitle", type: "textarea" },
        { name: "hero_image", label: "Hero image", type: "image" },
        {
          name: "blocks",
          label: "Blocks (JSON)",
          type: "json",
          help: "Array of block objects rendered in order on the page.",
        },
        { name: "visibility", label: "Visibility", type: "select", options: ["public", "private"] },
        { name: "sort_order", label: "Sort order", type: "number" },
        { name: "status", label: "Status", type: "status" },
        { name: "publish_at", label: "Publish at", type: "datetime" },
        { name: "seo", label: "SEO (JSON)", type: "json" },
      ]}
    />
  ),
});
