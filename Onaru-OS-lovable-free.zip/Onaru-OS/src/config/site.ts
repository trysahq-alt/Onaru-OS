/**
 * Canonical site configuration.
 * The production domain lives here and nowhere else, so moving hosts is a
 * single environment change rather than a code change.
 */

const raw = import.meta.env as Record<string, string | undefined>;

function normalize(url: string): string {
  return url.replace(/\/+$/, "");
}

export const SITE_URL = normalize(raw["VITE_SITE_URL"] || "https://onaru.app");

export const siteUrl = (path = "/") => `${SITE_URL}${path.startsWith("/") ? path : `/${path}`}`;

