
REVOKE EXECUTE ON FUNCTION public.onaru_hq_overview() FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.onaru_hq_timeseries(integer) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.onaru_hq_cross_product() FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.onaru_hq_product_stats() FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.is_onaru_hq(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.onaru_hq_overview() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.onaru_hq_timeseries(integer) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.onaru_hq_cross_product() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.onaru_hq_product_stats() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.is_onaru_hq(uuid) TO authenticated, service_role;
