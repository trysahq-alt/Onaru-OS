import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { hqUser } from "@/lib/hq.functions";
import { Panel, Empty, Tag, relativeTime } from "@/components/hq/ui";

export const Route = createFileRoute("/_authenticated/hq/users/$id")({ component: HQUser360 });

function HQUser360() {
  const { id } = Route.useParams();
  const fetchUser = useServerFn(hqUser);
  const { data, isLoading, error } = useQuery({
    queryKey: ["hq", "user", id],
    queryFn: () => fetchUser({ data: { id } }),
  });

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading identity…</p>;
  if (error) return <p className="text-sm text-red-300">{(error as Error).message}</p>;
  if (!data) return null;

  const u = data.user;
  const productName = (pid: string) => data.products.find((p) => p.id === pid)?.name ?? "Unknown product";
  const orgName = (oid: string) => data.organizations.find((o) => o.id === oid)?.name ?? "Organization";

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center gap-3">
        <div>
          <h1 className="text-2xl font-semibold sm:text-3xl">{u.display_name || u.primary_email}</h1>
          <p className="text-xs text-muted-foreground">{u.primary_email} · Onaru ID {u.id}</p>
        </div>
        <Tag tone={u.status === "active" ? "good" : "bad"}>{u.status}</Tag>
        {u.email_verified ? <Tag tone="good">email verified</Tag> : <Tag>email unverified</Tag>}
        {u.identity_verified ? <Tag tone="good">identity verified</Tag> : null}
      </header>

      <div className="grid gap-4 xl:grid-cols-2">
        <Panel title="Identity">
          <dl className="space-y-2 text-sm">
            {[
              ["Country", u.country],
              ["Timezone", u.timezone],
              ["Phone", u.phone_verified ? u.phone : u.phone ? `${u.phone} (unverified)` : null],
              ["Joined", u.created_at ? new Date(u.created_at).toLocaleDateString() : null],
              ["Last active", relativeTime(u.last_seen_at)],
            ].map(([k, v]) => (
              <div key={String(k)} className="flex justify-between gap-4">
                <dt className="text-muted-foreground">{String(k)}</dt>
                <dd className="truncate">{v ? String(v) : "—"}</dd>
              </div>
            ))}
          </dl>
        </Panel>

        <Panel title="Products used">
          {data.memberships.length ? (
            <ul className="divide-y divide-border text-sm">
              {data.memberships.map((m) => (
                <li key={m.id} className="flex items-center justify-between gap-3 py-2.5">
                  <span>{productName(m.product_id)}<span className="ml-2 text-xs text-muted-foreground">{m.role}</span></span>
                  <span className="text-xs text-muted-foreground">{relativeTime(m.last_active_at)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="Not mapped to any product yet." />
          )}
        </Panel>

        <Panel title="Organizations">
          {data.orgs.length ? (
            <ul className="divide-y divide-border text-sm">
              {data.orgs.map((o) => (
                <li key={o.organization_id} className="flex items-center justify-between py-2.5">
                  <span>{orgName(o.organization_id)}</span>
                  <span className="text-xs text-muted-foreground">{o.role}</span>
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="No organization memberships." />
          )}
        </Panel>

        <Panel title="Activity timeline">
          {data.events.length ? (
            <ul className="divide-y divide-border text-sm">
              {data.events.map((e) => (
                <li key={e.id} className="flex items-center justify-between gap-3 py-2.5">
                  <span className="truncate">
                    <span className="text-muted-foreground">{productName(e.product_id)}</span>
                    <span className="mx-2 text-muted-foreground/40">—</span>
                    {e.event_name}
                  </span>
                  <span className="shrink-0 text-xs text-muted-foreground">{relativeTime(e.occurred_at)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <Empty title="No recorded activity." />
          )}
        </Panel>
      </div>
    </div>
  );
}
