import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  hqIntegrations,
  hqCreateProduct,
  hqCreateCredential,
  hqRotateCredential,
  hqRevokeCredential,
} from "@/lib/hq.functions";
import { Panel, Empty, Tag, relativeTime } from "@/components/hq/ui";

export const Route = createFileRoute("/_authenticated/hq/integrations")({ component: HQIntegrations });

const SCOPES = [
  "identity:read",
  "identity:write",
  "events:write",
  "organizations:read",
  "organizations:write",
  "memberships:write",
] as const;

function HQIntegrations() {
  const qc = useQueryClient();
  const fetchData = useServerFn(hqIntegrations);
  const createProduct = useServerFn(hqCreateProduct);
  const createCredential = useServerFn(hqCreateCredential);
  const rotate = useServerFn(hqRotateCredential);
  const revoke = useServerFn(hqRevokeCredential);

  const { data, isLoading } = useQuery({ queryKey: ["hq", "integrations"], queryFn: () => fetchData() });
  const [newKey, setNewKey] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", slug: "", environment: "development", status: "beta" });
  const [credForm, setCredForm] = useState<{ productId: string; name: string; environment: string; scopes: string[] }>({
    productId: "",
    name: "",
    environment: "development",
    scopes: ["events:write", "identity:write"],
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ["hq"] });

  const productMutation = useMutation({
    mutationFn: () => createProduct({ data: form as never }),
    onSuccess: () => {
      toast.success("Product registered");
      setForm({ name: "", slug: "", environment: "development", status: "beta" });
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const credMutation = useMutation({
    mutationFn: () => createCredential({ data: credForm as never }),
    onSuccess: (res: { key: string }) => {
      setNewKey(res.key);
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const products = data?.products ?? [];
  const clients = (data?.clients ?? []) as Array<Record<string, unknown>>;

  return (
    <div className="space-y-6">
      <header>
        <p className="text-[10px] uppercase tracking-[0.3em] text-gold">Onaru Connect</p>
        <h1 className="mt-2 text-2xl font-semibold sm:text-3xl">Integration center</h1>
      </header>

      {newKey ? (
        <Panel title="New credential — shown once">
          <p className="break-all rounded-xl border border-gold/30 bg-gold/5 p-3 font-mono text-xs">{newKey}</p>
          <p className="mt-2 text-xs text-muted-foreground">
            Store this now. Onaru keeps only a hash — it can never be displayed again.
          </p>
          <button onClick={() => setNewKey(null)} className="mt-3 text-xs uppercase tracking-[0.2em] text-gold">
            I have saved it
          </button>
        </Panel>
      ) : null}

      <Panel title="Register a product">
        <div className="grid gap-2 sm:grid-cols-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Product name" className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm" />
          <input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} placeholder="slug (a-z, 0-9, -)" className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm" />
          <select value={form.environment} onChange={(e) => setForm({ ...form, environment: e.target.value })} className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm">
            <option value="development">development</option>
            <option value="staging">staging</option>
            <option value="production">production</option>
          </select>
          <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm">
            <option value="beta">beta</option>
            <option value="active">active</option>
            <option value="disabled">disabled</option>
          </select>
        </div>
        <button
          onClick={() => productMutation.mutate()}
          disabled={productMutation.isPending || !form.name || !form.slug}
          className="mt-3 rounded-full bg-gold px-4 py-2 text-xs font-medium text-black disabled:opacity-50"
        >
          Register product
        </button>
      </Panel>

      <Panel title="Issue API credentials">
        {products.length === 0 ? (
          <Empty title="No products connected yet." body="Register a product above to issue credentials." />
        ) : (
          <>
            <div className="grid gap-2 sm:grid-cols-3">
              <select value={credForm.productId} onChange={(e) => setCredForm({ ...credForm, productId: e.target.value })} className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm">
                <option value="">Select product</option>
                {products.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
              <input value={credForm.name} onChange={(e) => setCredForm({ ...credForm, name: e.target.value })} placeholder="Credential name" className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm" />
              <select value={credForm.environment} onChange={(e) => setCredForm({ ...credForm, environment: e.target.value })} className="rounded-xl border border-border bg-card/40 px-3 py-2 text-sm">
                <option value="development">development</option>
                <option value="staging">staging</option>
                <option value="production">production</option>
              </select>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {SCOPES.map((s) => {
                const on = credForm.scopes.includes(s);
                return (
                  <button
                    key={s}
                    onClick={() =>
                      setCredForm({
                        ...credForm,
                        scopes: on ? credForm.scopes.filter((x) => x !== s) : [...credForm.scopes, s],
                      })
                    }
                    className={`rounded-full px-3 py-1 text-[11px] ${on ? "bg-gold/15 text-gold" : "bg-white/5 text-muted-foreground"}`}
                  >
                    {s}
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => credMutation.mutate()}
              disabled={credMutation.isPending || !credForm.productId || !credForm.name || credForm.scopes.length === 0}
              className="mt-3 rounded-full bg-gold px-4 py-2 text-xs font-medium text-black disabled:opacity-50"
            >
              Generate credential
            </button>
          </>
        )}
      </Panel>

      <Panel title="Credentials">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : clients.length ? (
          <ul className="divide-y divide-border text-sm">
            {clients.map((c) => (
              <li key={String(c.id)} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <span className="min-w-0">
                  <span className="block truncate">{String(c.name)}</span>
                  <span className="block truncate font-mono text-[11px] text-muted-foreground">{String(c.key_prefix)}.••••</span>
                </span>
                <span className="flex items-center gap-2">
                  <Tag>{String(c.environment)}</Tag>
                  <Tag tone={c.status === "active" ? "good" : "bad"}>{String(c.status)}</Tag>
                  <span className="text-xs text-muted-foreground">used {relativeTime(c.last_used_at as string)}</span>
                  <button
                    onClick={async () => {
                      const res = await rotate({ data: { id: String(c.id) } });
                      setNewKey(res.key);
                      invalidate();
                    }}
                    className="text-[11px] uppercase tracking-[0.16em] text-gold"
                  >
                    Rotate
                  </button>
                  <button
                    onClick={async () => {
                      await revoke({ data: { id: String(c.id) } });
                      toast.success("Credential revoked");
                      invalidate();
                    }}
                    className="text-[11px] uppercase tracking-[0.16em] text-red-300"
                  >
                    Revoke
                  </button>
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <Empty title="No credentials issued yet." />
        )}
      </Panel>

      <Panel title="Developer instructions">
        <pre className="overflow-x-auto rounded-xl border border-border bg-black/40 p-3 text-[11px] text-muted-foreground">{`POST https://onaru.app/api/public/onaru/v1/identify
Authorization: Bearer <key_prefix>.<secret>
Content-Type: application/json

{ "email": "user@example.com", "external_user_id": "your-app-user-id" }

POST /api/public/onaru/v1/events
{ "event_name": "booking.created", "external_user_id": "your-app-user-id",
  "external_event_id": "unique-id", "properties": { "amount": 25000 } }

POST /api/public/onaru/v1/events/batch   { "events": [ ... ] }
GET  /api/public/onaru/v1/identity/<onaru_user_id>`}</pre>
      </Panel>
    </div>
  );
}
