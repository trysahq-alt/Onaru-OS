import { createFileRoute, Link } from "@tanstack/react-router";
import { siteUrl } from "@/config/site";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Contact";
import { Reveal } from "@/components/site/Reveal";
import { SmoothScroll } from "@/components/site/SmoothScroll";
import { Cursor } from "@/components/site/Cursor";
import { companies } from "@/data/companies";

const title = "Our Companies — ONARU LIMITED";
const description =
  "ONARU builds and operates companies across technology, creativity, food, spaces, entertainment and experiences — TRYSA, Yomi Visuals, YV Studios, YOFA, YV Experience and Playbaaq.";

export const Route = createFileRoute("/companies")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: siteUrl("/companies") },
    ],
    links: [{ rel: "canonical", href: siteUrl("/companies") }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "ItemList",
          name: "The ONARU Ecosystem",
          itemListElement: companies.map((c, i) => ({
            "@type": "ListItem",
            position: i + 1,
            item: { "@type": "Organization", name: c.name, description: c.label },
          })),
        }),
      },
    ],
  }),
  component: CompaniesPage,
});

function CompaniesPage() {
  return (
    <>
      <SmoothScroll />
      <Cursor />
      <Nav />
      <main id="top">
        <section className="relative border-b border-border px-6 pb-24 pt-40 md:px-10 md:pb-32 md:pt-56">
          <div className="mx-auto max-w-[1400px]">
            <Reveal>
              <p className="eyebrow">Our Companies</p>
              <h1 className="display-xl mt-6 max-w-[14ch]">
                Different ideas.
                <br />
                <span className="text-gold-gradient">One ecosystem.</span>
              </h1>
              <p className="mt-8 max-w-[62ch] text-[15px] leading-relaxed text-muted-foreground md:text-lg">
                ONARU builds and operates companies across technology, creativity, food, spaces,
                entertainment and experiences.
              </p>
            </Reveal>

            <Reveal delay={0.1}>
              <div className="mt-14 grid grid-cols-2 gap-x-6 gap-y-5 md:mt-20 md:grid-cols-6">
                {companies.map((c) => (
                  <div key={c.slug} className="border-t border-border pt-4">
                    <p className="truncate text-[13px] text-foreground">{c.name}</p>
                    <p className="mt-1 text-[12px] text-muted-foreground">{c.label}</p>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </section>

        {companies.map((c, i) => (
          <section
            key={c.slug}
            id={c.slug}
            className="border-b border-border px-6 py-24 md:px-10 md:py-36"
          >
            <div className="mx-auto grid max-w-[1400px] items-center gap-10 lg:grid-cols-2 lg:gap-20">
              <Reveal className={i % 2 === 1 ? "lg:order-2" : undefined}>
                <div className="relative overflow-hidden rounded-[1.75rem] hairline">
                  <img
                    src={c.image}
                    alt={`${c.name} — ${c.category}`}
                    loading="lazy"
                    width={1600}
                    height={1100}
                    className="h-full w-full object-cover"
                  />
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/70 to-transparent" />
                </div>
              </Reveal>

              <Reveal delay={0.08}>
                <div>
                  {c.logo ? (
                    <div
                      className={`flex h-16 w-36 items-center justify-center overflow-hidden rounded-xl ${
                        c.tone === "light" ? "bg-foreground/95" : "bg-card hairline"
                      }`}
                    >
                      <img
                        src={c.logo}
                        alt={`${c.name} logo`}
                        loading="lazy"
                        className="h-full w-full object-contain p-2.5"
                        style={{ transform: `scale(${c.zoom ?? 1})` }}
                      />
                    </div>
                  ) : (
                    <div className="inline-flex h-16 items-center rounded-xl bg-card px-5 hairline">
                      <span className="wordmark text-sm text-foreground/85">{c.name}</span>
                    </div>
                  )}

                  <p className="eyebrow mt-8 text-gold">{c.category}</p>
                  <h2 className="display-lg mt-5">{c.name}</h2>
                  <p className="mt-4 text-[15px] italic text-gold-soft/80">{c.tagline}</p>
                  <p className="mt-5 max-w-[54ch] text-[15px] leading-[1.85] text-muted-foreground">
                    {c.long}
                  </p>

                  <div className="mt-8 flex flex-wrap gap-2">
                    {c.highlights.map((h) => (
                      <span
                        key={h}
                        className="rounded-full border border-border px-3 py-1.5 text-[12px] text-muted-foreground"
                      >
                        {h}
                      </span>
                    ))}
                  </div>

                  <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-4">
                    <a href={c.href} className="btn-gold">
                      {c.cta}
                    </a>
                    <div className="flex items-center gap-4">
                      <span className="rounded-full border border-border px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                        {c.status}
                      </span>
                      <span className="text-[13px] text-muted-foreground">{c.location}</span>
                    </div>
                  </div>
                </div>
              </Reveal>
            </div>
          </section>
        ))}

        <section className="px-6 py-28 md:px-10 md:py-40">
          <div className="mx-auto max-w-[1400px]">
            <Reveal>
              <p className="eyebrow">02 — ONARU Studio</p>
              <h2 className="display-lg mt-6 max-w-[20ch]">
                Building something of your own?
              </h2>
              <p className="mt-6 max-w-[54ch] text-[15px] leading-relaxed text-muted-foreground">
                The same teams that build our companies work with a small number of external
                partners each year.
              </p>
              <div className="mt-10 flex flex-wrap gap-4">
                <Link to="/" hash="contact" className="btn-gold">
                  Start a project
                </Link>
                <Link to="/" className="btn-ghost">
                  Back to ONARU
                </Link>
              </div>
            </Reveal>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
