import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { hqOrganizations } from "@/lib/hq.functions";
import { Panel, Empty, relativeTime } from "@/components/hq/ui";

export const Route = createFileRoute("/_authenticated/hq/organizations")({ component: HQOrgs });

function HQOrgs() {
  const fetchOrgs = useServerFn(hqOrganizations);
  const { data, isLoading } = useQuery({ queryKey: ["hq", "orgs"], queryFn: () => fetchOrgs() });

  return (
    <div className="space-y-6">
      <header>
        <p className="text-[10px] uppercase tracking-[0.3em] text-gold">Onaru ID</p>
        <h1 className="mt-2 text-2xl font-semibold sm:text-3xl">Organizations</h1>
      </header>
      <Panel>
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : (data ?? []).length ? (
          <ul className="divide-y divide-border text-sm">
            {((data ?? []) as Array<Record<string, unknown>>).map((o) => (
              <li key={String(o.id)} className="flex items-center justify-between gap-3 py-3">
                <span className="min-w-0">
                  <span className="block truncate">{String(o.name ?? "")}</span>
                  <span className="block truncate text-xs text-muted-foreground">
                    {String(o.organization_type ?? "")} · {String(o.member_count ?? 0)} members
                  </span>
                </span>
                <span className="shrink-0 text-xs text-muted-foreground">{relativeTime(o.created_at as string)}</span>
              </li>
            ))}
          </ul>
        ) : (
          <Empty title="No organizations yet." body="Organizations are created by connected products through Onaru Connect." />
        )}
      </Panel>
    </div>
  );
}
